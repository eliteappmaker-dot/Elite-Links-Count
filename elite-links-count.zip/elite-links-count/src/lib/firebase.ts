import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
import { getAuth } from "firebase/auth";
import { initializeFirestore, persistentLocalCache, persistentMultipleTabManager } from "firebase/firestore";
import { getStorage } from "firebase/storage";

const firebaseConfig = {
  apiKey: "AIzaSyAcYRq8uGaqFIR1itH-EAUqLUoIESPfAB8",
  authDomain: "elite-maker.firebaseapp.com",
  databaseURL: "https://elite-maker-default-rtdb.firebaseio.com",
  projectId: "elite-maker",
  storageBucket: "elite-maker.firebasestorage.app",
  messagingSenderId: "212398895436",
  appId: "1:212398895436:web:4f83c926e38c66abcc5fe9",
  measurementId: "G-GC74MQV0L5"
};

const app = initializeApp(firebaseConfig);
export const analytics = typeof window !== "undefined" ? getAnalytics(app) : null;
export const auth = getAuth(app);

// Initialize Firestore with settings to improve connectivity
export const db = initializeFirestore(app, {
  localCache: persistentLocalCache({
    tabManager: persistentMultipleTabManager()
  }),
  experimentalForceLongPolling: true,
});

export const storage = getStorage(app);
