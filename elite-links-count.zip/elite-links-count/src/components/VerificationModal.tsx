import React from 'react';
import { X, Send, Instagram, ShieldAlert } from 'lucide-react';

interface VerificationModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function VerificationModal({ isOpen, onClose }: VerificationModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-75 p-4 animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl shadow-2xl max-w-md w-full overflow-hidden transform scale-100 transition-transform">
        <div className="p-6 border-b border-gray-100 flex justify-between items-center bg-red-50">
          <h3 className="text-xl font-black text-red-600 flex items-center gap-2 uppercase tracking-wide">
            <ShieldAlert size={24} /> Verification Required
          </h3>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 transition-colors">
            <X size={24} />
          </button>
        </div>
        
        <div className="p-8 space-y-6 text-center">
          <p className="text-gray-600 font-medium text-lg leading-relaxed">
            To generate links, you must verify your account. Please contact the admin via Telegram or Instagram to get verified.
          </p>
          <p className="text-sm text-gray-500 font-medium bg-yellow-50 p-3 rounded-xl border border-yellow-100">
            After sending the message on Telegram or Instagram, your account will be verified within <span className="font-bold text-gray-900">2-3 hours</span>. You will receive a reply on the account you used to message us. Please wait patiently.
          </p>
          
          <div className="space-y-4 pt-2">
            <a 
              href="https://t.me/eliteindustrysofficial" 
              target="_blank" 
              rel="noreferrer"
              className="flex items-center justify-center gap-3 w-full bg-[#0088cc] hover:bg-[#0077b5] text-white py-4 rounded-xl font-bold text-lg transition-all shadow-lg shadow-blue-100 hover:shadow-xl hover:-translate-y-0.5"
            >
              <Send size={24} /> Contact on Telegram
            </a>
            
            <a 
              href="https://www.instagram.com/elitehubanimeofficials?igsh=ajJhdW5qd3Q0azF5" 
              target="_blank" 
              rel="noreferrer"
              className="flex items-center justify-center gap-3 w-full bg-gradient-to-r from-[#833ab4] via-[#fd1d1d] to-[#fcb045] text-white py-4 rounded-xl font-bold text-lg transition-all shadow-lg shadow-pink-100 hover:shadow-xl hover:-translate-y-0.5"
            >
              <Instagram size={24} /> Contact on Instagram
            </a>
          </div>
        </div>
        
        <div className="bg-gray-50 p-4 text-center border-t border-gray-100">
          <p className="text-xs text-gray-400 font-medium">
            Thank you for your patience.
          </p>
        </div>
      </div>
    </div>
  );
}
