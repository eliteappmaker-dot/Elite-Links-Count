import React, { useState, useEffect } from 'react';
import { Lock, ShieldAlert } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';

export function AdBlockDetector() {
  const [isAdBlockActive, setIsAdBlockActive] = useState(false);
  const { urlSettings } = useAuth();

  useEffect(() => {
    const checkAdBlock = async () => {
      // Multiple bait tests
      const adsbox = document.createElement('div');
      adsbox.innerHTML = '&nbsp;';
      adsbox.className = 'adsbox adbox pub_300x250 pub_300x250m pub_728x90 text-ad textAd text_ad text_ads text-ads';
      adsbox.style.position = 'absolute';
      adsbox.style.left = '-1000px';
      adsbox.style.top = '-1000px';
      document.body.appendChild(adsbox);

      setTimeout(async () => {
        const isAdsBoxBlocked = adsbox.offsetHeight === 0 || adsbox.clientWidth === 0;
        
        let isFetchBlocked = false;
        try {
          // Head request to Google Ads script
          await fetch('https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js', { 
            method: 'HEAD', 
            mode: 'no-cors',
            cache: 'no-store'
          });
        } catch (e) {
          isFetchBlocked = true;
        }

        if (isAdsBoxBlocked || isFetchBlocked) {
          setIsAdBlockActive(true);
        }
        
        adsbox.remove();
      }, 500);
    };

    // Only run detection on non-admin pages if needed, but usually redirect is public
    checkAdBlock();
  }, []);

  if (!isAdBlockActive) return null;

  return (
    <div className="fixed inset-0 z-[10000] flex flex-col items-center justify-center bg-gray-950/95 backdrop-blur-md p-4 text-white text-center select-none">
      <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-20"></div>
      
      <div className="relative bg-gray-900/80 p-8 md:p-12 rounded-[3rem] border-2 border-red-500/40 shadow-[0_0_80px_rgba(239,68,68,0.3)] max-w-lg w-full backdrop-blur-2xl space-y-8 animate-in zoom-in duration-500">
        <div className="relative">
          <div className="absolute inset-0 bg-red-500 blur-3xl opacity-30"></div>
          <div className="bg-red-500/10 p-6 rounded-full inline-block relative border border-red-500/30">
            <ShieldAlert size={64} className="text-red-500 animate-pulse" />
          </div>
        </div>
        
        <div className="space-y-4">
          <h2 className="text-4xl font-black uppercase tracking-tighter text-red-500 leading-none">
            Ads Block Detected!
          </h2>
          <p className="text-gray-300 text-xl font-bold leading-relaxed">
            Please close your ads block and continue this website
          </p>
          <div className="h-1 w-20 bg-red-500/40 mx-auto rounded-full"></div>
        </div>

        <div className="bg-white/5 border border-white/10 p-6 rounded-3xl text-left space-y-4">
          <p className="text-sm text-gray-400 font-medium leading-relaxed">
            We noticed you're using an ad-blocker. To keep our high-CPM shortening services free for everyone, we require ads to be displayed.
          </p>
          <ul className="text-xs text-emerald-400 font-bold space-y-2 uppercase tracking-widest list-none">
            <li className="flex items-center gap-2">
              <div className="w-1.5 h-1.5 rounded-full bg-emerald-500"></div>
              Pause AdBlock for this site
            </li>
            <li className="flex items-center gap-2">
              <div className="w-1.5 h-1.5 rounded-full bg-emerald-500"></div>
              Refresh the page to proceed
            </li>
          </ul>
        </div>

        <button 
          onClick={() => window.location.reload()} 
          className="group relative w-full overflow-hidden bg-emerald-600 text-white px-8 py-5 rounded-[2rem] font-black uppercase tracking-[0.25em] transition-all hover:bg-emerald-500 active:scale-95 shadow-2xl shadow-emerald-900/20"
        >
          <span className="relative z-10 flex items-center justify-center gap-3">
             Refresh Page Now
          </span>
        </button>
        
        <div className="pt-2">
          <p className="text-[10px] text-gray-600 font-bold uppercase tracking-[0.3em]">
            Protected by Elite Security &copy; 2026
          </p>
        </div>
      </div>
    </div>
  );
}
