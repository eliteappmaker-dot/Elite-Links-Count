import { useEffect, useRef } from 'react';

export function AdDisplay({ html }: { html: string }) {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!containerRef.current || !html) return;
    
    const container = containerRef.current;
    container.innerHTML = '';
    
    const slot = document.createElement('div');
    slot.innerHTML = html;
    
    // Move all nodes to container
    Array.from(slot.childNodes).forEach(node => {
      if (node.nodeName === 'SCRIPT') {
        const script = document.createElement('script');
        const originalScript = node as HTMLScriptElement;
        
        Array.from(originalScript.attributes).forEach(attr => {
          script.setAttribute(attr.name, attr.value);
        });
        
        if (originalScript.src) {
          script.src = originalScript.src;
        } else {
          script.textContent = originalScript.textContent;
        }
        
        container.appendChild(script);
      } else {
        container.appendChild(node.cloneNode(true));
      }
    });
  }, [html]);

  return <div ref={containerRef} className="w-full flex justify-center overflow-hidden" />;
}
