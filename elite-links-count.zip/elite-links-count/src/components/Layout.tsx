import { Link, Outlet, useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { auth, db } from "@/lib/firebase";
import { LogOut, Menu, X, Send, Instagram, Mail, MessageCircle, BarChart2, LayoutDashboard, Wallet, CheckSquare, ShieldCheck, LogIn, User, Link as LinkIcon, Users } from "lucide-react";
import { useState, useEffect } from "react";
import { doc, getDoc } from "firebase/firestore";

export function Layout() {
  const { user, isAdmin, urlSettings } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);

  const handleLogout = async () => {
    await auth.signOut();
    navigate("/");
  };

  const isActive = (path: string) => location.pathname === path;

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900 font-sans flex flex-col">
      {/* Header */}
      <header className="bg-white border-b border-gray-100 sticky top-0 z-40 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            <div className="flex items-center">
              <Link to="/" className="flex items-center gap-4 group">
                <img src="https://iili.io/qfdOijn.png" alt="Elite Links Count" className="h-16 md:h-20 object-contain animate-logo-glow transition-all duration-500 group-hover:scale-110" onError={(e) => {
                  e.currentTarget.src = "https://ui-avatars.com/api/?name=Elite+Links+Count&background=10b981&color=fff";
                }} />
                <div className="flex flex-col">
                  <span className="font-righteous text-2xl md:text-3xl text-gradient tracking-tighter leading-none">Elite Links</span>
                  <span className="font-righteous text-xl md:text-2xl text-gradient tracking-widest leading-none opacity-80">Count</span>
                </div>
              </Link>
            </div>

            {/* Desktop Nav */}
            <nav className="hidden lg:flex items-center gap-2">
              {user ? (
                <>
                  <Link to="/" className={`nav-button ${isActive("/") ? "nav-button-active" : "nav-button-inactive"}`}>
                    <LinkIcon size={18} />
                    Links Count
                  </Link>
                  <Link to="/elite-hub" className={`nav-button ${isActive("/elite-hub") ? "nav-button-active" : "nav-button-inactive"}`}>
                    <LinkIcon size={18} />
                    Elite Hub
                  </Link>
                  <Link to="/dashboard" className={`nav-button ${isActive("/dashboard") ? "nav-button-active" : "nav-button-inactive"}`}>
                    <LayoutDashboard size={18} />
                    Dashboard
                  </Link>
                  <Link to="/analytics" className={`nav-button ${isActive("/analytics") ? "nav-button-active" : "nav-button-inactive"}`}>
                    <BarChart2 size={18} />
                    Analytics
                  </Link>
                  <Link to="/tasks" className={`nav-button ${isActive("/tasks") ? "nav-button-active" : "nav-button-inactive"}`}>
                    <CheckSquare size={18} />
                    Tasks
                  </Link>
                  <Link to="/invite" className={`nav-button ${isActive("/invite") ? "nav-button-active" : "nav-button-inactive"}`}>
                    <Users size={18} />
                    Invite
                  </Link>
                  <Link to="/wallet" className={`nav-button ${isActive("/wallet") ? "nav-button-active" : "nav-button-inactive"}`}>
                    <Wallet size={18} />
                    Wallet
                  </Link>
                  <Link to="/profile" className={`nav-button ${isActive("/profile") ? "nav-button-active" : "nav-button-inactive"}`}>
                    <User size={18} />
                    Profile
                  </Link>
                  {isAdmin && (
                    <>
                      <Link to="/admin" className={`nav-button ${isActive("/admin") ? "nav-button-active" : "nav-button-inactive"}`}>
                        <ShieldCheck size={18} />
                        Admin
                      </Link>
                      <Link to="/links-count/preview-links-count" className="nav-button nav-button-inactive text-xs" target="_blank">
                        Preview LC
                      </Link>
                      <Link to="/preview-elite-hub" className="nav-button nav-button-inactive text-xs" target="_blank">
                        Preview EH
                      </Link>
                    </>
                  )}
                  <div className="h-6 w-px bg-gray-200 mx-2"></div>
                  <button
                    onClick={handleLogout}
                    className="flex items-center gap-2 px-4 py-2 rounded-xl font-semibold text-red-500 hover:bg-red-50 transition-all duration-300"
                  >
                    <LogOut size={18} />
                    Logout
                  </button>
                </>
              ) : (
                <Link to="/login" className="flex items-center gap-2 bg-emerald-600 text-white px-6 py-2.5 rounded-xl font-bold hover:bg-emerald-700 transition-all duration-300 shadow-md hover:shadow-lg active:scale-95">
                  <LogIn size={18} />
                  Login / Signup
                </Link>
              )}
            </nav>

            {/* Mobile Menu Button */}
            <div className="lg:hidden flex items-center">
              <button
                onClick={() => setMenuOpen(true)}
                className="p-2 text-gray-600 hover:text-emerald-600 focus:outline-none bg-gray-50 rounded-xl border border-gray-100"
              >
                <Menu size={28} />
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Side Drawer */}
      {menuOpen && (
        <div className="fixed inset-0 z-50 flex">
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setMenuOpen(false)}></div>
          <div className="relative flex-1 flex flex-col max-w-xs w-full bg-white shadow-2xl h-full transform transition-transform duration-300 ease-in-out">
            <div className="absolute top-0 right-0 -mr-14 pt-6">
              <button
                className="flex items-center justify-center h-12 w-12 rounded-full bg-white/10 text-white hover:bg-white/20 focus:outline-none"
                onClick={() => setMenuOpen(false)}
              >
                <X className="h-8 w-8" />
              </button>
            </div>
            
            <div className="flex-1 h-0 pt-8 pb-4 overflow-y-auto">
              <div className="flex-shrink-0 flex items-center gap-4 px-8 mb-12">
                <img src="https://iili.io/qfdOijn.png" alt="Elite Links Count" className="h-20 object-contain animate-logo-glow" onError={(e) => {
                  e.currentTarget.src = "https://ui-avatars.com/api/?name=Elite+Links+Count&background=10b981&color=fff";
                }} />
                <div className="flex flex-col">
                  <span className="font-righteous text-2xl text-gradient leading-none">Elite Links</span>
                  <span className="font-righteous text-xl text-gradient leading-none opacity-80">Count</span>
                </div>
              </div>
              <nav className="px-4 space-y-3">
                {user ? (
                  <>
                    <Link to="/" onClick={() => setMenuOpen(false)} className={`flex items-center gap-4 px-6 py-4 rounded-2xl text-lg font-bold transition-all ${isActive("/") ? "bg-emerald-50 text-emerald-600" : "text-gray-700 hover:bg-gray-50"}`}>
                      <LinkIcon size={22} />
                      Links Count
                    </Link>
                    <Link to="/elite-hub" onClick={() => setMenuOpen(false)} className={`flex items-center gap-4 px-6 py-4 rounded-2xl text-lg font-bold transition-all ${isActive("/elite-hub") ? "bg-emerald-50 text-emerald-600" : "text-gray-700 hover:bg-gray-50"}`}>
                      <LinkIcon size={22} />
                      Elite Hub
                    </Link>
                    <Link to="/dashboard" onClick={() => setMenuOpen(false)} className={`flex items-center gap-4 px-6 py-4 rounded-2xl text-lg font-bold transition-all ${isActive("/dashboard") ? "bg-emerald-50 text-emerald-600" : "text-gray-700 hover:bg-gray-50"}`}>
                      <LayoutDashboard size={22} />
                      Dashboard
                    </Link>
                    <Link to="/analytics" onClick={() => setMenuOpen(false)} className={`flex items-center gap-4 px-6 py-4 rounded-2xl text-lg font-bold transition-all ${isActive("/analytics") ? "bg-emerald-50 text-emerald-600" : "text-gray-700 hover:bg-gray-50"}`}>
                      <BarChart2 size={22} />
                      Analytics
                    </Link>
                    <Link to="/tasks" onClick={() => setMenuOpen(false)} className={`flex items-center gap-4 px-6 py-4 rounded-2xl text-lg font-bold transition-all ${isActive("/tasks") ? "bg-emerald-50 text-emerald-600" : "text-gray-700 hover:bg-gray-50"}`}>
                      <CheckSquare size={22} />
                      Tasks
                    </Link>
                    <Link to="/invite" onClick={() => setMenuOpen(false)} className={`flex items-center gap-4 px-6 py-4 rounded-2xl text-lg font-bold transition-all ${isActive("/invite") ? "bg-emerald-50 text-emerald-600" : "text-gray-700 hover:bg-gray-50"}`}>
                      <Users size={22} />
                      Invite
                    </Link>
                    <Link to="/wallet" onClick={() => setMenuOpen(false)} className={`flex items-center gap-4 px-6 py-4 rounded-2xl text-lg font-bold transition-all ${isActive("/wallet") ? "bg-emerald-50 text-emerald-600" : "text-gray-700 hover:bg-gray-50"}`}>
                      <Wallet size={22} />
                      Wallet
                    </Link>
                    <Link to="/profile" onClick={() => setMenuOpen(false)} className={`flex items-center gap-4 px-6 py-4 rounded-2xl text-lg font-bold transition-all ${isActive("/profile") ? "bg-emerald-50 text-emerald-600" : "text-gray-700 hover:bg-gray-50"}`}>
                      <User size={22} />
                      Profile
                    </Link>
                    {isAdmin && (
                      <>
                        <Link to="/admin" onClick={() => setMenuOpen(false)} className={`flex items-center gap-4 px-6 py-4 rounded-2xl text-lg font-bold transition-all ${isActive("/admin") ? "bg-emerald-50 text-emerald-600" : "text-gray-700 hover:bg-gray-50"}`}>
                          <ShieldCheck size={22} />
                          Admin Panel
                        </Link>
                        <Link to="/links-count/preview-links-count" onClick={() => setMenuOpen(false)} className="flex items-center gap-4 px-6 py-4 rounded-2xl text-lg font-bold text-gray-700 hover:bg-gray-50 transition-all" target="_blank">
                          <LinkIcon size={22} />
                          Preview Links Count
                        </Link>
                        <Link to="/preview-elite-hub" onClick={() => setMenuOpen(false)} className="flex items-center gap-4 px-6 py-4 rounded-2xl text-lg font-bold text-gray-700 hover:bg-gray-50 transition-all" target="_blank">
                          <LinkIcon size={22} />
                          Preview Elite Hub
                        </Link>
                      </>
                    )}
                    <div className="pt-6 mt-6 border-t border-gray-100">
                      <button
                        onClick={() => { handleLogout(); setMenuOpen(false); }}
                        className="w-full flex items-center gap-4 px-6 py-4 rounded-2xl text-lg font-bold text-red-600 hover:bg-red-50 transition-all"
                      >
                        <LogOut size={22} />
                        Logout
                      </button>
                    </div>
                  </>
                ) : (
                  <Link to="/login" onClick={() => setMenuOpen(false)} className="flex items-center justify-center gap-3 w-full bg-emerald-600 text-white px-6 py-4 rounded-2xl text-lg font-bold hover:bg-emerald-700 transition-all shadow-lg active:scale-95">
                    <LogIn size={22} />
                    Login / Signup
                  </Link>
                )}
              </nav>
            </div>
          </div>
        </div>
      )}

      {/* Main Content */}
      <main className="flex-1 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <Outlet />
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-100 pt-16 pb-8 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
            {/* Brand Column */}
            <div className="col-span-1 md:col-span-2 space-y-6 text-center md:text-left">
              <Link to="/" className="flex items-center justify-center md:justify-start gap-4">
                <img src="https://iili.io/qfdOijn.png" alt="Elite Links Count" className="h-16 object-contain" />
                <div className="flex flex-col">
                  <span className="font-righteous text-2xl text-gradient leading-none">Elite Links</span>
                  <span className="font-righteous text-xl text-gradient leading-none opacity-80">Count</span>
                </div>
              </Link>
              <p className="text-gray-500 text-sm max-w-sm mx-auto md:mx-0">
                The most professional link monetization platform. Shorten, share and earn money with high CPM rates and real-time analytics.
              </p>
              <div className="flex items-center justify-center md:justify-start gap-4">
                <a href={urlSettings.telegramChannel || "#"} target="_blank" rel="noreferrer" className="p-2 bg-gray-50 text-gray-400 hover:text-blue-500 hover:bg-blue-50 rounded-xl transition-all">
                  <Send size={20} />
                </a>
                <a href={urlSettings.whatsappChannel || "#"} target="_blank" rel="noreferrer" className="p-2 bg-gray-50 text-gray-400 hover:text-green-500 hover:bg-green-50 rounded-xl transition-all">
                  <MessageCircle size={20} />
                </a>
                <a href={urlSettings.instagramChannel || "#"} target="_blank" rel="noreferrer" className="p-2 bg-gray-50 text-gray-400 hover:text-pink-600 hover:bg-pink-50 rounded-xl transition-all">
                  <Instagram size={20} />
                </a>
              </div>
            </div>

            {/* Links Column 1 */}
            <div className="space-y-6 text-center md:text-left">
              <h4 className="text-xs font-black text-gray-900 uppercase tracking-widest">Legal & Policies</h4>
              <ul className="space-y-4 text-sm font-bold text-gray-500">
                <li><a href={urlSettings.privacyPolicy || "#"} target="_blank" rel="noreferrer" className="hover:text-emerald-600 transition-colors">Privacy and Policy</a></li>
                <li><a href={urlSettings.useAndCondition || "#"} target="_blank" rel="noreferrer" className="hover:text-emerald-600 transition-colors">Use and Condition</a></li>
                <li><a href={urlSettings.adsCookies || "#"} target="_blank" rel="noreferrer" className="hover:text-emerald-600 transition-colors">Ads Cookies</a></li>
                <li><Link to="/earning-policy" className="hover:text-emerald-600 transition-colors">Earning Policy</Link></li>
              </ul>
            </div>

            {/* Links Column 2 */}
            <div className="space-y-6 text-center md:text-left">
              <h4 className="text-xs font-black text-gray-900 uppercase tracking-widest">Support & Help</h4>
              <ul className="space-y-4 text-sm font-bold text-gray-500">
                <li><a href={urlSettings.paymentIssue || "#"} target="_blank" rel="noreferrer" className="hover:text-emerald-600 transition-colors">Payment Issue</a></li>
                <li><a href={urlSettings.websiteAdsProblem || "#"} target="_blank" rel="noreferrer" className="hover:text-emerald-600 transition-colors">Website Ads Problem</a></li>
                <li><a href={urlSettings.websiteProblem || "#"} target="_blank" rel="noreferrer" className="hover:text-emerald-600 transition-colors">Website Problem</a></li>
                <li><a href={urlSettings.feedback || "#"} target="_blank" rel="noreferrer" className="hover:text-emerald-600 transition-colors">Feedback</a></li>
                <li><a href={urlSettings.contactAdmin || "#"} target="_blank" rel="noreferrer" className="hover:text-emerald-600 transition-colors">Contact Admin</a></li>
              </ul>
            </div>
          </div>

          <div className="pt-8 border-t border-gray-100 flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="text-xs font-bold text-gray-400 uppercase tracking-[0.3em]">Website version 1.1</div>
            <div className="text-sm font-medium text-gray-500">&copy; {new Date().getFullYear()} Elite Links Count. All rights reserved.</div>
          </div>
        </div>
      </footer>
    </div>
  );
}
