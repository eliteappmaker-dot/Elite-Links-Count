import React, { useEffect, useRef, useState } from 'react';

export function BannerAdDisplay({ html, className = "" }: { html: string, className?: string }) {
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const [height, setHeight] = useState(280); // Default start height
  // Generate a unique name for this iframe to identify messages
  const [iframeName] = useState(`ad-frame-${Math.random().toString(36).substr(2, 9)}`);

  useEffect(() => {
    const iframe = iframeRef.current;
    if (!iframe) return;

    const doc = iframe.contentDocument || iframe.contentWindow?.document;
    if (!doc) return;

    // Create a robust HTML structure for the ad
    const adContent = `
      <!DOCTYPE html>
      <html>
        <head>
          <base target="_blank">
          <style>
            body { 
              margin: 0; 
              padding: 0; 
              display: flex; 
              justify-content: center; 
              align-items: center; 
              overflow: hidden; 
              background-color: transparent;
            }
            /* Ensure images/iframes inside fit */
            img, iframe { max-width: 100%; }
          </style>
        </head>
        <body>
          <div id="ad-container">${html}</div>
          <script>
            function sendHeight() {
              const h = document.body.scrollHeight;
              if(h > 0) {
                window.parent.postMessage({ type: 'AD_RESIZE', height: h, id: window.name }, '*');
              }
            }

            // Initial check
            setTimeout(sendHeight, 500);
            
            // Periodic check
            setInterval(sendHeight, 1000);

            // Resize observer
            const resizeObserver = new ResizeObserver(() => sendHeight());
            resizeObserver.observe(document.body);
          </script>
        </body>
      </html>
    `;

    doc.open();
    doc.write(adContent);
    doc.close();

  }, [html]);

  // Listen for resize messages
  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      if (event.data && event.data.type === 'AD_RESIZE' && event.data.id === iframeName) {
        // Add a little padding to avoid scrollbars
        setHeight(event.data.height + 10);
      }
    };
    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, [iframeName]);

  return (
    <div className={`w-full flex justify-center ${className}`}>
      <iframe 
        ref={iframeRef}
        name={iframeName}
        title="Advertisement"
        className="w-full border-0 overflow-hidden"
        style={{ height: `${height}px`, transition: 'height 0.3s ease' }}
        scrolling="no"
        sandbox="allow-scripts allow-same-origin allow-popups allow-forms allow-popups-to-escape-sandbox"
      />
    </div>
  );
}
