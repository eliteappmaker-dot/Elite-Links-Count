import React from 'react';
import { Shield, Lock, Eye, FileText } from 'lucide-react';

export function PrivacyPolicy() {
  return (
    <div className="max-w-4xl mx-auto py-12 px-4 sm:px-6 lg:px-8 bg-white rounded-2xl shadow-sm border border-gray-200">
      <div className="text-center mb-12">
        <div className="mx-auto w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mb-4">
          <Shield className="h-8 w-8 text-emerald-600" />
        </div>
        <h1 className="text-3xl font-bold text-gray-900">Privacy Policy</h1>
        <p className="text-gray-500 mt-2">Last updated: {new Date().toLocaleDateString()}</p>
      </div>

      <div className="space-y-8 text-gray-600">
        <section>
          <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
            <Eye className="text-emerald-600" size={20} />
            Information We Collect
          </h2>
          <p>
            We collect information you provide directly to us, such as when you create an account, shorten a link, or contact us for support. This may include your name, email address, and payment information.
          </p>
          <p className="mt-2">
            When you use our services, we automatically collect certain information about your device and usage, including your IP address, browser type, and operating system.
          </p>
        </section>

        <section>
          <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
            <FileText className="text-emerald-600" size={20} />
            How We Use Your Information
          </h2>
          <ul className="list-disc pl-5 space-y-2">
            <li>To provide, maintain, and improve our services.</li>
            <li>To process transactions and send you related information.</li>
            <li>To monitor and analyze trends, usage, and activities in connection with our services.</li>
            <li>To detect, investigate, and prevent fraudulent transactions and other illegal activities.</li>
          </ul>
        </section>

        <section>
          <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
            <Lock className="text-emerald-600" size={20} />
            Data Security
          </h2>
          <p>
            We take reasonable measures to help protect information about you from loss, theft, misuse and unauthorized access, disclosure, alteration and destruction.
          </p>
        </section>

        <section>
          <h2 className="text-xl font-bold text-gray-900 mb-4">Contact Us</h2>
          <p>
            If you have any questions about this Privacy Policy, please contact us.
          </p>
        </section>
      </div>
    </div>
  );
}
