import React, { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { db } from "@/lib/firebase";
import { collection, addDoc, query, where, getDocs, Timestamp, doc, getDoc, updateDoc } from "firebase/firestore";
import { calculateEarnings } from "@/lib/utils";
import { IndianRupee, CheckCircle, Clock, XCircle, Eye, X, ShieldCheck, Wallet as WalletIcon, Save, Edit2, Info, Check, MessageSquare, Mail, TrendingUp, Upload, Loader2 } from "lucide-react";
import toast from "react-hot-toast";

export function Wallet() {
  const { user, appSettings } = useAuth();
  const [loading, setLoading] = useState(false);
  const [fetching, setFetching] = useState(true);
  
  // Stats
  const [stats, setStats] = useState({
    lifetimeEarnings: 0,
    availableBalance: 0,
    pendingAmount: 0,
  });

  // Payment Info
  const [paymentInfo, setPaymentInfo] = useState({
    upiName: "",
    whatsappNumber: "",
    notificationPreference: "whatsapp" as "whatsapp" | "email",
    upiId: "",
    qrUrl: "",
  });
  const [isEditingPayment, setIsEditingPayment] = useState(false);
  const [hasSavedPaymentInfo, setHasSavedPaymentInfo] = useState(false);
  const [uploading, setUploading] = useState(false);

  // Withdrawals
  const [withdrawals, setWithdrawals] = useState<any[]>([]);
  const [isWithdrawModalOpen, setIsWithdrawModalOpen] = useState(false);
  const [isSuccessModalOpen, setIsSuccessModalOpen] = useState(false);
  const [withdrawAmount, setWithdrawAmount] = useState("");
  const [selectedWithdrawal, setSelectedWithdrawal] = useState<any | null>(null);

  useEffect(() => {
    if (user) {
      fetchData();
    }
  }, [user]);

  const fetchData = async () => {
    if (!user) return;
    setFetching(true);
    try {
      // 1. Fetch user payment info
      const userDoc = await getDoc(doc(db, "users", user.uid));
      if (userDoc.exists()) {
        const data = userDoc.data();
        if (data.paymentInfo) {
          setPaymentInfo(data.paymentInfo);
          setHasSavedPaymentInfo(true);
        } else {
          setIsEditingPayment(true);
        }
      }

      // 2. Fetch all links to calculate lifetime earnings
      const linksQ = query(collection(db, "links"), where("userID", "==", user.uid));
      const linksSnap = await getDocs(linksQ);
      let lifetimeEarnings = 0;
      linksSnap.forEach((doc) => {
        const data = doc.data();
        const linkCPM = data.cpm || appSettings.cpm;
        lifetimeEarnings += calculateEarnings(data.totalClicks || 0, linkCPM);
      });

      // 3. Fetch all withdrawals
      const wQ = query(collection(db, "withdrawals"), where("userID", "==", user.uid));
      const wSnap = await getDocs(wQ);
      const fetchedW = wSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as any));
      
      let pendingAmount = 0;
      let approvedAmount = 0;

      fetchedW.forEach((w: any) => {
        if (w.status === "Pending") pendingAmount += w.amount;
        if (w.status === "Approved") approvedAmount += w.amount;
      });

      setStats({
        lifetimeEarnings,
        pendingAmount,
        availableBalance: (lifetimeEarnings + (userDoc.data()?.walletBalance || 0)) - pendingAmount - approvedAmount,
      });

      // Sort withdrawals by date
      fetchedW.sort((a: any, b: any) => {
        const dateA = a.createdAt?.toMillis() || 0;
        const dateB = b.createdAt?.toMillis() || 0;
        return dateB - dateA;
      });
      setWithdrawals(fetchedW);

    } catch (error) {
      console.error("Error fetching wallet data:", error);
      toast.error("Failed to load wallet data");
    } finally {
      setFetching(false);
    }
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Check file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      return toast.error("Image size must be less than 5MB");
    }

    setUploading(true);
    const formData = new FormData();
    formData.append('image', file);

    try {
      const response = await fetch(`https://api.imgbb.com/1/upload?key=08b09e1fc90b8d5b79780c7a9e392cd1`, {
        method: 'POST',
        body: formData,
      });
      const data = await response.json();
      
      if (data.success) {
        setPaymentInfo({ ...paymentInfo, qrUrl: data.data.url });
        toast.success("QR Code uploaded successfully!");
      } else {
        toast.error("Failed to upload image. Please try again.");
      }
    } catch (error) {
      console.error("Upload error:", error);
      toast.error("Error connecting to upload server");
    } finally {
      setUploading(false);
    }
  };

  const handleSavePaymentInfo = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!paymentInfo.upiName || !paymentInfo.whatsappNumber || !paymentInfo.upiId || !paymentInfo.qrUrl) {
      return toast.error("All payment fields are compulsory");
    }

    // Direct link validation
    const directLinkRegex = /\.(jpg|jpeg|png|webp|gif)$|(\?.*)$/i;
    const isDirectLink = directLinkRegex.test(paymentInfo.qrUrl.split('?')[0]);
    
    if (!isDirectLink) {
      return toast.error("Please provide a direct image link (ending in .jpg, .png, etc.)");
    }

    setLoading(true);
    try {
      await updateDoc(doc(db, "users", user!.uid), {
        paymentInfo: paymentInfo
      });
      setHasSavedPaymentInfo(true);
      setIsEditingPayment(false);
      toast.success("Payment information saved successfully!");
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleWithdrawRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(withdrawAmount);
    const minWithdrawal = appSettings.minWithdrawal || 100;
    
    if (isNaN(amount) || amount < minWithdrawal) {
      return toast.error(`Minimum withdrawal is ₹${minWithdrawal}`);
    }
    if (amount > stats.availableBalance) {
      return toast.error("Insufficient balance");
    }

    setLoading(true);
    try {
      await addDoc(collection(db, "withdrawals"), {
        userID: user!.uid,
        userEmail: user!.email,
        userName: user!.displayName || user!.email?.split("@")[0],
        paymentInfo: paymentInfo,
        upiId: paymentInfo.upiId, // For quick access
        amount: amount,
        status: "Pending",
        createdAt: Timestamp.now(),
      });

      setIsWithdrawModalOpen(false);
      setIsSuccessModalOpen(true);
      setWithdrawAmount("");
      fetchData();
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  if (fetching) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-600"></div>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto space-y-8 pb-12">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Wallet</h1>
          <p className="text-gray-500 mt-1">Manage your earnings and secure withdrawals</p>
        </div>
        <div className="flex items-center gap-2 bg-emerald-50 px-4 py-2 rounded-xl border border-emerald-100">
          <ShieldCheck className="text-emerald-600" size={20} />
          <span className="text-emerald-700 font-bold text-sm">Secure Payments</span>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-3xl border border-gray-200 shadow-sm relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:scale-110 transition-transform">
            <TrendingUp size={64} className="text-emerald-600" />
          </div>
          <p className="text-sm text-gray-500 font-bold uppercase tracking-wider mb-2">Lifetime Earning</p>
          <div className="text-3xl font-black text-gray-900">₹{stats.lifetimeEarnings.toFixed(2)}</div>
        </div>

        <div className="bg-emerald-600 p-6 rounded-3xl shadow-lg shadow-emerald-100 relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-4 opacity-20 group-hover:scale-110 transition-transform text-white">
            <WalletIcon size={64} />
          </div>
          <p className="text-sm text-emerald-100 font-bold uppercase tracking-wider mb-2">Available Balance</p>
          <div className="text-3xl font-black text-white">₹{stats.availableBalance.toFixed(2)}</div>
          <p className="text-xs text-emerald-100 mt-2">Ready to withdraw</p>
        </div>

        <div className="bg-white p-6 rounded-3xl border border-gray-200 shadow-sm relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:scale-110 transition-transform">
            <Clock size={64} className="text-orange-600" />
          </div>
          <p className="text-sm text-gray-500 font-bold uppercase tracking-wider mb-2">Pending Amount</p>
          <div className="text-3xl font-black text-gray-900">₹{stats.pendingAmount.toFixed(2)}</div>
        </div>
      </div>

      {/* Payment Information Section */}
      <div className="bg-white rounded-3xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-gray-100 flex justify-between items-center bg-gray-50/50">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-emerald-100 text-emerald-600 rounded-xl">
              <Info size={20} />
            </div>
            <h2 className="text-xl font-bold text-gray-900">Payment Information</h2>
          </div>
          {hasSavedPaymentInfo && !isEditingPayment && (
            <button 
              onClick={() => setIsEditingPayment(true)}
              className="flex items-center gap-2 text-emerald-600 font-bold text-sm hover:bg-emerald-50 px-4 py-2 rounded-xl transition-colors"
            >
              <Edit2 size={16} /> Edit Info
            </button>
          )}
        </div>

        <div className="p-8">
          {isEditingPayment ? (
            <form onSubmit={handleSavePaymentInfo} className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="block text-sm font-bold text-gray-700 uppercase tracking-wide">Name (As per UPI)</label>
                <input
                  type="text"
                  value={paymentInfo.upiName}
                  onChange={(e) => setPaymentInfo({...paymentInfo, upiName: e.target.value})}
                  className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
                  placeholder="Enter your full name"
                  required
                />
              </div>
              <div className="space-y-2">
                <label className="block text-sm font-bold text-gray-700 uppercase tracking-wide">
                  {paymentInfo.notificationPreference === 'whatsapp' ? 'WhatsApp Number' : 'Email Address'}
                </label>
                <input
                  type={paymentInfo.notificationPreference === 'whatsapp' ? 'tel' : 'email'}
                  value={paymentInfo.whatsappNumber}
                  onChange={(e) => setPaymentInfo({...paymentInfo, whatsappNumber: e.target.value})}
                  className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
                  placeholder={paymentInfo.notificationPreference === 'whatsapp' ? 'For payment proof' : 'For payment confirmation'}
                  required
                />
              </div>
              <div className="space-y-2">
                <label className="block text-sm font-bold text-gray-700 uppercase tracking-wide">Notification Preference</label>
                <div className="flex gap-4">
                  <button
                    type="button"
                    onClick={() => setPaymentInfo({...paymentInfo, notificationPreference: "whatsapp"})}
                    className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-2xl border-2 transition-all ${paymentInfo.notificationPreference === 'whatsapp' ? 'border-emerald-500 bg-emerald-50 text-emerald-700 font-bold' : 'border-gray-100 text-gray-500'}`}
                  >
                    <MessageSquare size={18} /> WhatsApp
                  </button>
                  <button
                    type="button"
                    onClick={() => setPaymentInfo({...paymentInfo, notificationPreference: "email"})}
                    className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-2xl border-2 transition-all ${paymentInfo.notificationPreference === 'email' ? 'border-emerald-500 bg-emerald-50 text-emerald-700 font-bold' : 'border-gray-100 text-gray-500'}`}
                  >
                    <Mail size={18} /> Email
                  </button>
                </div>
              </div>
              <div className="space-y-2">
                <label className="block text-sm font-bold text-gray-700 uppercase tracking-wide">UPI ID</label>
                <input
                  type="text"
                  value={paymentInfo.upiId}
                  onChange={(e) => setPaymentInfo({...paymentInfo, upiId: e.target.value})}
                  className="w-full px-4 py-3 border border-gray-200 rounded-2xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
                  placeholder="example@upi"
                  required
                />
              </div>
              <div className="md:col-span-2 space-y-4">
                <label className="block text-sm font-bold text-gray-700 uppercase tracking-wide">QR Code Image (Upload)</label>
                
                <div className="flex flex-col md:flex-row gap-6 items-start">
                  <div className="relative group">
                    <div className={`w-32 h-32 rounded-2xl border-2 border-dashed flex items-center justify-center overflow-hidden transition-all ${paymentInfo.qrUrl ? 'border-emerald-500 bg-emerald-50' : 'border-gray-300 bg-gray-50'}`}>
                      {paymentInfo.qrUrl ? (
                        <img src={paymentInfo.qrUrl} alt="QR Preview" className="w-full h-full object-contain" />
                      ) : (
                        <Upload size={32} className="text-gray-400" />
                      )}
                      
                      {uploading && (
                        <div className="absolute inset-0 bg-white/80 flex items-center justify-center backdrop-blur-sm">
                          <Loader2 className="animate-spin text-emerald-600" size={32} />
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="flex-1 space-y-3">
                    <div className="flex gap-2">
                      <label className={`cursor-pointer px-6 py-3 rounded-xl font-bold transition-all shadow-sm flex items-center gap-2 ${uploading ? 'bg-gray-100 text-gray-400 cursor-not-allowed' : 'bg-white border-2 border-emerald-600 text-emerald-600 hover:bg-emerald-50'}`}>
                        <Upload size={20} />
                        {paymentInfo.qrUrl ? 'Change Image' : 'Select Image'}
                        <input
                          type="file"
                          className="hidden"
                          accept="image/*"
                          onChange={handleImageUpload}
                          disabled={uploading}
                        />
                      </label>
                      
                      {paymentInfo.qrUrl && (
                        <button
                          type="button"
                          onClick={() => setPaymentInfo({...paymentInfo, qrUrl: ""})}
                          className="px-4 py-3 text-red-600 hover:bg-red-50 rounded-xl transition-colors font-medium"
                        >
                          Remove
                        </button>
                      )}
                    </div>
                    <p className="text-xs text-gray-500 font-medium">
                      <span className="text-emerald-600 font-bold">Recommended:</span> Select a clear image of your UPI QR Code. Max size 5MB.
                    </p>
                  </div>
                </div>

                {paymentInfo.qrUrl && (
                  <div className="space-y-2 pt-2">
                    <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest">Uploaded Image URL</label>
                    <input
                      type="url"
                      value={paymentInfo.qrUrl}
                      readOnly
                      className="w-full px-4 py-2 bg-gray-100 border border-gray-200 rounded-xl text-xs text-gray-500 outline-none"
                    />
                  </div>
                )}
              </div>
              <div className="md:col-span-2 pt-4">
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full bg-emerald-600 hover:bg-emerald-700 text-white py-4 rounded-2xl font-black text-lg shadow-lg shadow-emerald-100 transition-all flex items-center justify-center gap-2"
                >
                  <Save size={20} /> {loading ? "Saving..." : "Save Payment Information"}
                </button>
              </div>
            </form>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              <div className="space-y-1">
                <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">UPI Name</p>
                <p className="text-lg font-bold text-gray-900">{paymentInfo.upiName}</p>
              </div>
              <div className="space-y-1">
                <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">WhatsApp</p>
                <p className="text-lg font-bold text-gray-900">{paymentInfo.whatsappNumber}</p>
              </div>
              <div className="space-y-1">
                <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">UPI ID</p>
                <p className="text-lg font-bold text-emerald-600 font-mono">{paymentInfo.upiId}</p>
              </div>
              <div className="space-y-1">
                <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">Notifications</p>
                <p className="text-lg font-bold text-gray-900 capitalize">{paymentInfo.notificationPreference}</p>
              </div>
              <div className="lg:col-span-2 space-y-1">
                <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">QR Code URL</p>
                <div className="flex items-center gap-2">
                  <p className="text-sm font-medium text-gray-500 truncate flex-1">{paymentInfo.qrUrl}</p>
                  <button onClick={() => window.open(paymentInfo.qrUrl, '_blank')} className="p-2 text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors">
                    <Eye size={18} />
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Withdrawal Action */}
      {hasSavedPaymentInfo && !isEditingPayment && (
        <div className="flex justify-center">
          <button
            onClick={() => setIsWithdrawModalOpen(true)}
            className="bg-emerald-600 hover:bg-emerald-700 text-white px-12 py-5 rounded-3xl font-black text-xl shadow-xl shadow-emerald-100 transition-all transform hover:scale-105 flex items-center gap-3"
          >
            <WalletIcon size={24} /> Withdraw Funds
          </button>
        </div>
      )}

      {/* History Section */}
      <div className="bg-white rounded-3xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-gray-100 bg-gray-50/50">
          <h2 className="text-xl font-bold text-gray-900">Withdrawal History</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-4 text-left text-xs font-bold text-gray-500 uppercase tracking-widest">Withdrawal ID</th>
                <th className="px-6 py-4 text-left text-xs font-bold text-gray-500 uppercase tracking-widest">UPI ID</th>
                <th className="px-6 py-4 text-left text-xs font-bold text-gray-500 uppercase tracking-widest">Date & Time</th>
                <th className="px-6 py-4 text-center text-xs font-bold text-gray-500 uppercase tracking-widest">Status</th>
                <th className="px-6 py-4 text-right text-xs font-bold text-gray-500 uppercase tracking-widest">Amount</th>
                <th className="px-6 py-4 text-right text-xs font-bold text-gray-500 uppercase tracking-widest">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {withdrawals.map((w) => (
                <tr key={w.id} className="hover:bg-gray-50/50 transition-colors">
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-mono text-gray-400">#{w.id.slice(0, 8)}...</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{w.upiId}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{w.createdAt?.toDate().toLocaleString()}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-center">
                    <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider ${
                      w.status === 'Approved' ? 'bg-emerald-100 text-emerald-600' :
                      w.status === 'Rejected' ? 'bg-red-100 text-red-600' :
                      'bg-orange-100 text-orange-600'
                    }`}>
                      {w.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right font-black text-gray-900">₹{w.amount}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-right">
                    <button 
                      onClick={() => setSelectedWithdrawal(w)}
                      className="text-emerald-600 hover:bg-emerald-50 px-3 py-1 rounded-lg font-bold text-sm transition-colors"
                    >
                      Detail
                    </button>
                  </td>
                </tr>
              ))}
              {withdrawals.length === 0 && (
                <tr>
                  <td colSpan={6} className="px-6 py-12 text-center text-gray-500 font-medium">No withdrawal history found.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Withdraw Modal */}
      {isWithdrawModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="bg-white rounded-3xl shadow-2xl max-w-md w-full overflow-hidden animate-in zoom-in-95 duration-200">
            <div className="p-6 border-b border-gray-100 flex justify-between items-center">
              <h3 className="text-xl font-bold text-gray-900">Enter Amount</h3>
              <button onClick={() => setIsWithdrawModalOpen(false)} className="text-gray-400 hover:text-gray-600">
                <X size={24} />
              </button>
            </div>
            <form onSubmit={handleWithdrawRequest} className="p-8 space-y-6">
              <div className="space-y-2">
                <label className="block text-sm font-bold text-gray-500 uppercase tracking-widest">Withdrawal Amount (₹)</label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                    <span className="text-gray-400 font-bold text-xl">₹</span>
                  </div>
                  <input
                    type="number"
                    value={withdrawAmount}
                    onChange={(e) => setWithdrawAmount(e.target.value)}
                    className="w-full pl-10 pr-4 py-4 bg-gray-50 border border-gray-200 rounded-2xl text-2xl font-black focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
                    placeholder="0.00"
                    min={appSettings.minWithdrawal || 100}
                    step="1"
                    required
                  />
                </div>
                <p className="text-xs text-gray-400">Available: ₹{stats.availableBalance.toFixed(2)}</p>
              </div>

              <div className="bg-blue-50 p-4 rounded-2xl border border-blue-100 space-y-3">
                <div className="flex gap-3 text-blue-700">
                  <Info size={20} className="flex-shrink-0" />
                  <p className="text-sm font-medium leading-relaxed">
                    Minimum withdrawal is <span className="font-bold">₹100</span>. Please wait <span className="font-bold">24-36 hours</span> for the withdrawal to be processed to your account.
                  </p>
                </div>
                <div className="flex gap-3 text-blue-700">
                  <CheckCircle size={20} className="flex-shrink-0" />
                  <p className="text-sm font-medium leading-relaxed">
                    Payment proof will be sent to your <span className="font-bold">Email Address</span> if provided, or <span className="font-bold">WhatsApp Number</span> if provided.
                  </p>
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white py-4 rounded-2xl font-black text-lg shadow-lg shadow-emerald-100 transition-all"
              >
                {loading ? "Processing..." : "Confirm Withdrawal"}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Success Modal */}
      {isSuccessModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="bg-white rounded-[2.5rem] shadow-2xl max-w-md w-full p-10 text-center animate-in zoom-in-95 duration-300">
            <div className="w-24 h-24 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-8 animate-bounce">
              <Check size={48} strokeWidth={4} />
            </div>
            <h3 className="text-3xl font-black text-gray-900 mb-4 tracking-tight">Request Sent!</h3>
            <p className="text-gray-600 font-medium leading-relaxed mb-10">
              Thank you for using <span className="text-emerald-600 font-bold">Elite Links Count</span>. We appreciate your trust and hope you continue to grow with our platform. Your payment is being processed.
            </p>
            <button
              onClick={() => setIsSuccessModalOpen(false)}
              className="w-full bg-gray-900 hover:bg-black text-white py-4 rounded-2xl font-bold text-lg transition-all"
            >
              Close
            </button>
          </div>
        </div>
      )}

      {/* Detail Modal */}
      {selectedWithdrawal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="bg-white rounded-3xl shadow-2xl max-w-lg w-full overflow-hidden">
            <div className="p-6 border-b border-gray-100 flex justify-between items-center bg-gray-50/50">
              <h3 className="text-xl font-bold text-gray-900">Withdrawal Details</h3>
              <button onClick={() => setSelectedWithdrawal(null)} className="text-gray-400 hover:text-gray-600">
                <X size={24} />
              </button>
            </div>
            <div className="p-8 space-y-6">
              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-1">
                  <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">Status</p>
                  <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider ${
                    selectedWithdrawal.status === 'Approved' ? 'bg-emerald-100 text-emerald-600' :
                    selectedWithdrawal.status === 'Rejected' ? 'bg-red-100 text-red-600' :
                    'bg-orange-100 text-orange-600'
                  }`}>
                    {selectedWithdrawal.status}
                  </span>
                </div>
                <div className="space-y-1">
                  <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">Amount</p>
                  <p className="text-xl font-black text-gray-900">₹{selectedWithdrawal.amount}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">Date</p>
                  <p className="text-sm font-bold text-gray-700">{selectedWithdrawal.createdAt?.toDate().toLocaleDateString()}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">Time</p>
                  <p className="text-sm font-bold text-gray-700">{selectedWithdrawal.createdAt?.toDate().toLocaleTimeString()}</p>
                </div>
              </div>

              <div className="border-t border-gray-100 pt-6 space-y-4">
                <h4 className="font-bold text-gray-900 uppercase text-xs tracking-widest">Payment Destination</h4>
                <div className="bg-gray-50 p-4 rounded-2xl space-y-3">
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-500">UPI Name:</span>
                    <span className="text-sm font-bold text-gray-900">{selectedWithdrawal.paymentInfo?.upiName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-500">UPI ID:</span>
                    <span className="text-sm font-bold text-emerald-600 font-mono">{selectedWithdrawal.upiId}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-500">WhatsApp:</span>
                    <span className="text-sm font-bold text-gray-900">{selectedWithdrawal.paymentInfo?.whatsappNumber}</span>
                  </div>
                  {selectedWithdrawal.paymentInfo?.qrUrl && (
                    <div className="pt-2">
                      <p className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">QR Code</p>
                      <img 
                        src={selectedWithdrawal.paymentInfo.qrUrl} 
                        alt="Payment QR" 
                        className="w-32 h-32 object-contain border border-gray-200 rounded-xl bg-white p-1"
                        onError={(e) => (e.currentTarget.src = "https://via.placeholder.com/150?text=Invalid+QR+URL")}
                      />
                    </div>
                  )}
                </div>
              </div>

              {selectedWithdrawal.adminNote && (
                <div className="bg-orange-50 p-4 rounded-2xl border border-orange-100">
                  <p className="text-xs font-bold text-orange-700 uppercase tracking-widest mb-1">Admin Note</p>
                  <p className="text-sm text-orange-800 font-medium">{selectedWithdrawal.adminNote}</p>
                </div>
              )}

              <button
                onClick={() => setSelectedWithdrawal(null)}
                className="w-full bg-gray-100 hover:bg-gray-200 text-gray-900 py-3 rounded-xl font-bold transition-all"
              >
                Close Details
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
