import React from 'react';
import { FileText, CheckCircle, XCircle, AlertTriangle } from 'lucide-react';

export function Terms() {
  return (
    <div className="max-w-4xl mx-auto py-12 px-4 sm:px-6 lg:px-8 bg-white rounded-2xl shadow-sm border border-gray-200">
      <div className="text-center mb-12">
        <div className="mx-auto w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mb-4">
          <FileText className="h-8 w-8 text-emerald-600" />
        </div>
        <h1 className="text-3xl font-bold text-gray-900">Terms and Conditions</h1>
        <p className="text-gray-500 mt-2">Last updated: {new Date().toLocaleDateString()}</p>
      </div>

      <div className="space-y-8 text-gray-600">
        <section>
          <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
            <CheckCircle className="text-emerald-600" size={20} />
            Acceptance of Terms
          </h2>
          <p>
            By accessing or using our services, you agree to be bound by these Terms and Conditions. If you do not agree to all the terms and conditions, then you may not access the service.
          </p>
        </section>

        <section>
          <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
            <XCircle className="text-red-500" size={20} />
            Prohibited Uses
          </h2>
          <p>
            You may not use the Service for any illegal or unauthorized purpose. You must not, in the use of the Service, violate any laws in your jurisdiction (including but not limited to copyright laws).
          </p>
          <ul className="list-disc pl-5 mt-2 space-y-1">
            <li>Spamming or sending unsolicited messages.</li>
            <li>Distributing malware or viruses.</li>
            <li>Phishing or identity theft.</li>
            <li>Shortening URLs that redirect to illegal content.</li>
          </ul>
        </section>

        <section>
          <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
            <AlertTriangle className="text-yellow-500" size={20} />
            Disclaimer
          </h2>
          <p>
            The Service is provided on an "AS IS" and "AS AVAILABLE" basis. The Service is provided without warranties of any kind, whether express or implied, including, but not limited to, implied warranties of merchantability, fitness for a particular purpose, non-infringement or course of performance.
          </p>
        </section>

        <section>
          <h2 className="text-xl font-bold text-gray-900 mb-4">Changes to Terms</h2>
          <p>
            We reserve the right, at our sole discretion, to modify or replace these Terms at any time. If a revision is material we will try to provide at least 30 days notice prior to any new terms taking effect.
          </p>
        </section>

        <section>
          <h2 className="text-xl font-bold text-gray-900 mb-4">Contact Us</h2>
          <p>
            If you have any questions about these Terms, please contact us.
          </p>
        </section>
      </div>
    </div>
  );
}
