import React, { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { db } from "@/lib/firebase";
import { collection, query, where, getDocs, orderBy, deleteDoc, doc } from "firebase/firestore";
import { calculateEarnings } from "@/lib/utils";
import { BarChart2, TrendingUp, Calendar, Link as LinkIcon, Eye, IndianRupee, ChevronRight, Copy, Trash2, AlertTriangle } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import toast from "react-hot-toast";
import { DeleteConfirmModal } from "@/components/DeleteConfirmModal";

export function Analytics() {
  const { user, appSettings } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [links, setLinks] = useState<any[]>([]);
  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [linkToDelete, setLinkToDelete] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState("elite-hub");
  const [stats, setStats] = useState({
    lifetimeEarnings: 0,
    lifetimeViews: 0,
    todayEarnings: 0,
    todayViews: 0
  });

  useEffect(() => {
    if (user) {
      fetchAnalytics();
    }
  }, [user]);

  const fetchAnalytics = async () => {
    if (!user) return;
    try {
      const q = query(collection(db, "links"), where("userID", "==", user.uid));
      const querySnapshot = await getDocs(q);
      
      let totalViews = 0;
      let todayViews = 0;
      let totalEarnings = 0;
      let todayEarnings = 0;
      const today = new Date().toISOString().split('T')[0];
      
      const fetchedLinks = querySnapshot.docs.map(doc => {
        const data = doc.data();
        const linkCPM = data.cpm || appSettings.cpm;
        const linkTotalViews = data.totalClicks || 0;
        const linkTodayViews = data.dailyClicks?.[today] || 0;
        
        totalViews += linkTotalViews;
        todayViews += linkTodayViews;
        totalEarnings += calculateEarnings(linkTotalViews, linkCPM);
        todayEarnings += calculateEarnings(linkTodayViews, linkCPM);
        
        return { id: doc.id, ...data };
      });

      // Sort by date descending
      fetchedLinks.sort((a: any, b: any) => {
        const dateA = a.createdAt?.toMillis() || 0;
        const dateB = b.createdAt?.toMillis() || 0;
        return dateB - dateA;
      });

      setLinks(fetchedLinks);
      setStats({
        lifetimeEarnings: totalEarnings,
        lifetimeViews: totalViews,
        todayEarnings: todayEarnings,
        todayViews: todayViews
      });

    } catch (error) {
      console.error("Error fetching analytics:", error);
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = (e: React.MouseEvent, text: string) => {
    e.stopPropagation();
    navigator.clipboard.writeText(text);
    toast.success("Copied to clipboard!");
  };

  const handleDeleteClick = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    setLinkToDelete(id);
    setDeleteModalOpen(true);
  };

  const confirmDelete = async () => {
    if (!linkToDelete) return;
    try {
      await deleteDoc(doc(db, "links", linkToDelete));
      toast.success("Link deleted successfully");
      fetchAnalytics();
    } catch (error) {
      toast.error("Error deleting link");
    } finally {
      setLinkToDelete(null);
    }
  };

  const isExpired = (link: any) => {
    if (!link.createdAt) return false;
    const createdAt = link.createdAt.toMillis();
    const now = Date.now();
    const diffDays = (now - createdAt) / (1000 * 60 * 60 * 24);
    return diffDays > 30 && (link.totalClicks || 0) <= 400;
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-[50vh]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-600"></div>
      </div>
    );
  }

  const filteredLinks = links.filter((link) => {
    if (activeTab === "public") return !link.shortenerType || link.shortenerType === "public";
    return link.shortenerType === activeTab;
  });

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Analytics</h1>
        <p className="text-gray-500 mt-1">Track your links performance and earnings</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-emerald-100 text-emerald-600 rounded-xl">
              <IndianRupee size={24} />
            </div>
            <div>
              <p className="text-sm text-gray-500 font-medium">Lifetime Earnings</p>
              <h3 className="text-2xl font-bold text-gray-900">₹{stats.lifetimeEarnings.toFixed(2)}</h3>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-blue-100 text-blue-600 rounded-xl">
              <Eye size={24} />
            </div>
            <div>
              <p className="text-sm text-gray-500 font-medium">Lifetime Views</p>
              <h3 className="text-2xl font-bold text-gray-900">{stats.lifetimeViews}</h3>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-purple-100 text-purple-600 rounded-xl">
              <TrendingUp size={24} />
            </div>
            <div>
              <p className="text-sm text-gray-500 font-medium">Today's Earnings</p>
              <h3 className="text-2xl font-bold text-gray-900">₹{stats.todayEarnings.toFixed(2)}</h3>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-orange-100 text-orange-600 rounded-xl">
              <BarChart2 size={24} />
            </div>
            <div>
              <p className="text-sm text-gray-500 font-medium">Today's Views</p>
              <h3 className="text-2xl font-bold text-gray-900">{stats.todayViews}</h3>
            </div>
          </div>
        </div>
      </div>

      {/* Links List */}
      <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-lg font-bold text-gray-900 mb-4">Your Links</h2>
          
          <div className="flex overflow-x-auto border-b border-gray-200">
            {[
              { id: "elite-hub", label: "Elite Hub Shortener" },
              { id: "links-count", label: "Links Count" }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-6 py-3 text-sm font-medium whitespace-nowrap transition-colors border-b-2 ${
                  activeTab === tab.id
                    ? "border-emerald-600 text-emerald-600"
                    : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Link ID</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Original URL</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Ad Tier</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Views</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Earnings</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Action</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredLinks.map((link) => {
                let linkCPM = link.cpm;
                if (!linkCPM) {
                  if (link.shortenerType === "elite-hub") linkCPM = appSettings.cpmEliteHub || 500;
                  else if (link.shortenerType === "links-count") linkCPM = appSettings.cpmLinksCount || 500;
                  else linkCPM = appSettings.cpm || 500;
                }
                const expired = isExpired(link);
                const baseUrl = "https://elitelinkscount.netlify.app";
                const domain = "elitelinkscount.netlify.app";
                
                // elite-hub links have no prefix, links-count links have /links-count/ prefix
                const typePath = link.shortenerType === 'elite-hub' ? '' : link.shortenerType === 'links-count' ? 'links-count' : 'public';
                
                const shortUrl = typePath ? `${domain}/${typePath}/${link.linkID}` : `${domain}/${link.linkID}`;
                const fullShortUrl = typePath ? `${baseUrl}/${typePath}/${link.linkID}` : `${baseUrl}/${link.linkID}`;

                return (
                  <tr key={link.id} className={`hover:bg-gray-50 transition-colors cursor-pointer ${expired ? 'opacity-75' : ''}`} onClick={() => navigate(`/analytics/${link.linkID}`)}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center gap-2">
                        <LinkIcon size={16} className="text-gray-400" />
                        <span className={`font-medium ${expired ? 'text-gray-400' : 'text-emerald-600'}`}>{shortUrl}</span>
                        <button 
                          onClick={(e) => copyToClipboard(e, fullShortUrl)}
                          className="p-1 text-gray-400 hover:text-emerald-600 hover:bg-emerald-50 rounded transition-colors"
                          title="Copy Link"
                        >
                          <Copy size={14} />
                        </button>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="text-sm text-gray-900 truncate max-w-xs" title={link.originalURL}>
                        {link.originalURL}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center gap-2 text-sm text-gray-500">
                        <Calendar size={14} />
                        {link.createdAt?.toDate().toLocaleDateString()}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-center">
                      {expired ? (
                        <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-full bg-red-100 text-red-600 flex items-center gap-1 justify-center">
                          <AlertTriangle size={10} /> Expired
                        </span>
                      ) : (
                        <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-600">
                          Active
                        </span>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-center">
                      <span className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded-full ${
                        link.adTier === 'high' ? 'bg-red-100 text-red-600' :
                        link.adTier === 'medium' ? 'bg-blue-100 text-blue-600' :
                        'bg-gray-100 text-gray-600'
                      }`}>
                        {link.adTier || 'Standard'}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm text-gray-900 font-medium">
                      {link.totalClicks || 0}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm text-emerald-600 font-bold">
                      ₹{calculateEarnings(link.totalClicks || 0, linkCPM).toFixed(2)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm text-gray-400">
                      <div className="flex items-center justify-end gap-2">
                        <button 
                          onClick={(e) => handleDeleteClick(e, link.id)}
                          className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                          title="Delete Link"
                        >
                          <Trash2 size={18} />
                        </button>
                        <ChevronRight size={20} />
                      </div>
                    </td>
                  </tr>
                );
              })}
              {filteredLinks.length === 0 && (
                <tr>
                  <td colSpan={8} className="px-6 py-12 text-center text-gray-500">
                    No links generated yet.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      <DeleteConfirmModal 
        isOpen={deleteModalOpen}
        onClose={() => {
          setDeleteModalOpen(false);
          setLinkToDelete(null);
        }}
        onConfirm={confirmDelete}
      />
    </div>
  );
}
