import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { db } from "@/lib/firebase";
import { collection, query, getDocs, updateDoc, doc, orderBy, setDoc, getDoc } from "firebase/firestore";
import { Users, Link as LinkIcon, IndianRupee, Search, CheckCircle, XCircle, Copy, Maximize2, Settings, Save } from "lucide-react";
import { calculateEarnings } from "@/lib/utils";
import toast from "react-hot-toast";

import { ConfirmModal } from "@/components/ConfirmModal";

export function Admin() {
  const { isAdmin } = useAuth();
  const [activeTab, setActiveTab] = useState("dashboard");
  const [stats, setStats] = useState({ users: 0, links: 0, requests: 0 });
  const [users, setUsers] = useState<any[]>([]);
  const [requests, setRequests] = useState<any[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [loading, setLoading] = useState(true);
  const [fullscreenImage, setFullscreenImage] = useState<string | null>(null);
  const [adsSettings, setAdsSettings] = useState<any>({});
  const [urlSettings, setUrlSettings] = useState<any>({});
  const [appSettings, setAppSettings] = useState<any>({ 
    cpm: 500,
    cpmEliteHub: 500,
    cpmLinksCount: 500,
    minWithdrawal: 100,
    inviteShareUrl: "https://elite-links.com"
  });

  // Ad Config States
  const [bannerAdConfig, setBannerAdConfig] = useState({ type: 'script', client: '', slot: '' });
  const [nativeAdConfig, setNativeAdConfig] = useState({ type: 'script', client: '', slot: '' });

  // Elite Hub Ad Config States
  const [eliteBannerAd1Config, setEliteBannerAd1Config] = useState({ type: 'script', client: '', slot: '' });
  const [eliteBannerAd2Config, setEliteBannerAd2Config] = useState({ type: 'script', client: '', slot: '' });
  const [eliteNativeAd1Config, setEliteNativeAd1Config] = useState({ type: 'script', client: '', slot: '' });
  const [eliteNativeAd2Config, setEliteNativeAd2Config] = useState({ type: 'script', client: '', slot: '' });

  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    type: 'danger' | 'success' | 'warning' | 'info';
    onConfirm: () => void;
  }>({
    isOpen: false,
    title: "",
    message: "",
    type: "info",
    onConfirm: () => {},
  });

  const [links, setLinks] = useState<any[]>([]);
  const [paymentHistory, setPaymentHistory] = useState<any[]>([]);
  const [showPaymentHistory, setShowPaymentHistory] = useState(false);
  const [linkSearchQuery, setLinkSearchQuery] = useState("");
  const [paymentSearchQuery, setPaymentSearchQuery] = useState("");
  const [selectedLink, setSelectedLink] = useState<any | null>(null);
  const [editingUser, setEditingUser] = useState<any>(null);
  const [newBalance, setNewBalance] = useState("");

  useEffect(() => {
    if (isAdmin) {
      fetchData();
    }
  }, [isAdmin]);

  const handleUpdateBalance = async () => {
    if (!editingUser || !newBalance) return;
    try {
      await updateDoc(doc(db, "users", editingUser.id), { walletBalance: Number(newBalance) });
      toast.success("Balance updated successfully");
      setEditingUser(null);
      setNewBalance("");
      fetchData();
    } catch (error: any) {
      toast.error(error.message);
    }
  };

  const fetchData = async () => {
    try {
      // Fetch Stats
      const usersSnap = await getDocs(collection(db, "users"));
      const linksSnap = await getDocs(collection(db, "links"));
      const requestsSnap = await getDocs(collection(db, "withdrawals"));
      
      setStats({
        users: usersSnap.size,
        links: linksSnap.size,
        requests: requestsSnap.size,
      });

      // Fetch Users
      setUsers(usersSnap.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      
      // Fetch Links
      setLinks(linksSnap.docs.map(doc => ({ id: doc.id, ...doc.data() })));

      // Fetch Requests
      const allRequests = requestsSnap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      allRequests.sort((a: any, b: any) => {
        const dateA = a.createdAt?.toMillis() || 0;
        const dateB = b.createdAt?.toMillis() || 0;
        return dateB - dateA;
      });
      
      setRequests(allRequests.filter((r: any) => r.status === "Pending"));
      setPaymentHistory(allRequests.filter((r: any) => r.status !== "Pending"));

      // Fetch Settings
      const adsSnap = await getDoc(doc(db, "settings", "ads"));
      if (adsSnap.exists()) {
        const data = adsSnap.data();
        setAdsSettings(data);
        if (data.globalBannerAdConfig) setBannerAdConfig(data.globalBannerAdConfig);
        if (data.globalNativeAdConfig) setNativeAdConfig(data.globalNativeAdConfig);
        if (data.eliteBannerAd1Config) setEliteBannerAd1Config(data.eliteBannerAd1Config);
        if (data.eliteBannerAd2Config) setEliteBannerAd2Config(data.eliteBannerAd2Config);
        if (data.eliteNativeAd1Config) setEliteNativeAd1Config(data.eliteNativeAd1Config);
        if (data.eliteNativeAd2Config) setEliteNativeAd2Config(data.eliteNativeAd2Config);
      }

      const urlsSnap = await getDoc(doc(db, "settings", "urls"));
      if (urlsSnap.exists()) setUrlSettings(urlsSnap.data());

      const appSnap = await getDoc(doc(db, "settings", "app"));
      if (appSnap.exists()) {
        const data = appSnap.data();
        setAppSettings({
          cpm: data.cpm || 500,
          cpmEliteHub: data.cpmEliteHub || 500,
          cpmLinksCount: data.cpmLinksCount || 500,
          minWithdrawal: data.minWithdrawal || 100,
          inviteShareUrl: data.inviteShareUrl || "https://elite-links.com"
        });
      }

    } catch (error) {
      console.error("Error fetching admin data:", error);
    } finally {
      setLoading(false);
    }
  };

  const saveAppSetting = async (key: string, value: string | number) => {
    try {
      await setDoc(doc(db, "settings", "app"), { [key]: value }, { merge: true });
      setAppSettings((prev: any) => ({ ...prev, [key]: value }));
      toast.success(`${key} saved successfully`);
    } catch (error: any) {
      toast.error("Error saving setting");
    }
  };

  const generateGoogleAdScript = (client: string, slot: string) => {
    return `<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${client}"
     crossorigin="anonymous"></script>
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="${client}"
     data-ad-slot="${slot}"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>`;
  };

  const saveAdSetting = async (key: string, value: string, configKey?: string, configValue?: any) => {
    try {
      const updateData: any = { [key]: value };
      if (configKey && configValue) {
        updateData[configKey] = configValue;
      }
      
      await setDoc(doc(db, "settings", "ads"), updateData, { merge: true });
      setAdsSettings((prev: any) => ({ ...prev, ...updateData }));
      toast.success(`${key} saved successfully`);
    } catch (error: any) {
      toast.error("Error saving setting");
    }
  };

  const saveUrlSetting = async (key: string, value: string) => {
    try {
      await setDoc(doc(db, "settings", "urls"), { [key]: value }, { merge: true });
      setUrlSettings((prev: any) => ({ ...prev, [key]: value }));
      toast.success(`${key} saved successfully`);
    } catch (error: any) {
      toast.error("Error saving setting");
    }
  };


  const handleBlockUser = (userId: string, isBlocked: boolean) => {
    setConfirmModal({
      isOpen: true,
      title: isBlocked ? "Unblock User" : "Block User",
      message: `Are you sure you want to ${isBlocked ? 'unblock' : 'block'} this user?`,
      type: isBlocked ? "success" : "danger",
      onConfirm: async () => {
        try {
          await updateDoc(doc(db, "users", userId), { isBlocked: !isBlocked });
          toast.success(`User ${isBlocked ? 'unblocked' : 'blocked'} successfully`);
          fetchData();
        } catch (error: any) {
          toast.error(error.message);
        }
      }
    });
  };

  const handleApproveAdmin = (userId: string, isAdmin: boolean) => {
    setConfirmModal({
      isOpen: true,
      title: isAdmin ? "Remove Admin" : "Make Admin",
      message: `Are you sure you want to ${isAdmin ? 'remove' : 'grant'} admin access?`,
      type: isAdmin ? "danger" : "success",
      onConfirm: async () => {
        try {
          await updateDoc(doc(db, "users", userId), { isAdmin: !isAdmin });
          toast.success(`Admin access ${isAdmin ? 'removed' : 'granted'} successfully`);
          fetchData();
        } catch (error: any) {
          toast.error(error.message);
        }
      }
    });
  };

  const handleVerifyEliteHub = (userId: string, isVerified: boolean) => {
    setConfirmModal({
      isOpen: true,
      title: isVerified ? "Unverify User" : "Verify User",
      message: `Are you sure you want to ${isVerified ? 'unverify' : 'verify'} this user for Elite Hub Shortener?`,
      type: isVerified ? "warning" : "success",
      onConfirm: async () => {
        try {
          await updateDoc(doc(db, "users", userId), { isEliteHubVerified: !isVerified });
          toast.success(`Elite Hub Shortener ${isVerified ? 'unverified' : 'verified'} successfully`);
          fetchData();
        } catch (error: any) {
          toast.error(error.message);
        }
      }
    });
  };

  const handleVerifyLinksCount = (userId: string, isVerified: boolean) => {
    setConfirmModal({
      isOpen: true,
      title: isVerified ? "Unverify User" : "Verify User",
      message: `Are you sure you want to ${isVerified ? 'unverify' : 'verify'} this user for Links Count Shortener?`,
      type: isVerified ? "warning" : "success",
      onConfirm: async () => {
        try {
          await updateDoc(doc(db, "users", userId), { isLinksCountVerified: !isVerified });
          toast.success(`Links Count Shortener ${isVerified ? 'unverified' : 'verified'} successfully`);
          fetchData();
        } catch (error: any) {
          toast.error(error.message);
        }
      }
    });
  };

  const handleRequestStatus = (requestId: string, status: string) => {
    setConfirmModal({
      isOpen: true,
      title: `${status} Request`,
      message: `Are you sure you want to ${status.toLowerCase()} this request?`,
      type: status === 'Approved' ? "success" : "danger",
      onConfirm: async () => {
        try {
          await updateDoc(doc(db, "withdrawals", requestId), { status });
          toast.success(`Request ${status.toLowerCase()} successfully`);
          fetchData();
        } catch (error: any) {
          toast.error(error.message);
        }
      }
    });
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success("Copied to clipboard!");
  };

  const filteredUsers = users.filter(u => 
    u.email?.toLowerCase().includes(searchQuery.toLowerCase()) || 
    u.displayName?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredLinks = links.filter(l => 
    l.linkID?.toLowerCase().includes(linkSearchQuery.toLowerCase()) ||
    l.userEmail?.toLowerCase().includes(linkSearchQuery.toLowerCase()) ||
    l.userName?.toLowerCase().includes(linkSearchQuery.toLowerCase())
  );

  const filteredHistory = paymentHistory.filter(h => 
    h.userEmail?.toLowerCase().includes(paymentSearchQuery.toLowerCase()) ||
    h.upiId?.toLowerCase().includes(paymentSearchQuery.toLowerCase()) ||
    h.amount?.toString().includes(paymentSearchQuery) ||
    h.paymentInfo?.whatsappNumber?.includes(paymentSearchQuery)
  );

  if (!isAdmin) {
    return <div className="text-center py-12 text-red-600 font-bold">Access Denied. Admin only.</div>;
  }

  if (loading) {
    return <div className="flex justify-center items-center h-64">Loading Admin Panel...</div>;
  }

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Admin Panel</h1>
        <p className="text-gray-500 mt-1">Manage users, links, and payments</p>
      </div>

      {/* Tabs */}
      <div className="flex overflow-x-auto border-b border-gray-200">
        {["dashboard", "users", "links", "payments", "urls", "url-management", "ads", "elite-ads"].map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-6 py-3 font-medium text-sm capitalize whitespace-nowrap ${
              activeTab === tab
                ? "border-b-2 border-emerald-600 text-emerald-600"
                : "text-gray-500 hover:text-gray-700 hover:border-gray-300"
            }`}
          >
            {tab.replace("-", " ")}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      <div className="py-4">
        {activeTab === "dashboard" && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm flex items-center gap-4">
              <div className="p-3 bg-blue-50 rounded-xl text-blue-600"><Users size={24} /></div>
              <div>
                <div className="text-sm text-gray-500 font-medium">Total Users</div>
                <div className="text-2xl font-bold text-gray-900">{stats.users}</div>
              </div>
            </div>
            <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm flex items-center gap-4">
              <div className="p-3 bg-emerald-50 rounded-xl text-emerald-600"><LinkIcon size={24} /></div>
              <div>
                <div className="text-sm text-gray-500 font-medium">Total Links</div>
                <div className="text-2xl font-bold text-gray-900">{stats.links}</div>
              </div>
            </div>
            <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm flex items-center gap-4">
              <div className="p-3 bg-yellow-50 rounded-xl text-yellow-600"><IndianRupee size={24} /></div>
              <div>
                <div className="text-sm text-gray-500 font-medium">Pending Requests</div>
                <div className="text-2xl font-bold text-gray-900">{requests.length}</div>
              </div>
            </div>
          </div>
        )}

        {activeTab === "users" && (
          <div className="space-y-6">
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="text"
                placeholder="Search users by email or name..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-xl focus:ring-emerald-500 focus:border-emerald-500"
              />
            </div>

            <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">User</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Role</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Verifications</th>
                      <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {filteredUsers.map((u) => (
                      <tr key={u.id}>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <div className="flex-shrink-0 h-10 w-10">
                              <img className="h-10 w-10 rounded-full" src={u.photoURL || `https://ui-avatars.com/api/?name=${u.displayName || u.email}&background=10b981&color=fff`} alt="" />
                            </div>
                            <div className="ml-4">
                              <div className="text-sm font-medium text-gray-900">{u.displayName || 'No Name'}</div>
                              <div className="text-sm text-gray-500">{u.email}</div>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${u.isBlocked ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'}`}>
                            {u.isBlocked ? 'Blocked' : 'Active'}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {u.isAdmin ? 'Admin' : 'User'}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          <div className="flex flex-col gap-2">
                            <div className="flex items-center justify-between gap-2">
                              <span className="text-xs text-gray-500">Elite Hub:</span>
                              <button 
                                onClick={() => handleVerifyEliteHub(u.id, u.isEliteHubVerified)} 
                                className={`px-3 py-1 rounded-lg text-xs font-bold transition-colors ${u.isEliteHubVerified ? 'bg-green-100 text-green-700 hover:bg-green-200' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
                              >
                                {u.isEliteHubVerified ? 'Verified' : 'Verify'}
                              </button>
                            </div>
                            <div className="flex items-center justify-between gap-2">
                              <span className="text-xs text-gray-500">Links Count:</span>
                              <button 
                                onClick={() => handleVerifyLinksCount(u.id, u.isLinksCountVerified)} 
                                className={`px-3 py-1 rounded-lg text-xs font-bold transition-colors ${u.isLinksCountVerified ? 'bg-green-100 text-green-700 hover:bg-green-200' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
                              >
                                {u.isLinksCountVerified ? 'Verified' : 'Verify'}
                              </button>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium space-x-2">
                          <button onClick={() => handleBlockUser(u.id, u.isBlocked)} className={`${u.isBlocked ? 'text-emerald-600 hover:text-emerald-900' : 'text-red-600 hover:text-red-900'}`}>
                            {u.isBlocked ? 'Unblock' : 'Block'}
                          </button>
                          <span className="text-gray-300">|</span>
                          <button onClick={() => handleApproveAdmin(u.id, u.isAdmin)} className="text-blue-600 hover:text-blue-900">
                            {u.isAdmin ? 'Remove Admin' : 'Make Admin'}
                          </button>
                          <span className="text-gray-300">|</span>
                          <button 
                            onClick={() => {
                              setEditingUser(u);
                              setNewBalance(u.walletBalance?.toString() || "0");
                            }} 
                            className="text-purple-600 hover:text-purple-900"
                          >
                            Edit Balance
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {activeTab === "links" && (
          <div className="space-y-6">
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="text"
                placeholder="Search links by ID, user email, or name..."
                value={linkSearchQuery}
                onChange={(e) => setLinkSearchQuery(e.target.value)}
                className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-xl focus:ring-emerald-500 focus:border-emerald-500"
              />
            </div>

            <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Link ID</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">User</th>
                      <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Views</th>
                      <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Earnings</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Created At</th>
                      <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Action</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {filteredLinks.map((l) => (
                      <tr key={l.id}>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-mono text-gray-900">#{l.linkID}</td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm font-medium text-gray-900">{l.userName || 'Unknown'}</div>
                          <div className="text-sm text-gray-500">{l.userEmail}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-right text-sm text-gray-900 font-bold">{l.totalClicks || 0}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-right text-sm text-emerald-600 font-bold">₹{calculateEarnings(l.totalClicks || 0, l.cpm || appSettings.cpm).toFixed(2)}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {l.createdAt?.toDate().toLocaleString()}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                          <button onClick={() => setSelectedLink(l)} className="text-emerald-600 hover:text-emerald-900">Detail</button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {activeTab === "payments" && (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-bold text-gray-900">{showPaymentHistory ? "Payment History" : "Pending Requests"}</h2>
              <button 
                onClick={() => setShowPaymentHistory(!showPaymentHistory)}
                className="bg-emerald-600 text-white px-4 py-2 rounded-xl font-bold text-sm hover:bg-emerald-700 transition-colors"
              >
                {showPaymentHistory ? "View Pending" : "View History"}
              </button>
            </div>

            {showPaymentHistory && (
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="text"
                  placeholder="Search history by email, amount, UPI ID, or WhatsApp..."
                  value={paymentSearchQuery}
                  onChange={(e) => setPaymentSearchQuery(e.target.value)}
                  className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-xl focus:ring-emerald-500 focus:border-emerald-500"
                />
              </div>
            )}

            <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">User Details</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Amount</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Contact Info</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">UPI / QR</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                      {!showPaymentHistory && <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>}
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {(showPaymentHistory ? filteredHistory : requests).map((r) => (
                      <tr key={r.id}>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm font-bold text-gray-900">{r.userName}</div>
                          <div className="text-xs text-gray-500">{r.userEmail}</div>
                          <div className="text-[10px] text-gray-400 font-mono">ID: {r.id}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm font-black text-emerald-600">₹{r.amount}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-xs font-bold text-gray-700">
                            {r.paymentInfo?.notificationPreference === 'whatsapp' ? 'WhatsApp: ' : 'Email: '}
                            <span className="font-medium text-gray-500">{r.paymentInfo?.whatsappNumber}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-mono text-gray-500">{r.upiId}</span>
                            <button onClick={() => copyToClipboard(r.upiId)} className="text-gray-400 hover:text-emerald-600"><Copy size={12} /></button>
                          </div>
                          {r.paymentInfo?.qrUrl && (
                            <button onClick={() => setFullscreenImage(r.paymentInfo.qrUrl)} className="mt-1 flex items-center gap-1 text-[10px] text-blue-600 hover:text-blue-800 font-bold uppercase">
                              <Maximize2 size={10} /> View QR
                            </button>
                          )}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-xs text-gray-500">
                          {r.createdAt?.toDate().toLocaleString()}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`px-2 py-0.5 inline-flex text-[10px] leading-5 font-black rounded-full uppercase tracking-wider ${
                            r.status === 'Approved' ? 'bg-green-100 text-green-800' :
                            r.status === 'Rejected' ? 'bg-red-100 text-red-800' :
                            'bg-yellow-100 text-yellow-800'
                          }`}>
                            {r.status}
                          </span>
                        </td>
                        {!showPaymentHistory && (
                          <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium space-x-2">
                            <button onClick={() => handleRequestStatus(r.id, 'Approved')} className="text-emerald-600 hover:text-emerald-900 font-bold">Approve</button>
                            <span className="text-gray-300">|</span>
                            <button onClick={() => handleRequestStatus(r.id, 'Rejected')} className="text-red-600 hover:text-red-900 font-bold">Reject</button>
                          </td>
                        )}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {activeTab === "urls" && (
          <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm space-y-6">
            <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2"><Settings size={20} className="text-emerald-600" /> App Settings</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-6 col-span-1 md:col-span-2 p-6 bg-blue-50 rounded-2xl border border-blue-100">
                <h3 className="font-bold text-blue-900 text-lg">Global Settings</h3>
                <div className="space-y-2">
                  <label className="block text-sm font-medium text-blue-800">Your Website URL</label>
                  <p className="text-xs text-blue-600 mb-2">This URL will be used as the base domain for all generated short links.</p>
                  <div className="flex gap-2">
                    <input
                      type="url"
                      className="flex-1 p-3 border border-blue-200 rounded-xl focus:ring-blue-500 focus:border-blue-500"
                      placeholder="https://yourwebsite.com"
                      value={appSettings.websiteUrl || ""}
                      onChange={(e) => setAppSettings({ ...appSettings, websiteUrl: e.target.value })}
                    />
                    <button 
                      onClick={() => saveAppSetting("websiteUrl", appSettings.websiteUrl)}
                      className="bg-blue-600 text-white px-4 py-2 rounded-xl font-medium hover:bg-blue-700"
                    >
                      Save
                    </button>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="block text-sm font-medium text-blue-800">Minimum Withdrawal Amount (₹)</label>
                  <div className="flex gap-2">
                    <input
                      type="number"
                      className="flex-1 p-3 border border-blue-200 rounded-xl focus:ring-blue-500 focus:border-blue-500"
                      placeholder="100"
                      value={appSettings.minWithdrawal}
                      onChange={(e) => setAppSettings({ ...appSettings, minWithdrawal: Number(e.target.value) })}
                    />
                    <button 
                      onClick={() => saveAppSetting("minWithdrawal", appSettings.minWithdrawal)}
                      className="bg-blue-600 text-white px-4 py-2 rounded-xl font-medium hover:bg-blue-700"
                    >
                      Save
                    </button>
                  </div>
                </div>
              </div>

              <div className="space-y-6 col-span-1 md:col-span-2 p-6 bg-emerald-50 rounded-2xl border border-emerald-100">
                <h3 className="font-bold text-emerald-900 text-lg">Earnings per 1000 Views (CPM in ₹)</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="space-y-2">
                    <label className="block text-sm font-medium text-emerald-800">Links Count CPM</label>
                    <div className="flex gap-2">
                      <input
                        type="number"
                        className="flex-1 p-3 border border-emerald-200 rounded-xl focus:ring-emerald-500 focus:border-emerald-500"
                        placeholder="500"
                        value={appSettings.cpmLinksCount}
                        onChange={(e) => setAppSettings({ ...appSettings, cpmLinksCount: Number(e.target.value) })}
                      />
                      <button 
                        onClick={() => saveAppSetting("cpmLinksCount", appSettings.cpmLinksCount)}
                        className="bg-emerald-600 text-white px-3 py-2 rounded-xl font-medium hover:bg-emerald-700"
                      >
                        Save
                      </button>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="block text-sm font-medium text-emerald-800">Elite Hub CPM</label>
                    <div className="flex gap-2">
                      <input
                        type="number"
                        className="flex-1 p-3 border border-emerald-200 rounded-xl focus:ring-emerald-500 focus:border-emerald-500"
                        placeholder="500"
                        value={appSettings.cpmEliteHub}
                        onChange={(e) => setAppSettings({ ...appSettings, cpmEliteHub: Number(e.target.value) })}
                      />
                      <button 
                        onClick={() => saveAppSetting("cpmEliteHub", appSettings.cpmEliteHub)}
                        className="bg-emerald-600 text-white px-3 py-2 rounded-xl font-medium hover:bg-emerald-700"
                      >
                        Save
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === "url-management" && (
          <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm space-y-6">
            <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2"><Settings size={20} className="text-emerald-600" /> URL Management</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {[
                "privacyPolicy", 
                "useAndCondition", 
                "paymentIssue", 
                "websiteAdsProblem", 
                "adsCookies", 
                "websiteProblem", 
                "feedback", 
                "contactAdmin",
                "telegramChannel", 
                "telegramGroup", 
                "whatsappChannel", 
                "instagramChannel",
                "inviteShareUrl"
              ].map((urlType) => (
                <div key={urlType} className="space-y-2">
                  <div className="flex justify-between items-center">
                    <label className="block text-sm font-medium text-gray-700 capitalize">{urlType.replace(/([A-Z])/g, ' $1').trim()} URL</label>
                    <button 
                      onClick={() => saveUrlSetting(urlType, urlSettings[urlType])}
                      className="text-sm bg-emerald-50 text-emerald-600 px-3 py-1 rounded-lg font-medium hover:bg-emerald-100 flex items-center gap-1"
                    >
                      <Save size={14} /> Save
                    </button>
                  </div>
                  <input
                    type="url"
                    className="w-full p-3 border border-gray-300 rounded-xl focus:ring-emerald-500 focus:border-emerald-500"
                    placeholder={`https://example.com/${urlType.toLowerCase()}`}
                    value={urlSettings[urlType] || ""}
                    onChange={(e) => setUrlSettings({ ...urlSettings, [urlType]: e.target.value })}
                  />
                </div>
              ))}
            </div>
          </div>
        )}
        {activeTab === "ads" && (
          <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm space-y-6">
            <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2"><Settings size={20} className="text-emerald-600" /> Ad Scripts Management</h2>
            
            <div className="grid grid-cols-1 gap-6">
              <div className="border-b border-gray-100 pb-4">
                <h3 className="text-lg font-bold text-gray-900 mb-2">Global Ad Scripts</h3>
                <p className="text-xs text-gray-500">These scripts will be used for all banner and native ad placements across all redirect pages.</p>
              </div>

              {/* Global Banner Ad Section */}
              <div className="space-y-4 p-4 bg-gray-50 rounded-2xl border border-gray-200">
                <div className="flex justify-between items-center">
                  <label className="block text-sm font-bold text-gray-900">Global Banner Ad</label>
                  <div className="flex bg-white rounded-lg p-1 border border-gray-200">
                    <button
                      onClick={() => setBannerAdConfig({ ...bannerAdConfig, type: 'script' })}
                      className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${bannerAdConfig.type === 'script' ? 'bg-emerald-100 text-emerald-700' : 'text-gray-500 hover:bg-gray-50'}`}
                    >
                      Custom Script
                    </button>
                    <button
                      onClick={() => setBannerAdConfig({ ...bannerAdConfig, type: 'google' })}
                      className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${bannerAdConfig.type === 'google' ? 'bg-emerald-100 text-emerald-700' : 'text-gray-500 hover:bg-gray-50'}`}
                    >
                      Google Ad Unit
                    </button>
                  </div>
                </div>

                {bannerAdConfig.type === 'script' ? (
                  <textarea
                    className="w-full p-3 border border-gray-300 rounded-xl focus:ring-emerald-500 focus:border-emerald-500 font-mono text-sm h-32"
                    placeholder="Paste banner ad script here..."
                    value={adsSettings.globalBannerAd || ""}
                    onChange={(e) => setAdsSettings({ ...adsSettings, globalBannerAd: e.target.value })}
                  />
                ) : (
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="text-xs font-medium text-gray-500">Publisher ID (e.g., ca-pub-xxx)</label>
                      <input
                        type="text"
                        className="w-full p-2 border border-gray-300 rounded-lg focus:ring-emerald-500 focus:border-emerald-500 text-sm"
                        placeholder="ca-pub-0000000000000000"
                        value={bannerAdConfig.client}
                        onChange={(e) => setBannerAdConfig({ ...bannerAdConfig, client: e.target.value })}
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-xs font-medium text-gray-500">Ad Slot ID (e.g., 1234567890)</label>
                      <input
                        type="text"
                        className="w-full p-2 border border-gray-300 rounded-lg focus:ring-emerald-500 focus:border-emerald-500 text-sm"
                        placeholder="1234567890"
                        value={bannerAdConfig.slot}
                        onChange={(e) => setBannerAdConfig({ ...bannerAdConfig, slot: e.target.value })}
                      />
                    </div>
                  </div>
                )}

                <div className="flex justify-end">
                  <button 
                    onClick={() => {
                      let value = adsSettings.globalBannerAd;
                      if (bannerAdConfig.type === 'google') {
                        if (!bannerAdConfig.client || !bannerAdConfig.slot) return toast.error("Please enter Publisher ID and Slot ID");
                        value = generateGoogleAdScript(bannerAdConfig.client, bannerAdConfig.slot);
                      }
                      saveAdSetting("globalBannerAd", value, "globalBannerAdConfig", bannerAdConfig);
                    }}
                    className="text-sm bg-emerald-600 text-white px-4 py-2 rounded-xl font-medium hover:bg-emerald-700 flex items-center gap-2"
                  >
                    <Save size={16} /> Save Banner Ad
                  </button>
                </div>
              </div>

              {/* Global Native Ad Section */}
              <div className="space-y-4 p-4 bg-gray-50 rounded-2xl border border-gray-200">
                <div className="flex justify-between items-center">
                  <label className="block text-sm font-bold text-gray-900">Global Native Ad</label>
                  <div className="flex bg-white rounded-lg p-1 border border-gray-200">
                    <button
                      onClick={() => setNativeAdConfig({ ...nativeAdConfig, type: 'script' })}
                      className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${nativeAdConfig.type === 'script' ? 'bg-emerald-100 text-emerald-700' : 'text-gray-500 hover:bg-gray-50'}`}
                    >
                      Custom Script
                    </button>
                    <button
                      onClick={() => setNativeAdConfig({ ...nativeAdConfig, type: 'google' })}
                      className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${nativeAdConfig.type === 'google' ? 'bg-emerald-100 text-emerald-700' : 'text-gray-500 hover:bg-gray-50'}`}
                    >
                      Google Ad Unit
                    </button>
                  </div>
                </div>

                {nativeAdConfig.type === 'script' ? (
                  <textarea
                    className="w-full p-3 border border-gray-300 rounded-xl focus:ring-emerald-500 focus:border-emerald-500 font-mono text-sm h-32"
                    placeholder="Paste native ad script here..."
                    value={adsSettings.globalNativeAd || ""}
                    onChange={(e) => setAdsSettings({ ...adsSettings, globalNativeAd: e.target.value })}
                  />
                ) : (
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="text-xs font-medium text-gray-500">Publisher ID (e.g., ca-pub-xxx)</label>
                      <input
                        type="text"
                        className="w-full p-2 border border-gray-300 rounded-lg focus:ring-emerald-500 focus:border-emerald-500 text-sm"
                        placeholder="ca-pub-0000000000000000"
                        value={nativeAdConfig.client}
                        onChange={(e) => setNativeAdConfig({ ...nativeAdConfig, client: e.target.value })}
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-xs font-medium text-gray-500">Ad Slot ID (e.g., 1234567890)</label>
                      <input
                        type="text"
                        className="w-full p-2 border border-gray-300 rounded-lg focus:ring-emerald-500 focus:border-emerald-500 text-sm"
                        placeholder="1234567890"
                        value={nativeAdConfig.slot}
                        onChange={(e) => setNativeAdConfig({ ...nativeAdConfig, slot: e.target.value })}
                      />
                    </div>
                  </div>
                )}

                <div className="flex justify-end">
                  <button 
                    onClick={() => {
                      let value = adsSettings.globalNativeAd;
                      if (nativeAdConfig.type === 'google') {
                        if (!nativeAdConfig.client || !nativeAdConfig.slot) return toast.error("Please enter Publisher ID and Slot ID");
                        value = generateGoogleAdScript(nativeAdConfig.client, nativeAdConfig.slot);
                      }
                      saveAdSetting("globalNativeAd", value, "globalNativeAdConfig", nativeAdConfig);
                    }}
                    className="text-sm bg-emerald-600 text-white px-4 py-2 rounded-xl font-medium hover:bg-emerald-700 flex items-center gap-2"
                  >
                    <Save size={16} /> Save Native Ad
                  </button>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <label className="block text-sm font-medium text-gray-700">Social Bar Ad Script</label>
                  <button 
                    onClick={() => saveAdSetting("socialBarAd", adsSettings.socialBarAd)}
                    className="text-sm bg-emerald-50 text-emerald-600 px-3 py-1 rounded-lg font-medium hover:bg-emerald-100 flex items-center gap-1"
                  >
                    <Save size={14} /> Save
                  </button>
                </div>
                <textarea
                  className="w-full p-3 border border-gray-300 rounded-xl focus:ring-emerald-500 focus:border-emerald-500 font-mono text-sm h-32"
                  placeholder="Paste Social Bar ad script here..."
                  value={adsSettings.socialBarAd || ""}
                  onChange={(e) => setAdsSettings({ ...adsSettings, socialBarAd: e.target.value })}
                />
              </div>

              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <label className="block text-sm font-medium text-gray-700">Popunder Ad Script</label>
                  <button 
                    onClick={() => saveAdSetting("popunderAd", adsSettings.popunderAd)}
                    className="text-sm bg-emerald-50 text-emerald-600 px-3 py-1 rounded-lg font-medium hover:bg-emerald-100 flex items-center gap-1"
                  >
                    <Save size={14} /> Save
                  </button>
                </div>
                <textarea
                  className="w-full p-3 border border-gray-300 rounded-xl focus:ring-emerald-500 focus:border-emerald-500 font-mono text-sm h-32"
                  placeholder="Paste Popunder ad script here..."
                  value={adsSettings.popunderAd || ""}
                  onChange={(e) => setAdsSettings({ ...adsSettings, popunderAd: e.target.value })}
                />
              </div>

              <div className="border-t border-gray-200 pt-6 mt-2">
                <h3 className="text-lg font-bold text-gray-900 mb-4">Redirect Page Customization</h3>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <label className="block text-sm font-medium text-gray-700">Redirect Page Details Text</label>
                  <button 
                    onClick={() => saveAdSetting("redirectDetails", adsSettings.redirectDetails)}
                    className="text-sm bg-emerald-50 text-emerald-600 px-3 py-1 rounded-lg font-medium hover:bg-emerald-100 flex items-center gap-1"
                  >
                    <Save size={14} /> Save
                  </button>
                </div>
                <textarea
                  className="w-full p-3 border border-gray-300 rounded-xl focus:ring-emerald-500 focus:border-emerald-500 text-sm h-32"
                  placeholder="Enter the details text to show on the redirect page..."
                  value={adsSettings.redirectDetails || ""}
                  onChange={(e) => setAdsSettings({ ...adsSettings, redirectDetails: e.target.value })}
                />
              </div>

              <div className="border-t border-gray-200 pt-6 mt-2">
                <h3 className="text-lg font-bold text-gray-900 mb-4">Direct Links (Individual per Shortener)</h3>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <label className="block text-sm font-medium text-gray-700">Links Count Direct Link</label>
                  <button 
                    onClick={() => saveAdSetting("linksCountDirectLink", adsSettings.linksCountDirectLink)}
                    className="text-sm bg-emerald-50 text-emerald-600 px-3 py-1 rounded-lg font-medium hover:bg-emerald-100 flex items-center gap-1"
                  >
                    <Save size={14} /> Save
                  </button>
                </div>
                <input
                  type="url"
                  className="w-full p-3 border border-gray-300 rounded-xl focus:ring-emerald-500 focus:border-emerald-500"
                  placeholder="https://example.com/direct-link"
                  value={adsSettings.linksCountDirectLink || ""}
                  onChange={(e) => setAdsSettings({ ...adsSettings, linksCountDirectLink: e.target.value })}
                />
              </div>
            </div>
          </div>
        )}

        {activeTab === "elite-ads" && (
          <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm space-y-6">
            <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2"><Settings size={20} className="text-emerald-600" /> Elite Hub Ad Management</h2>
            
            <div className="grid grid-cols-1 gap-6">
              <div className="border-b border-gray-100 pb-4">
                <h3 className="text-lg font-bold text-gray-900 mb-2">Elite Hub Specific Ads</h3>
                <p className="text-xs text-gray-500">These scripts will be used exclusively for the Elite Hub Redirect page. The system will alternate between Script 1 and Script 2.</p>
              </div>

              {/* Elite Banner Ad 1 */}
              <div className="space-y-4 p-4 bg-gray-50 rounded-2xl border border-gray-200">
                <div className="flex justify-between items-center">
                  <label className="block text-sm font-bold text-gray-900">Elite Banner Ad Script 1</label>
                  <div className="flex bg-white rounded-lg p-1 border border-gray-200">
                    <button
                      onClick={() => setEliteBannerAd1Config({ ...eliteBannerAd1Config, type: 'script' })}
                      className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${eliteBannerAd1Config.type === 'script' ? 'bg-emerald-100 text-emerald-700' : 'text-gray-500 hover:bg-gray-50'}`}
                    >
                      Custom Script
                    </button>
                    <button
                      onClick={() => setEliteBannerAd1Config({ ...eliteBannerAd1Config, type: 'google' })}
                      className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${eliteBannerAd1Config.type === 'google' ? 'bg-emerald-100 text-emerald-700' : 'text-gray-500 hover:bg-gray-50'}`}
                    >
                      Google Ad Unit
                    </button>
                  </div>
                </div>

                {eliteBannerAd1Config.type === 'script' ? (
                  <textarea
                    className="w-full p-3 border border-gray-300 rounded-xl focus:ring-emerald-500 focus:border-emerald-500 font-mono text-sm h-32"
                    placeholder="Paste banner ad script 1 here..."
                    value={adsSettings.eliteBannerAd1 || ""}
                    onChange={(e) => setAdsSettings({ ...adsSettings, eliteBannerAd1: e.target.value })}
                  />
                ) : (
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="text-xs font-medium text-gray-500">Publisher ID</label>
                      <input
                        type="text"
                        className="w-full p-2 border border-gray-300 rounded-lg focus:ring-emerald-500 focus:border-emerald-500 text-sm"
                        placeholder="ca-pub-xxx"
                        value={eliteBannerAd1Config.client}
                        onChange={(e) => setEliteBannerAd1Config({ ...eliteBannerAd1Config, client: e.target.value })}
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-xs font-medium text-gray-500">Ad Slot ID</label>
                      <input
                        type="text"
                        className="w-full p-2 border border-gray-300 rounded-lg focus:ring-emerald-500 focus:border-emerald-500 text-sm"
                        placeholder="1234567890"
                        value={eliteBannerAd1Config.slot}
                        onChange={(e) => setEliteBannerAd1Config({ ...eliteBannerAd1Config, slot: e.target.value })}
                      />
                    </div>
                  </div>
                )}
                <div className="flex justify-end">
                  <button 
                    onClick={() => {
                      let value = adsSettings.eliteBannerAd1;
                      if (eliteBannerAd1Config.type === 'google') {
                        if (!eliteBannerAd1Config.client || !eliteBannerAd1Config.slot) return toast.error("Please enter Publisher ID and Slot ID");
                        value = generateGoogleAdScript(eliteBannerAd1Config.client, eliteBannerAd1Config.slot);
                      }
                      saveAdSetting("eliteBannerAd1", value, "eliteBannerAd1Config", eliteBannerAd1Config);
                    }}
                    className="text-sm bg-emerald-600 text-white px-4 py-2 rounded-xl font-medium hover:bg-emerald-700 flex items-center gap-2"
                  >
                    <Save size={16} /> Save Script 1
                  </button>
                </div>
              </div>

              {/* Elite Banner Ad 2 */}
              <div className="space-y-4 p-4 bg-gray-50 rounded-2xl border border-gray-200">
                <div className="flex justify-between items-center">
                  <label className="block text-sm font-bold text-gray-900">Elite Banner Ad Script 2</label>
                  <div className="flex bg-white rounded-lg p-1 border border-gray-200">
                    <button
                      onClick={() => setEliteBannerAd2Config({ ...eliteBannerAd2Config, type: 'script' })}
                      className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${eliteBannerAd2Config.type === 'script' ? 'bg-emerald-100 text-emerald-700' : 'text-gray-500 hover:bg-gray-50'}`}
                    >
                      Custom Script
                    </button>
                    <button
                      onClick={() => setEliteBannerAd2Config({ ...eliteBannerAd2Config, type: 'google' })}
                      className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${eliteBannerAd2Config.type === 'google' ? 'bg-emerald-100 text-emerald-700' : 'text-gray-500 hover:bg-gray-50'}`}
                    >
                      Google Ad Unit
                    </button>
                  </div>
                </div>

                {eliteBannerAd2Config.type === 'script' ? (
                  <textarea
                    className="w-full p-3 border border-gray-300 rounded-xl focus:ring-emerald-500 focus:border-emerald-500 font-mono text-sm h-32"
                    placeholder="Paste banner ad script 2 here..."
                    value={adsSettings.eliteBannerAd2 || ""}
                    onChange={(e) => setAdsSettings({ ...adsSettings, eliteBannerAd2: e.target.value })}
                  />
                ) : (
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="text-xs font-medium text-gray-500">Publisher ID</label>
                      <input
                        type="text"
                        className="w-full p-2 border border-gray-300 rounded-lg focus:ring-emerald-500 focus:border-emerald-500 text-sm"
                        placeholder="ca-pub-xxx"
                        value={eliteBannerAd2Config.client}
                        onChange={(e) => setEliteBannerAd2Config({ ...eliteBannerAd2Config, client: e.target.value })}
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-xs font-medium text-gray-500">Ad Slot ID</label>
                      <input
                        type="text"
                        className="w-full p-2 border border-gray-300 rounded-lg focus:ring-emerald-500 focus:border-emerald-500 text-sm"
                        placeholder="1234567890"
                        value={eliteBannerAd2Config.slot}
                        onChange={(e) => setEliteBannerAd2Config({ ...eliteBannerAd2Config, slot: e.target.value })}
                      />
                    </div>
                  </div>
                )}
                <div className="flex justify-end">
                  <button 
                    onClick={() => {
                      let value = adsSettings.eliteBannerAd2;
                      if (eliteBannerAd2Config.type === 'google') {
                        if (!eliteBannerAd2Config.client || !eliteBannerAd2Config.slot) return toast.error("Please enter Publisher ID and Slot ID");
                        value = generateGoogleAdScript(eliteBannerAd2Config.client, eliteBannerAd2Config.slot);
                      }
                      saveAdSetting("eliteBannerAd2", value, "eliteBannerAd2Config", eliteBannerAd2Config);
                    }}
                    className="text-sm bg-emerald-600 text-white px-4 py-2 rounded-xl font-medium hover:bg-emerald-700 flex items-center gap-2"
                  >
                    <Save size={16} /> Save Script 2
                  </button>
                </div>
              </div>

              {/* Elite Native Ad 1 */}
              <div className="space-y-4 p-4 bg-gray-50 rounded-2xl border border-gray-200">
                <div className="flex justify-between items-center">
                  <label className="block text-sm font-bold text-gray-900">Elite Native Ad Script 1</label>
                  <div className="flex bg-white rounded-lg p-1 border border-gray-200">
                    <button
                      onClick={() => setEliteNativeAd1Config({ ...eliteNativeAd1Config, type: 'script' })}
                      className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${eliteNativeAd1Config.type === 'script' ? 'bg-emerald-100 text-emerald-700' : 'text-gray-500 hover:bg-gray-50'}`}
                    >
                      Custom Script
                    </button>
                    <button
                      onClick={() => setEliteNativeAd1Config({ ...eliteNativeAd1Config, type: 'google' })}
                      className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${eliteNativeAd1Config.type === 'google' ? 'bg-emerald-100 text-emerald-700' : 'text-gray-500 hover:bg-gray-50'}`}
                    >
                      Google Ad Unit
                    </button>
                  </div>
                </div>

                {eliteNativeAd1Config.type === 'script' ? (
                  <textarea
                    className="w-full p-3 border border-gray-300 rounded-xl focus:ring-emerald-500 focus:border-emerald-500 font-mono text-sm h-32"
                    placeholder="Paste native ad script 1 here..."
                    value={adsSettings.eliteNativeAd1 || ""}
                    onChange={(e) => setAdsSettings({ ...adsSettings, eliteNativeAd1: e.target.value })}
                  />
                ) : (
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="text-xs font-medium text-gray-500">Publisher ID</label>
                      <input
                        type="text"
                        className="w-full p-2 border border-gray-300 rounded-lg focus:ring-emerald-500 focus:border-emerald-500 text-sm"
                        placeholder="ca-pub-xxx"
                        value={eliteNativeAd1Config.client}
                        onChange={(e) => setEliteNativeAd1Config({ ...eliteNativeAd1Config, client: e.target.value })}
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-xs font-medium text-gray-500">Ad Slot ID</label>
                      <input
                        type="text"
                        className="w-full p-2 border border-gray-300 rounded-lg focus:ring-emerald-500 focus:border-emerald-500 text-sm"
                        placeholder="1234567890"
                        value={eliteNativeAd1Config.slot}
                        onChange={(e) => setEliteNativeAd1Config({ ...eliteNativeAd1Config, slot: e.target.value })}
                      />
                    </div>
                  </div>
                )}
                <div className="flex justify-end">
                  <button 
                    onClick={() => {
                      let value = adsSettings.eliteNativeAd1;
                      if (eliteNativeAd1Config.type === 'google') {
                        if (!eliteNativeAd1Config.client || !eliteNativeAd1Config.slot) return toast.error("Please enter Publisher ID and Slot ID");
                        value = generateGoogleAdScript(eliteNativeAd1Config.client, eliteNativeAd1Config.slot);
                      }
                      saveAdSetting("eliteNativeAd1", value, "eliteNativeAd1Config", eliteNativeAd1Config);
                    }}
                    className="text-sm bg-emerald-600 text-white px-4 py-2 rounded-xl font-medium hover:bg-emerald-700 flex items-center gap-2"
                  >
                    <Save size={16} /> Save Script 1
                  </button>
                </div>
              </div>

              {/* Elite Native Ad 2 */}
              <div className="space-y-4 p-4 bg-gray-50 rounded-2xl border border-gray-200">
                <div className="flex justify-between items-center">
                  <label className="block text-sm font-bold text-gray-900">Elite Native Ad Script 2</label>
                  <div className="flex bg-white rounded-lg p-1 border border-gray-200">
                    <button
                      onClick={() => setEliteNativeAd2Config({ ...eliteNativeAd2Config, type: 'script' })}
                      className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${eliteNativeAd2Config.type === 'script' ? 'bg-emerald-100 text-emerald-700' : 'text-gray-500 hover:bg-gray-50'}`}
                    >
                      Custom Script
                    </button>
                    <button
                      onClick={() => setEliteNativeAd2Config({ ...eliteNativeAd2Config, type: 'google' })}
                      className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${eliteNativeAd2Config.type === 'google' ? 'bg-emerald-100 text-emerald-700' : 'text-gray-500 hover:bg-gray-50'}`}
                    >
                      Google Ad Unit
                    </button>
                  </div>
                </div>

                {eliteNativeAd2Config.type === 'script' ? (
                  <textarea
                    className="w-full p-3 border border-gray-300 rounded-xl focus:ring-emerald-500 focus:border-emerald-500 font-mono text-sm h-32"
                    placeholder="Paste native ad script 2 here..."
                    value={adsSettings.eliteNativeAd2 || ""}
                    onChange={(e) => setAdsSettings({ ...adsSettings, eliteNativeAd2: e.target.value })}
                  />
                ) : (
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="text-xs font-medium text-gray-500">Publisher ID</label>
                      <input
                        type="text"
                        className="w-full p-2 border border-gray-300 rounded-lg focus:ring-emerald-500 focus:border-emerald-500 text-sm"
                        placeholder="ca-pub-xxx"
                        value={eliteNativeAd2Config.client}
                        onChange={(e) => setEliteNativeAd2Config({ ...eliteNativeAd2Config, client: e.target.value })}
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-xs font-medium text-gray-500">Ad Slot ID</label>
                      <input
                        type="text"
                        className="w-full p-2 border border-gray-300 rounded-lg focus:ring-emerald-500 focus:border-emerald-500 text-sm"
                        placeholder="1234567890"
                        value={eliteNativeAd2Config.slot}
                        onChange={(e) => setEliteNativeAd2Config({ ...eliteNativeAd2Config, slot: e.target.value })}
                      />
                    </div>
                  </div>
                )}
                <div className="flex justify-end">
                  <button 
                    onClick={() => {
                      let value = adsSettings.eliteNativeAd2;
                      if (eliteNativeAd2Config.type === 'google') {
                        if (!eliteNativeAd2Config.client || !eliteNativeAd2Config.slot) return toast.error("Please enter Publisher ID and Slot ID");
                        value = generateGoogleAdScript(eliteNativeAd2Config.client, eliteNativeAd2Config.slot);
                      }
                      saveAdSetting("eliteNativeAd2", value, "eliteNativeAd2Config", eliteNativeAd2Config);
                    }}
                    className="text-sm bg-emerald-600 text-white px-4 py-2 rounded-xl font-medium hover:bg-emerald-700 flex items-center gap-2"
                  >
                    <Save size={16} /> Save Script 2
                  </button>
                </div>
              </div>

              <div className="border-t border-gray-200 pt-6 mt-2">
                <h3 className="text-lg font-bold text-gray-900 mb-4">Elite Hub Direct Links</h3>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <label className="block text-sm font-medium text-gray-700">Bottom Direct Link (Wait 5s)</label>
                  <button 
                    onClick={() => saveAdSetting("eliteDirectLinkBottom", adsSettings.eliteDirectLinkBottom)}
                    className="text-sm bg-emerald-50 text-emerald-600 px-3 py-1 rounded-lg font-medium hover:bg-emerald-100 flex items-center gap-1"
                  >
                    <Save size={14} /> Save
                  </button>
                </div>
                <input
                  type="url"
                  className="w-full p-3 border border-gray-300 rounded-xl focus:ring-emerald-500 focus:border-emerald-500"
                  placeholder="https://example.com/bottom-link"
                  value={adsSettings.eliteDirectLinkBottom || ""}
                  onChange={(e) => setAdsSettings({ ...adsSettings, eliteDirectLinkBottom: e.target.value })}
                />
              </div>

              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <label className="block text-sm font-medium text-gray-700">End Direct Link 1</label>
                  <button 
                    onClick={() => saveAdSetting("eliteDirectLinkEnd1", adsSettings.eliteDirectLinkEnd1)}
                    className="text-sm bg-emerald-50 text-emerald-600 px-3 py-1 rounded-lg font-medium hover:bg-emerald-100 flex items-center gap-1"
                  >
                    <Save size={14} /> Save
                  </button>
                </div>
                <input
                  type="url"
                  className="w-full p-3 border border-gray-300 rounded-xl focus:ring-emerald-500 focus:border-emerald-500"
                  placeholder="https://example.com/end-link-1"
                  value={adsSettings.eliteDirectLinkEnd1 || ""}
                  onChange={(e) => setAdsSettings({ ...adsSettings, eliteDirectLinkEnd1: e.target.value })}
                />
              </div>

              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <label className="block text-sm font-medium text-gray-700">End Direct Link 2</label>
                  <button 
                    onClick={() => saveAdSetting("eliteDirectLinkEnd2", adsSettings.eliteDirectLinkEnd2)}
                    className="text-sm bg-emerald-50 text-emerald-600 px-3 py-1 rounded-lg font-medium hover:bg-emerald-100 flex items-center gap-1"
                  >
                    <Save size={14} /> Save
                  </button>
                </div>
                <input
                  type="url"
                  className="w-full p-3 border border-gray-300 rounded-xl focus:ring-emerald-500 focus:border-emerald-500"
                  placeholder="https://example.com/end-link-2"
                  value={adsSettings.eliteDirectLinkEnd2 || ""}
                  onChange={(e) => setAdsSettings({ ...adsSettings, eliteDirectLinkEnd2: e.target.value })}
                />
              </div>
            </div>
          </div>
        )}

      </div>

      {/* Link Detail Modal */}
      {selectedLink && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-75 p-4">
          <div className="bg-white rounded-3xl shadow-2xl max-w-lg w-full overflow-hidden">
            <div className="p-6 border-b border-gray-100 flex justify-between items-center bg-gray-50/50">
              <h3 className="text-xl font-bold text-gray-900">Link Details</h3>
              <button onClick={() => setSelectedLink(null)} className="text-gray-400 hover:text-gray-600">
                <XCircle size={24} />
              </button>
            </div>
            <div className="p-8 space-y-6">
              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-1">
                  <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">Link ID</p>
                  <p className="text-sm font-mono font-bold text-gray-900">#{selectedLink.linkID}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">Creator</p>
                  <p className="text-sm font-bold text-gray-900">{selectedLink.userName || 'Unknown'}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">Views</p>
                  <p className="text-xl font-black text-gray-900">{selectedLink.totalClicks || 0}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">Earnings</p>
                  <p className="text-xl font-black text-emerald-600">₹{calculateEarnings(selectedLink.totalClicks || 0, selectedLink.cpm || appSettings.cpm).toFixed(2)}</p>
                </div>
              </div>

              <div className="border-t border-gray-100 pt-6 space-y-4">
                <h4 className="font-bold text-gray-900 uppercase text-xs tracking-widest">Daily Breakdown</h4>
                <div className="max-h-40 overflow-y-auto space-y-2">
                  {selectedLink.dailyClicks && Object.entries(selectedLink.dailyClicks).map(([date, clicks]: any) => (
                    <div key={date} className="flex justify-between text-sm p-2 bg-gray-50 rounded-lg">
                      <span className="text-gray-500">{date}</span>
                      <span className="font-bold text-gray-900">{clicks} views</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="border-t border-gray-100 pt-6">
                <p className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-1">Creator Email</p>
                <p className="text-sm font-medium text-gray-700">{selectedLink.userEmail}</p>
              </div>

              <button
                onClick={() => setSelectedLink(null)}
                className="w-full bg-gray-100 hover:bg-gray-200 text-gray-900 py-3 rounded-xl font-bold transition-all"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Fullscreen Image Modal */}
      {fullscreenImage && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-90 p-4" onClick={() => setFullscreenImage(null)}>
          <div className="relative max-w-full max-h-full flex flex-col items-center gap-4">
            <button className="absolute top-0 right-0 text-white hover:text-gray-300 p-4" onClick={() => setFullscreenImage(null)}>
              <XCircle size={40} />
            </button>
            <img src={fullscreenImage} alt="QR Code" className="max-w-full max-h-[85vh] object-contain rounded-2xl shadow-2xl bg-white p-4" />
            <p className="text-white font-black text-xl uppercase tracking-widest">User QR Code</p>
          </div>
        </div>
      )}

      <ConfirmModal 
        isOpen={confirmModal.isOpen}
        onClose={() => setConfirmModal({ ...confirmModal, isOpen: false })}
        onConfirm={confirmModal.onConfirm}
        title={confirmModal.title}
        message={confirmModal.message}
        type={confirmModal.type}
      />
      {editingUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-xl max-w-md w-full p-6 space-y-4 animate-in fade-in zoom-in duration-200">
            <h3 className="text-xl font-bold text-gray-900">Edit User Balance</h3>
            <p className="text-sm text-gray-500">
              Update wallet balance for <span className="font-bold text-gray-900">{editingUser.email}</span>
            </p>
            
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">New Balance (₹)</label>
              <input
                type="number"
                value={newBalance}
                onChange={(e) => setNewBalance(e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-xl focus:ring-emerald-500 focus:border-emerald-500"
                placeholder="0.00"
              />
            </div>

            <div className="flex justify-end gap-3 pt-4">
              <button
                onClick={() => setEditingUser(null)}
                className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-xl font-medium transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleUpdateBalance}
                className="px-4 py-2 bg-emerald-600 text-white hover:bg-emerald-700 rounded-xl font-bold transition-colors shadow-sm shadow-emerald-200"
              >
                Update Balance
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
