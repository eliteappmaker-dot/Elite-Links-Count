import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { db } from "@/lib/firebase";
import { collection, query, where, getDocs, doc, getDoc } from "firebase/firestore";
import { calculateEarnings } from "@/lib/utils";
import { ArrowLeft, Calendar, Eye, IndianRupee, Link as LinkIcon, ExternalLink, Copy, ShieldCheck, AlertTriangle, TrendingUp, Check, Zap } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import toast from "react-hot-toast";

export function LinkDetails() {
  const { id } = useParams();
  const { user, appSettings } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [linkData, setLinkData] = useState<any>(null);
  const [dailyStats, setDailyStats] = useState<any[]>([]);

  useEffect(() => {
    if (user && id) {
      fetchLinkDetails();
    }
  }, [user, id]);

  const fetchLinkDetails = async () => {
    try {
      const q = query(collection(db, "links"), where("linkID", "==", id), where("userID", "==", user!.uid));
      const querySnapshot = await getDocs(q);

      if (querySnapshot.empty) {
        navigate("/analytics");
        return;
      }

      const docData = querySnapshot.docs[0].data();
      setLinkData(docData);

      // Process daily stats
      const dailyClicks = docData.dailyClicks || {};
      const dailyRawClicks = docData.dailyRawClicks || {};
      const linkCPM = docData.cpm || appSettings.cpm;
      
      // Get all unique dates from both sets of stats
      const allDates = Array.from(new Set([...Object.keys(dailyClicks), ...Object.keys(dailyRawClicks)]));
      
      const stats = allDates.map(date => {
        const completed = dailyClicks[date] || 0;
        const initial = dailyRawClicks[date] || 0;
        return {
          date,
          views: completed,
          initialClicks: initial,
          conversion: initial > 0 ? ((completed / initial) * 100).toFixed(1) + "%" : "0%",
          earnings: calculateEarnings(completed, linkCPM)
        };
      }).sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

      setDailyStats(stats);
    } catch (error) {
      console.error("Error fetching link details:", error);
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success("Copied to clipboard!");
  };

  const isExpired = (link: any) => {
    if (!link || !link.createdAt) return false;
    const createdAt = link.createdAt.toMillis();
    const now = Date.now();
    const diffDays = (now - createdAt) / (1000 * 60 * 60 * 24);
    return diffDays > 30 && (link.totalClicks || 0) <= 400;
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-[50vh]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-600"></div>
      </div>
    );
  }

  const expired = isExpired(linkData);
  const baseUrl = "https://elitelinkscount.netlify.app";
  const domain = "elitelinkscount.netlify.app";
  const typePath = linkData?.shortenerType === 'elite-hub' ? '' : linkData?.shortenerType === 'links-count' ? 'links-count' : 'public';
  
  // Construct URL correctly: avoid extra slash if typePath is empty
  const shortUrl = typePath ? `${domain}/${typePath}/${id}` : `${domain}/${id}`;
  const fullShortUrl = typePath ? `${baseUrl}/${typePath}/${id}` : `${baseUrl}/${id}`;

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate("/analytics")} className="p-2 hover:bg-gray-100 rounded-full transition-colors">
            <ArrowLeft size={24} className="text-gray-600" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-3">
              Link Details <span className="text-emerald-600">#{id}</span>
              {expired ? (
                <span className="text-xs uppercase font-bold px-3 py-1 rounded-full bg-red-100 text-red-600 flex items-center gap-1">
                  <AlertTriangle size={12} /> Expired
                </span>
              ) : (
                <span className="text-xs uppercase font-bold px-3 py-1 rounded-full bg-emerald-100 text-emerald-600">
                  Active
                </span>
              )}
            </h1>
          </div>
        </div>
      </div>

      <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 bg-gray-50 rounded-xl border border-gray-100">
          <div className="flex-1 min-w-0">
            <p className="text-sm text-gray-500 font-medium mb-1">Short Link</p>
            <a href={fullShortUrl} target="_blank" rel="noreferrer" className="text-emerald-600 font-mono font-bold truncate block hover:underline">
              {shortUrl}
            </a>
          </div>
          <button 
            onClick={() => copyToClipboard(fullShortUrl)}
            className="flex items-center justify-center gap-2 px-4 py-2 bg-white border border-gray-200 rounded-lg text-gray-700 hover:bg-gray-50 hover:text-emerald-600 transition-colors shadow-sm flex-shrink-0"
          >
            <Copy size={16} />
            <span>Copy</span>
          </button>
        </div>

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 bg-gray-50 rounded-xl border border-gray-100">
          <div className="flex-1 min-w-0">
            <p className="text-sm text-gray-500 font-medium mb-1">Original URL</p>
            <div className="flex items-center gap-2">
              <ExternalLink size={16} className="text-gray-400 flex-shrink-0" />
              <p className="text-gray-900 truncate">{linkData.originalURL}</p>
            </div>
          </div>
          <button 
            onClick={() => copyToClipboard(linkData.originalURL)}
            className="flex items-center justify-center gap-2 px-4 py-2 bg-white border border-gray-200 rounded-lg text-gray-700 hover:bg-gray-50 hover:text-emerald-600 transition-colors shadow-sm flex-shrink-0"
          >
            <Copy size={16} />
            <span>Copy</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-2 opacity-10 group-hover:opacity-20 transition-opacity">
            <LinkIcon size={48} />
          </div>
          <div className="flex items-center gap-4">
            <div className="p-3 bg-purple-100 text-purple-600 rounded-xl">
              <TrendingUp size={24} />
            </div>
            <div>
              <p className="text-sm text-gray-500 font-medium">Initial Clicks</p>
              <h3 className="text-2xl font-bold text-gray-900">{linkData.rawClicks || 0}</h3>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-2 opacity-10 group-hover:opacity-20 transition-opacity">
            <Eye size={48} />
          </div>
          <div className="flex items-center gap-4">
            <div className="p-3 bg-blue-100 text-blue-600 rounded-xl">
              <Check size={24} />
            </div>
            <div>
              <p className="text-sm text-gray-500 font-medium">Completed Views</p>
              <h3 className="text-2xl font-bold text-gray-900">{linkData.totalClicks || 0}</h3>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-2 opacity-10 group-hover:opacity-20 transition-opacity">
            <IndianRupee size={48} />
          </div>
          <div className="flex items-center gap-4">
            <div className="p-3 bg-emerald-100 text-emerald-600 rounded-xl">
              <IndianRupee size={24} />
            </div>
            <div>
              <p className="text-sm text-gray-500 font-medium">Total Earnings</p>
              <h3 className="text-2xl font-bold text-gray-900">₹{calculateEarnings(linkData.totalClicks || 0, linkData.cpm || appSettings.cpm).toFixed(2)}</h3>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-2 opacity-10 group-hover:opacity-20 transition-opacity">
            <ShieldCheck size={48} />
          </div>
          <div className="flex items-center gap-4">
            <div className="p-3 bg-orange-100 text-orange-600 rounded-xl">
              <Zap size={24} />
            </div>
            <div>
              <p className="text-sm text-gray-500 font-medium">Conversion Rate</p>
              <h3 className="text-2xl font-bold text-gray-900">
                {linkData.rawClicks > 0 ? ((linkData.totalClicks / linkData.rawClicks) * 100).toFixed(1) : 0}%
              </h3>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm">
        <h2 className="text-lg font-bold text-gray-900 mb-6">Daily Performance</h2>
        <div className="h-80 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={dailyStats}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="date" />
              <YAxis yAxisId="left" orientation="left" stroke="#10b981" />
              <YAxis yAxisId="right" orientation="right" stroke="#3b82f6" />
              <Tooltip />
              <Bar yAxisId="right" dataKey="initialClicks" name="Initial Clicks" fill="#9333ea" radius={[4, 4, 0, 0]} barSize={20} />
              <Bar yAxisId="right" dataKey="views" name="Completed Views" fill="#3b82f6" radius={[4, 4, 0, 0]} barSize={20} />
              <Bar yAxisId="left" dataKey="earnings" name="Earnings (₹)" fill="#10b981" radius={[4, 4, 0, 0]} barSize={20} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-lg font-bold text-gray-900">Daily Breakdown</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Initial Clicks</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Completed</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Conv %</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Earnings</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {dailyStats.map((stat, index) => (
                <tr key={index} className="hover:bg-gray-50 transition-colors">
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 font-medium">
                    {stat.date}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm text-gray-600">
                    {stat.initialClicks}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm text-blue-600 font-bold">
                    {stat.views}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm text-orange-600 font-bold">
                    {stat.conversion}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm text-emerald-600 font-bold">
                    ₹{stat.earnings.toFixed(2)}
                  </td>
                </tr>
              ))}
              {dailyStats.length === 0 && (
                <tr>
                  <td colSpan={3} className="px-6 py-12 text-center text-gray-500">
                    No data available yet.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
