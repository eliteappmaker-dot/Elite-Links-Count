import React, { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { db } from "@/lib/firebase";
import { collection, query, where, getDocs, doc, getDoc, updateDoc, increment, Timestamp } from "firebase/firestore";
import { Copy, Share2, Users, TrendingUp, Gift, Award, CheckCircle, AlertCircle } from "lucide-react";
import toast from "react-hot-toast";

interface ReferredUser {
  id: string;
  displayName: string;
  photoURL: string | null;
  totalViews: number;
  totalWithdrawals: number;
  createdAt: any;
  earningsForReferrer: number;
}

export function Invite() {
  const { user, userProfile, urlSettings } = useAuth();
  const [referredUsers, setReferredUsers] = useState<ReferredUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    totalInvites: 0,
    totalEarnings: 0
  });

  const [referralCode, setReferralCode] = useState(userProfile?.referralCode || "");

  useEffect(() => {
    if (userProfile) {
      if (!userProfile.referralCode) {
        // Generate and save referral code if missing
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        let newCode = '';
        for (let i = 0; i < 6; i++) {
          newCode += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        updateDoc(doc(db, "users", userProfile.uid), { referralCode: newCode })
          .then(() => setReferralCode(newCode))
          .catch(err => console.error("Error generating code:", err));
      } else {
        setReferralCode(userProfile.referralCode);
      }
      fetchReferredUsers();
    }
  }, [userProfile]);

  const inviteLink = urlSettings?.inviteShareUrl || "https://elite-links.com";
  const shareMessage = `Join Elite Links and earn money! Use my invite code: ${referralCode} to get ₹5 bonus instantly! ${inviteLink}`;

  const fetchReferredUsers = async () => {
    setLoading(true);
    try {
      // Fetch users referred by current user
      const q = query(collection(db, "users"), where("referredBy", "==", user!.uid));
      const querySnapshot = await getDocs(q);
      
      const usersList: ReferredUser[] = [];
      let totalEarned = 0;

      // We need to check tasks for each user
      // This is a client-side check. Ideally, this should be a cloud function.
      // For this environment, we check on load.
      
      const referrerRef = doc(db, "users", user!.uid);
      const referrerDoc = await getDoc(referrerRef);
      const referralRewards = referrerDoc.data()?.referralRewards || {};
      let rewardsUpdated = false;
      let newEarnings = 0;

      for (const userDoc of querySnapshot.docs) {
        const userData = userDoc.data();
        const userId = userDoc.id;
        
        // Fetch user's stats (views, withdrawals)
        // Views are in 'links' collection, withdrawals in 'withdrawals'
        
        // 1. Calculate Views
        const linksQ = query(collection(db, "links"), where("userID", "==", userId));
        const linksSnap = await getDocs(linksQ);
        let totalViews = 0;
        linksSnap.forEach(l => {
          const clicks = l.data().dailyClicks || {};
          Object.values(clicks).forEach((c: any) => totalViews += Number(c));
        });

        // 2. Calculate Withdrawals
        const withdrawalsQ = query(collection(db, "withdrawals"), where("userID", "==", userId), where("status", "==", "Approved"));
        const wSnap = await getDocs(withdrawalsQ);
        let totalWithdrawals = 0;
        wSnap.forEach(w => totalWithdrawals += w.data().amount);

        // Check Tasks
        let userEarnings = 0;
        const joinDate = userData.createdAt?.toDate();
        const now = new Date();
        const oneWeek = 7 * 24 * 60 * 60 * 1000;
        const oneMonth = 30 * 24 * 60 * 60 * 1000;

        // Task 1: 2000 views in 1 week (₹10)
        const task1Id = `${userId}_task1`;
        if (!referralRewards[task1Id] && totalViews >= 2000 && (now.getTime() - joinDate.getTime()) <= oneWeek) {
          referralRewards[task1Id] = true;
          newEarnings += 10;
          userEarnings += 10;
          rewardsUpdated = true;
        } else if (referralRewards[task1Id]) {
          userEarnings += 10;
        }

        // Task 2: 50,000 views in 1 month (₹50)
        const task2Id = `${userId}_task2`;
        if (!referralRewards[task2Id] && totalViews >= 50000 && (now.getTime() - joinDate.getTime()) <= oneMonth) {
          referralRewards[task2Id] = true;
          newEarnings += 50;
          userEarnings += 50;
          rewardsUpdated = true;
        } else if (referralRewards[task2Id]) {
          userEarnings += 50;
        }

        // Task 3: Withdraw > ₹500 in 1 month (₹60)
        const task3Id = `${userId}_task3`;
        if (!referralRewards[task3Id] && totalWithdrawals > 500 && (now.getTime() - joinDate.getTime()) <= oneMonth) {
          referralRewards[task3Id] = true;
          newEarnings += 60;
          userEarnings += 60;
          rewardsUpdated = true;
        } else if (referralRewards[task3Id]) {
          userEarnings += 60;
        }

        totalEarned += userEarnings;

        usersList.push({
          id: userId,
          displayName: userData.displayName || "Unknown User",
          photoURL: userData.photoURL,
          totalViews,
          totalWithdrawals,
          createdAt: userData.createdAt,
          earningsForReferrer: userEarnings
        });
      }

      if (rewardsUpdated) {
        await updateDoc(referrerRef, {
          walletBalance: increment(newEarnings),
          referralRewards: referralRewards
        });
        toast.success(`You earned ₹${newEarnings} from referrals!`);
        totalEarned += newEarnings; // Update local total
      }

      setReferredUsers(usersList);
      setStats({
        totalInvites: usersList.length,
        totalEarnings: totalEarned
      });

    } catch (error) {
      console.error("Error fetching referrals:", error);
      toast.error("Failed to load referral data");
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success("Copied to clipboard!");
  };

  const shareOnWhatsApp = () => {
    const url = `https://wa.me/?text=${encodeURIComponent(shareMessage)}`;
    window.open(url, '_blank');
  };

  const shareOnTelegram = () => {
    const url = `https://t.me/share/url?url=${encodeURIComponent(inviteLink)}&text=${encodeURIComponent(shareMessage)}`;
    window.open(url, '_blank');
  };

  const shareNative = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Join Elite Links',
          text: shareMessage,
          url: inviteLink,
        });
      } catch (err) {
        console.error("Share failed:", err);
      }
    } else {
      copyToClipboard(shareMessage);
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8 pb-20">
      {/* Header */}
      <div className="text-center space-y-4 py-8">
        <h1 className="text-4xl md:text-5xl font-black text-gray-900 tracking-tight">
          Refer & Earn <span className="text-emerald-600">Big Rewards</span>
        </h1>
        <p className="text-xl text-gray-500 font-medium max-w-2xl mx-auto">
          Invite your friends and earn up to ₹120 per referral!
        </p>
      </div>

      {/* Invite Code Card */}
      <div className="bg-gradient-to-br from-emerald-900 to-emerald-800 rounded-[2.5rem] p-8 md:p-12 text-white shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 -mt-20 -mr-20 w-96 h-96 bg-emerald-500 rounded-full opacity-20 blur-3xl"></div>
        <div className="absolute bottom-0 left-0 -mb-20 -ml-20 w-80 h-80 bg-emerald-400 rounded-full opacity-20 blur-3xl"></div>
        
        <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-12">
          <div className="text-center md:text-left space-y-6">
            <div>
              <p className="text-emerald-200 font-bold uppercase tracking-widest text-sm mb-2">Your Invite Code</p>
              <div className="flex items-center gap-4 bg-white/10 backdrop-blur-md p-2 rounded-2xl border border-white/20">
                <code className="text-3xl md:text-5xl font-mono font-black px-4 md:px-6 tracking-widest">
                  {referralCode || "LOADING"}
                </code>
                <button 
                  onClick={() => copyToClipboard(referralCode)}
                  className="p-3 md:p-4 bg-white text-emerald-900 rounded-xl hover:bg-emerald-50 transition-colors shadow-lg"
                >
                  <Copy size={20} />
                </button>
              </div>
              <p className="text-emerald-200/80 text-xs font-medium mt-2 text-center md:text-left">
                User: {userProfile?.displayName || "Unknown"}
              </p>
            </div>
            
            <div className="flex flex-wrap gap-3 justify-center md:justify-start">
              <button onClick={shareOnWhatsApp} className="flex items-center gap-2 bg-[#25D366] hover:bg-[#20bd5a] text-white px-4 py-2.5 rounded-xl font-bold text-sm transition-all shadow-lg shadow-green-900/20">
                <Share2 size={16} /> WhatsApp
              </button>
              <button onClick={shareOnTelegram} className="flex items-center gap-2 bg-[#0088cc] hover:bg-[#0077b5] text-white px-4 py-2.5 rounded-xl font-bold text-sm transition-all shadow-lg shadow-blue-900/20">
                <Share2 size={16} /> Telegram
              </button>
              <button onClick={shareNative} className="flex items-center gap-2 bg-white/20 hover:bg-white/30 text-white px-4 py-2.5 rounded-xl font-bold text-sm transition-all backdrop-blur-sm">
                More
              </button>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 w-full max-w-md">
            <div className="bg-white/10 backdrop-blur-md p-6 rounded-2xl border border-white/10 text-center">
              <Users size={32} className="mx-auto mb-2 text-emerald-300" />
              <p className="text-3xl font-black">{stats.totalInvites}</p>
              <p className="text-emerald-200 text-xs font-bold uppercase tracking-wider">Total Invites</p>
            </div>
            <div className="bg-white/10 backdrop-blur-md p-6 rounded-2xl border border-white/10 text-center">
              <Gift size={32} className="mx-auto mb-2 text-emerald-300" />
              <p className="text-3xl font-black">₹{stats.totalEarnings}</p>
              <p className="text-emerald-200 text-xs font-bold uppercase tracking-wider">Total Earned</p>
            </div>
          </div>
        </div>
      </div>

      {/* Tasks Info */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow">
          <div className="w-12 h-12 bg-blue-50 rounded-2xl flex items-center justify-center text-blue-600 mb-4">
            <TrendingUp size={24} />
          </div>
          <h3 className="font-bold text-lg text-gray-900 mb-2">Task 1</h3>
          <p className="text-gray-500 text-sm mb-4">If user crosses <span className="font-bold text-gray-900">2,000 views</span> in 1 week.</p>
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-gray-400 uppercase tracking-wider">Reward</span>
            <span className="text-xl font-black text-blue-600">₹10</span>
          </div>
        </div>

        <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow">
          <div className="w-12 h-12 bg-purple-50 rounded-2xl flex items-center justify-center text-purple-600 mb-4">
            <Award size={24} />
          </div>
          <h3 className="font-bold text-lg text-gray-900 mb-2">Task 2</h3>
          <p className="text-gray-500 text-sm mb-4">If user crosses <span className="font-bold text-gray-900">50,000 views</span> in 1 month.</p>
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-gray-400 uppercase tracking-wider">Reward</span>
            <span className="text-xl font-black text-purple-600">₹50</span>
          </div>
        </div>

        <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow">
          <div className="w-12 h-12 bg-orange-50 rounded-2xl flex items-center justify-center text-orange-600 mb-4">
            <Gift size={24} />
          </div>
          <h3 className="font-bold text-lg text-gray-900 mb-2">Task 3</h3>
          <p className="text-gray-500 text-sm mb-4">If user withdraws <span className="font-bold text-gray-900">&gt; ₹500</span> in 1 month.</p>
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-gray-400 uppercase tracking-wider">Reward</span>
            <span className="text-xl font-black text-orange-600">₹60</span>
          </div>
        </div>
      </div>

      {/* Referred Users List */}
      <div className="bg-white rounded-[2.5rem] border border-gray-200 shadow-sm overflow-hidden">
        <div className="p-8 border-b border-gray-100">
          <h2 className="text-2xl font-black text-gray-900">Referred Users</h2>
        </div>
        
        {loading ? (
          <div className="p-8 text-center text-gray-500">Loading...</div>
        ) : referredUsers.length === 0 ? (
          <div className="p-12 text-center">
            <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-4 text-gray-400">
              <Users size={32} />
            </div>
            <h3 className="text-lg font-bold text-gray-900">No referrals yet</h3>
            <p className="text-gray-500">Share your code to start earning!</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-8 py-4 text-left text-xs font-black text-gray-400 uppercase tracking-widest">User</th>
                  <th className="px-8 py-4 text-left text-xs font-black text-gray-400 uppercase tracking-widest">Total Views</th>
                  <th className="px-8 py-4 text-right text-xs font-black text-gray-400 uppercase tracking-widest">You Earned</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {referredUsers.map((referral) => (
                  <tr key={referral.id} className="hover:bg-gray-50/50 transition-colors">
                    <td className="px-8 py-4">
                      <div className="flex items-center gap-4">
                        <div className="w-10 h-10 bg-emerald-100 rounded-full flex items-center justify-center text-emerald-700 font-bold">
                          {referral.displayName.charAt(0).toUpperCase()}
                        </div>
                        <div>
                          <p className="font-bold text-gray-900">
                            {referral.displayName.substring(0, 4)}...
                          </p>
                          <p className="text-xs text-gray-400">
                            Joined {referral.createdAt?.toDate().toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                    </td>
                    <td className="px-8 py-4">
                      <span className="font-mono font-medium text-gray-600">{referral.totalViews}</span>
                    </td>
                    <td className="px-8 py-4 text-right">
                      <span className="font-black text-emerald-600">+₹{referral.earningsForReferrer}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
