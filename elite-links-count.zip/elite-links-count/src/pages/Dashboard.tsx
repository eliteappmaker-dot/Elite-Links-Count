import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { db } from "@/lib/firebase";
import { collection, query, where, getDocs } from "firebase/firestore";
import { calculateEarnings } from "@/lib/utils";
import { Link } from "react-router-dom";
import { Link as LinkIcon, TrendingUp, IndianRupee, ArrowRight } from "lucide-react";

export function Dashboard() {
  const { user, appSettings } = useAuth();
  const [stats, setStats] = useState({
    totalLinks: 0,
    totalClicks: 0,
    totalEarnings: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      fetchStats();
    }
  }, [user]);

  const fetchStats = async () => {
    if (!user) return;
    try {
      const q = query(collection(db, "links"), where("userID", "==", user.uid));
      const querySnapshot = await getDocs(q);
      
      let totalClicks = 0;
      let totalEarningsCalculated = 0;
      const totalLinks = querySnapshot.size;
      
      querySnapshot.forEach((doc) => {
        const data = doc.data();
        const linkCPM = data.cpm || appSettings.cpm;
        const linkClicks = data.totalClicks || 0;
        totalClicks += linkClicks;
        totalEarningsCalculated += calculateEarnings(linkClicks, linkCPM);
      });

      setStats({
        totalLinks,
        totalClicks,
        totalEarnings: totalEarningsCalculated,
      });
    } catch (error) {
      console.error("Error fetching stats:", error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div className="flex justify-center items-center h-64">Loading...</div>;
  }

  return (
    <div className="max-w-5xl mx-auto space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
        <p className="text-gray-500 mt-1">Welcome back, {user?.displayName || user?.email}</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm flex flex-col">
          <div className="flex items-center gap-3 text-gray-500 mb-4">
            <div className="p-2 bg-emerald-50 rounded-lg text-emerald-600">
              <LinkIcon size={20} />
            </div>
            <span className="font-medium">Total Links</span>
          </div>
          <div className="text-4xl font-bold text-gray-900">{stats.totalLinks}</div>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm flex flex-col">
          <div className="flex items-center gap-3 text-gray-500 mb-4">
            <div className="p-2 bg-emerald-50 rounded-lg text-emerald-600">
              <TrendingUp size={20} />
            </div>
            <span className="font-medium">Total Clicks</span>
          </div>
          <div className="text-4xl font-bold text-gray-900">{stats.totalClicks}</div>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm flex flex-col">
          <div className="flex items-center gap-3 text-gray-500 mb-4">
            <div className="p-2 bg-emerald-50 rounded-lg text-emerald-600">
              <IndianRupee size={20} />
            </div>
            <span className="font-medium">Total Earnings</span>
          </div>
          <div className="text-4xl font-bold text-emerald-600">₹{stats.totalEarnings.toFixed(2)}</div>
        </div>
      </div>

      {/* Actions */}
      <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm flex flex-col md:flex-row items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-gray-900">Ready to withdraw?</h2>
          <p className="text-gray-500">Transfer your earnings directly to your UPI account.</p>
        </div>
        <Link
          to="/wallet"
          className="bg-emerald-600 hover:bg-emerald-700 text-white px-6 py-3 rounded-xl font-medium transition-colors flex items-center gap-2 whitespace-nowrap"
        >
          Go to Wallet <ArrowRight size={18} />
        </Link>
      </div>
    </div>
  );
}
