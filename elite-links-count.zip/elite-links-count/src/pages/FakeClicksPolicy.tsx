import React from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { ShieldAlert, Ban, UserCheck, Info } from 'lucide-react';

export function FakeClicksPolicy() {
  const { urlSettings } = useAuth();

  return (
    <div className="max-w-4xl mx-auto py-12 px-4">
      <div className="bg-white rounded-3xl shadow-xl border border-gray-100 overflow-hidden">
        <div className="bg-red-600 p-8 text-white">
          <div className="flex items-center gap-4 mb-4">
            <ShieldAlert size={40} />
            <h1 className="text-3xl font-black uppercase tracking-tight">Fake Clicks Policy</h1>
          </div>
          <p className="text-red-50 opacity-90 font-medium">Ensuring fair play and protecting our advertisers.</p>
        </div>
        
        <div className="p-8 md:p-12 space-y-10">
          <section className="space-y-4">
            <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2">
              <Info className="text-red-600" size={24} /> What are Fake Clicks?
            </h2>
            <p className="text-gray-600 leading-relaxed">
              Fake clicks refer to any clicks generated through non-human or deceptive means. This includes using bots, automated scripts, click farms, or incentivizing users to click on links without genuine interest in the content.
            </p>
          </section>

          <section className="space-y-4">
            <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2">
              <Ban className="text-red-500" size={24} /> Prohibited Activities
            </h2>
            <div className="bg-red-50 p-6 rounded-2xl border border-red-100 space-y-4">
              <ul className="space-y-3">
                <li className="flex gap-3 text-red-800 font-medium">
                  <span className="flex-shrink-0 w-6 h-6 bg-red-200 rounded-full flex items-center justify-center text-xs">1</span>
                  Using VPNs, Proxies, or Tor to generate clicks from different locations.
                </li>
                <li className="flex gap-3 text-red-800 font-medium">
                  <span className="flex-shrink-0 w-6 h-6 bg-red-200 rounded-full flex items-center justify-center text-xs">2</span>
                  Clicking on your own links repeatedly to inflate earnings.
                </li>
                <li className="flex gap-3 text-red-800 font-medium">
                  <span className="flex-shrink-0 w-6 h-6 bg-red-200 rounded-full flex items-center justify-center text-xs">3</span>
                  Asking others to click on your links in exchange for money, points, or other rewards.
                </li>
                <li className="flex gap-3 text-red-800 font-medium">
                  <span className="flex-shrink-0 w-6 h-6 bg-red-200 rounded-full flex items-center justify-center text-xs">4</span>
                  Using automated software, bots, or scripts to simulate human clicks.
                </li>
              </ul>
            </div>
          </section>

          <section className="space-y-4">
            <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2">
              <UserCheck className="text-emerald-600" size={24} /> Consequences
            </h2>
            <p className="text-gray-600 leading-relaxed">
              We have advanced detection systems to identify fake clicks. If your account is found to be engaging in fraudulent activity:
            </p>
            <ul className="list-disc pl-6 text-gray-600 space-y-2 font-medium">
              <li>All earnings generated from fake clicks will be voided.</li>
              <li>Pending withdrawal requests will be rejected.</li>
              <li>Your account may be permanently banned without notice.</li>
              <li>We reserve the right to report fraudulent activity to relevant authorities.</li>
            </ul>
          </section>

          <div className="pt-8 border-t border-gray-100 flex flex-col md:flex-row justify-between items-center gap-6">
            <p className="text-sm text-gray-500 font-medium">Last Updated: {new Date().toLocaleDateString()}</p>
            {urlSettings.contactAdmin && (
              <a href={urlSettings.contactAdmin} className="bg-red-600 text-white px-8 py-3 rounded-2xl font-bold hover:bg-red-700 transition-all shadow-lg shadow-red-100">
                Report Fraud
              </a>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
