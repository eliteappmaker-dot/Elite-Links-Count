import React, { useState, useEffect } from "react";
import { auth, db } from "@/lib/firebase";
import { useAuth } from "@/contexts/AuthContext";
import { signInWithEmailAndPassword, createUserWithEmailAndPassword } from "firebase/auth";
import { doc, setDoc, getDoc, collection, query, where, getDocs } from "firebase/firestore";
import { useNavigate, Link } from "react-router-dom";
import toast from "react-hot-toast";
import { Mail, Lock, User, ArrowRight, ShieldCheck, Zap, TrendingUp, Gift } from "lucide-react";

export function Login() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [inviteCode, setInviteCode] = useState("");
  const [isSignUp, setIsSignUp] = useState(false);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const { user, userProfile } = useAuth();

  // Automatic redirect if already logged in
  useEffect(() => {
    if (user && userProfile) {
      navigate(userProfile.isAdmin ? "/admin" : "/dashboard");
    }
  }, [user, userProfile, navigate]);

  const generateReferralCode = () => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    for (let i = 0; i < 6; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  };

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      if (isSignUp) {
        if (!name.trim()) {
          toast.error("Please enter your name");
          setLoading(false);
          return;
        }

        // Password Validation
        const passwordRegex = /^[A-Z][A-Za-z0-9]{7,}$/;
        if (!passwordRegex.test(password)) {
          toast.error("Password must start with a capital letter and be at least 8 characters long with numbers and letters.");
          setLoading(false);
          return;
        }

        // Device Restriction Check
        const deviceAccounts = parseInt(localStorage.getItem('device_accounts') || '0');
        if (deviceAccounts >= 2) {
          toast.error("Maximum 2 accounts allowed per device.");
          setLoading(false);
          return;
        }

        let referrerId = null;
        let bonusAmount = 0;

        // Validate Invite Code
        if (inviteCode.trim()) {
          const usersRef = collection(db, "users");
          const q = query(usersRef, where("referralCode", "==", inviteCode.trim()));
          const querySnapshot = await getDocs(q);

          if (!querySnapshot.empty) {
            referrerId = querySnapshot.docs[0].id;
            bonusAmount = 5;
          } else {
            toast.error("Invalid invite code. Please check or leave blank.");
            setLoading(false);
            return;
          }
        }

        const result = await createUserWithEmailAndPassword(auth, email, password);
        const user = result.user;
        const isAdmin = ["eliteappmaker@gmail.com", "myotherwork2025@gmail.com"].includes(user.email || "");
        
        const newReferralCode = generateReferralCode();

        await setDoc(doc(db, "users", user.uid), {
          email: user.email,
          displayName: name.trim(),
          photoURL: null,
          createdAt: new Date(),
          isAdmin: isAdmin,
          isBlocked: false,
          totalEarnings: bonusAmount, // Add bonus if applicable
          totalClicks: 0,
          balance: 0,
          walletBalance: bonusAmount, // Add bonus to wallet
          referralCode: newReferralCode,
          referredBy: referrerId,
          socialTasksCompleted: false
        });

        // Increment device account count
        localStorage.setItem('device_accounts', (deviceAccounts + 1).toString());
        
        if (bonusAmount > 0) {
          toast.success("Account created! ₹5 bonus added.");
        } else {
          toast.success("Account created successfully!");
        }
        navigate(isAdmin ? "/admin" : "/dashboard");
      } else {
        const result = await signInWithEmailAndPassword(auth, email, password);
        const userRef = doc(db, "users", result.user.uid);
        const userSnap = await getDoc(userRef);
        
        if (userSnap.exists()) {
          const userData = userSnap.data();
          if (userData.isBlocked) {
            toast.error("Your account has been blocked. Please contact support.");
            await auth.signOut();
            setLoading(false);
            return;
          }
          toast.success("Logged in successfully!");
          navigate(userData.isAdmin ? "/admin" : "/dashboard");
        } else {
          // Handle case where user exists in Auth but not Firestore (should rarely happen)
           await setDoc(doc(db, "users", result.user.uid), {
            email: result.user.email,
            displayName: result.user.displayName || "User",
            photoURL: result.user.photoURL,
            createdAt: new Date(),
            isAdmin: false,
            isBlocked: false,
            totalEarnings: 0,
            totalClicks: 0,
            balance: 0,
            walletBalance: 0,
            referralCode: generateReferralCode(),
          });
          toast.success("Logged in successfully!");
          navigate("/dashboard");
        }
      }
    } catch (error: any) {
      console.error("Auth error:", error);
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[85vh] flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-5xl w-full bg-white rounded-3xl shadow-2xl overflow-hidden flex flex-col md:flex-row border border-gray-100">
        
        {/* Left Side - Graphic/Info */}
        <div className="md:w-1/2 bg-emerald-600 p-12 text-white flex flex-col justify-between relative overflow-hidden hidden md:flex">
          <div className="absolute top-0 right-0 -mt-20 -mr-20 w-80 h-80 bg-emerald-500 rounded-full opacity-50 blur-3xl"></div>
          <div className="absolute bottom-0 left-0 -mb-20 -ml-20 w-80 h-80 bg-emerald-700 rounded-full opacity-50 blur-3xl"></div>
          
          <div className="relative z-10">
            <Link to="/" className="flex items-center gap-3 mb-12">
              <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center shadow-lg">
                <TrendingUp className="text-emerald-600" size={24} />
              </div>
              <span className="font-righteous text-2xl tracking-wide">Elite Links</span>
            </Link>
            
            <h1 className="text-4xl font-bold mb-6 leading-tight">
              Monetize your audience with the highest CPM rates.
            </h1>
            <p className="text-emerald-100 text-lg mb-12 max-w-md">
              Join thousands of creators earning daily with our advanced link shortener network.
            </p>
            
            <div className="space-y-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-emerald-500/30 rounded-full flex items-center justify-center backdrop-blur-sm">
                  <Zap size={24} className="text-emerald-100" />
                </div>
                <div>
                  <h3 className="font-bold text-lg">Instant Generation</h3>
                  <p className="text-emerald-100 text-sm">Create links in milliseconds</p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-emerald-500/30 rounded-full flex items-center justify-center backdrop-blur-sm">
                  <ShieldCheck size={24} className="text-emerald-100" />
                </div>
                <div>
                  <h3 className="font-bold text-lg">Secure Tracking</h3>
                  <p className="text-emerald-100 text-sm">Advanced anti-bot protection</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="relative z-10 text-emerald-200 text-sm mt-12">
            © {new Date().getFullYear()} Elite Links Count. All rights reserved.
          </div>
        </div>

        {/* Right Side - Form */}
        <div className="md:w-1/2 p-8 md:p-12 lg:p-16 flex flex-col justify-center bg-gray-50 relative">
          <div className="max-w-md w-full mx-auto space-y-8">
            <div className="text-center md:text-left">
              <h2 className="text-3xl font-extrabold text-gray-900 tracking-tight">
                {isSignUp ? "Create an account" : "Welcome back"}
              </h2>
              <p className="mt-2 text-sm text-gray-500">
                {isSignUp ? "Already have an account? " : "Don't have an account? "}
                <button
                  type="button"
                  onClick={() => setIsSignUp(!isSignUp)}
                  className="font-bold text-emerald-600 hover:text-emerald-500 transition-colors"
                >
                  {isSignUp ? "Sign in instead" : "Create one now"}
                </button>
              </p>
            </div>

            <form className="space-y-6" onSubmit={handleAuth}>
              <div className="space-y-4">
                {isSignUp && (
                  <>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                          <User className="h-5 w-5 text-gray-400" />
                        </div>
                        <input
                          type="text"
                          required
                          value={name}
                          onChange={(e) => setName(e.target.value)}
                          className="block w-full pl-10 pr-3 py-3 border border-gray-300 rounded-xl focus:ring-emerald-500 focus:border-emerald-500 bg-white shadow-sm transition-colors"
                          placeholder="John Doe"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Invite Code (Optional)</label>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                          <Gift className="h-5 w-5 text-gray-400" />
                        </div>
                        <input
                          type="text"
                          value={inviteCode}
                          onChange={(e) => setInviteCode(e.target.value)}
                          className="block w-full pl-10 pr-3 py-3 border border-gray-300 rounded-xl focus:ring-emerald-500 focus:border-emerald-500 bg-white shadow-sm transition-colors"
                          placeholder="Enter 6-digit code"
                          maxLength={6}
                        />
                      </div>
                      <p className="mt-1 text-xs text-emerald-600 font-medium">Enter invite code to get ₹5 bonus. Do not enter wrong code.</p>
                    </div>
                  </>
                )}

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <Mail className="h-5 w-5 text-gray-400" />
                    </div>
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="block w-full pl-10 pr-3 py-3 border border-gray-300 rounded-xl focus:ring-emerald-500 focus:border-emerald-500 bg-white shadow-sm transition-colors"
                      placeholder="you@example.com"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Password</label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <Lock className="h-5 w-5 text-gray-400" />
                    </div>
                    <input
                      type="password"
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="block w-full pl-10 pr-3 py-3 border border-gray-300 rounded-xl focus:ring-emerald-500 focus:border-emerald-500 bg-white shadow-sm transition-colors"
                      placeholder="••••••••"
                      minLength={8}
                    />
                  </div>
                  {isSignUp && (
                    <p className="mt-2 text-xs text-red-500 font-medium">
                      Please remember your password. It cannot be reset.
                      <br />
                      Password must be at least 8 characters long, start with a capital letter, and contain numbers and letters.
                    </p>
                  )}
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full flex justify-center items-center gap-2 py-3 px-4 border border-transparent rounded-xl shadow-sm text-sm font-bold text-white bg-emerald-600 hover:bg-emerald-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-emerald-500 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? (
                  <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                ) : (
                  <>
                    {isSignUp ? "Create Account" : "Sign In"}
                    <ArrowRight size={18} />
                  </>
                )}
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
