import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { db } from '@/lib/firebase';
import { doc, getDoc, updateDoc } from 'firebase/firestore';
import { User, Mail, Calendar, Edit2, Save, Send, MessageCircle, Instagram } from 'lucide-react';
import toast from 'react-hot-toast';

export function Profile() {
  const { user, urlSettings } = useAuth();
  const [userData, setUserData] = useState<any>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [newDisplayName, setNewDisplayName] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      fetchUserData();
    }
  }, [user]);

  const fetchUserData = async () => {
    try {
      const docSnap = await getDoc(doc(db, "users", user!.uid));
      if (docSnap.exists()) {
        const data = docSnap.data();
        setUserData(data);
        setNewDisplayName(data.displayName || '');
      }
    } catch (error) {
      console.error("Error fetching user data:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateProfile = async () => {
    if (!newDisplayName.trim()) {
      toast.error("Username cannot be empty");
      return;
    }
    try {
      await updateDoc(doc(db, "users", user!.uid), {
        displayName: newDisplayName
      });
      setUserData({ ...userData, displayName: newDisplayName });
      setIsEditing(false);
      toast.success("Profile updated successfully");
    } catch (error) {
      toast.error("Error updating profile");
    }
  };

  if (loading) return <div className="flex justify-center py-12">Loading Profile...</div>;
  if (!user) return <div className="text-center py-12">Please login to view profile.</div>;

  const firstLetter = (userData?.displayName || user.email || '?')[0].toUpperCase();

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      <div className="bg-white rounded-3xl shadow-xl border border-gray-100 overflow-hidden">
        <div className="bg-emerald-600 h-32 relative">
          <div className="absolute -bottom-12 left-8">
            <div className="w-24 h-24 rounded-3xl bg-white p-1 shadow-lg">
              <div className="w-full h-full rounded-2xl bg-emerald-100 flex items-center justify-center text-emerald-600 text-4xl font-black">
                {firstLetter}
              </div>
            </div>
          </div>
        </div>
        
        <div className="pt-16 p-8 space-y-6">
          <div className="flex justify-between items-start">
            <div className="space-y-1">
              {isEditing ? (
                <div className="flex gap-2">
                  <input 
                    type="text" 
                    value={newDisplayName}
                    onChange={(e) => setNewDisplayName(e.target.value)}
                    className="text-2xl font-black text-gray-900 border-b-2 border-emerald-500 focus:outline-none bg-transparent"
                    autoFocus
                  />
                  <button onClick={handleUpdateProfile} className="p-2 text-emerald-600 hover:bg-emerald-50 rounded-xl transition-colors">
                    <Save size={20} />
                  </button>
                </div>
              ) : (
                <div className="flex items-center gap-2 group">
                  <h1 className="text-3xl font-black text-gray-900 tracking-tight">{userData?.displayName || 'No Name'}</h1>
                  <button onClick={() => setIsEditing(true)} className="p-1 text-gray-400 opacity-0 group-hover:opacity-100 hover:text-emerald-600 transition-all">
                    <Edit2 size={16} />
                  </button>
                </div>
              )}
              <p className="text-gray-500 font-medium flex items-center gap-2">
                <Mail size={14} /> {user.email}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4">
            <div className="p-4 bg-gray-50 rounded-2xl border border-gray-100 flex items-center gap-4">
              <div className="p-2 bg-white rounded-xl text-emerald-600 shadow-sm">
                <Calendar size={20} />
              </div>
              <div>
                <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">Joined On</p>
                <p className="text-sm font-bold text-gray-900">
                  {userData?.createdAt?.toDate ? userData.createdAt.toDate().toLocaleDateString() : 'N/A'}
                </p>
              </div>
            </div>
            <div className="p-4 bg-gray-50 rounded-2xl border border-gray-100 flex items-center gap-4">
              <div className="p-2 bg-white rounded-xl text-emerald-600 shadow-sm">
                <User size={20} />
              </div>
              <div>
                <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">Account Status</p>
                <p className="text-sm font-bold text-emerald-600">Active</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Social Links */}
      <div className="bg-white rounded-3xl shadow-xl border border-gray-100 p-8 space-y-6">
        <h2 className="text-xl font-black text-gray-900 uppercase tracking-tight flex items-center gap-2">
          Our Channels & Groups
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <a href={urlSettings.telegramChannel || "#"} target="_blank" rel="noreferrer" className="flex items-center gap-4 p-4 bg-blue-50 rounded-2xl border border-blue-100 hover:bg-blue-100 transition-all group">
            <div className="p-3 bg-white rounded-xl text-blue-600 shadow-sm group-hover:scale-110 transition-transform">
              <Send size={24} />
            </div>
            <div>
              <p className="text-xs font-bold text-blue-400 uppercase tracking-widest">Telegram</p>
              <p className="text-sm font-black text-blue-900">Official Channel</p>
            </div>
          </a>
          <a href={urlSettings.telegramGroup || "#"} target="_blank" rel="noreferrer" className="flex items-center gap-4 p-4 bg-blue-50 rounded-2xl border border-blue-100 hover:bg-blue-100 transition-all group">
            <div className="p-3 bg-white rounded-xl text-blue-400 shadow-sm group-hover:scale-110 transition-transform">
              <MessageCircle size={24} />
            </div>
            <div>
              <p className="text-xs font-bold text-blue-300 uppercase tracking-widest">Telegram</p>
              <p className="text-sm font-black text-blue-800">Community Group</p>
            </div>
          </a>
          <a href={urlSettings.whatsappChannel || "#"} target="_blank" rel="noreferrer" className="flex items-center gap-4 p-4 bg-emerald-50 rounded-2xl border border-emerald-100 hover:bg-emerald-100 transition-all group">
            <div className="p-3 bg-white rounded-xl text-emerald-600 shadow-sm group-hover:scale-110 transition-transform">
              <MessageCircle size={24} className="transform rotate-12" />
            </div>
            <div>
              <p className="text-xs font-bold text-emerald-400 uppercase tracking-widest">WhatsApp</p>
              <p className="text-sm font-black text-emerald-900">Updates Channel</p>
            </div>
          </a>
          <a href={urlSettings.instagramChannel || "#"} target="_blank" rel="noreferrer" className="flex items-center gap-4 p-4 bg-pink-50 rounded-2xl border border-pink-100 hover:bg-pink-100 transition-all group">
            <div className="p-3 bg-white rounded-xl text-pink-600 shadow-sm group-hover:scale-110 transition-transform">
              <Instagram size={24} />
            </div>
            <div>
              <p className="text-xs font-bold text-pink-400 uppercase tracking-widest">Instagram</p>
              <p className="text-sm font-black text-pink-900">Follow Us</p>
            </div>
          </a>
        </div>
      </div>
    </div>
  );
}
