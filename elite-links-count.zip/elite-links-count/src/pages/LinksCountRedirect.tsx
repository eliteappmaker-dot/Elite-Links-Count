import React, { useState, useEffect } from "react";
import { db } from "@/lib/firebase";
import { doc, updateDoc, increment } from "firebase/firestore";
import { ArrowRight, Lock, Send, MessageCircle, Instagram } from "lucide-react";
import { AdDisplay } from "@/components/AdDisplay";
import { BannerAdDisplay } from "@/components/BannerAdDisplay";
import { useAuth } from "@/contexts/AuthContext";

export function LinksCountRedirect({ linkData, adsSettings }: { linkData: any, adsSettings: any }) {
  const [isAdBlockerActive, setIsAdBlockerActive] = useState(false);
  const { urlSettings } = useAuth();

  useEffect(() => {
    // Basic AdBlocker detection
    const checkAdBlocker = () => {
      const ad = document.createElement('div');
      ad.innerHTML = '&nbsp;';
      ad.className = 'adsbox';
      document.body.appendChild(ad);
      window.setTimeout(() => {
        if (ad.offsetHeight === 0) {
          setIsAdBlockerActive(true);
        }
        ad.remove();
      }, 100);
    };
    checkAdBlocker();
  }, []);

  const countViewAndRedirect = async () => {
    if (!linkData) return;
    try {
      const today = new Date().toISOString().split('T')[0];
      const clickKey = `click_${linkData.id}`;
      const lastClick = localStorage.getItem(clickKey);
      const now = Date.now();
      
      // If clicked in last 24 hours, don't count but still redirect
      if (lastClick && now - parseInt(lastClick) < 24 * 60 * 60 * 1000) {
        console.log("View already counted today for this link.");
      } else {
        const linkRef = doc(db, "links", linkData.id);
        await updateDoc(linkRef, {
          totalClicks: increment(1),
          [`dailyClicks.${today}`]: increment(1)
        });
        localStorage.setItem(clickKey, now.toString());
      }
      
      window.location.href = linkData.originalURL;
    } catch (err) {
      console.error("Error counting view:", err);
      window.location.href = linkData.originalURL;
    }
  };

  const renderBannerAd = (key: string) => {
    if (!adsSettings.globalBannerAd) return null;
    return (
      <div key={key} className="flex flex-col items-center gap-4 my-6 w-full overflow-hidden">
        <BannerAdDisplay html={adsSettings.globalBannerAd} />
      </div>
    );
  };

  const renderGlobalAds = () => {
    return (
      <>
        {adsSettings.socialBarAd && <AdDisplay html={adsSettings.socialBarAd} />}
        {adsSettings.popunderAd && <AdDisplay html={adsSettings.popunderAd} />}
      </>
    );
  };

  if (isAdBlockerActive) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-gray-900 p-4 text-white">
        <Lock size={64} className="text-red-500 mb-6" />
        <h2 className="text-3xl font-black uppercase mb-4">AdBlocker Detected</h2>
        <p className="text-gray-400 max-w-md text-center mb-8">Please disable your AdBlocker to continue. Our platform relies on ads to provide free services to creators.</p>
        <button onClick={() => window.location.reload()} className="bg-emerald-600 px-8 py-3 rounded-2xl font-black uppercase">I've disabled it</button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col font-sans">
      {renderGlobalAds()}
      
      <div className="flex-1 flex flex-col items-center w-full max-w-4xl mx-auto px-4 py-8">
        
        {/* 1. Top Page Banner Ad */}
        <div className="w-full mb-8">
           {renderBannerAd("top-page-banner")}
        </div>

        {/* Extra Ad 1: Above Card */}
        <div className="w-full mb-8">
           {renderBannerAd("extra-top-banner")}
        </div>

        <div className="bg-white w-full rounded-[2rem] shadow-xl border border-gray-100 overflow-hidden">
          <div className="p-8 md:p-12 flex flex-col items-center text-center space-y-8">
            
            {/* Extra Ad 2: Inside Card Top */}
            <div className="w-full">
              {renderBannerAd("card-top-banner")}
            </div>
            
            {/* 2. Logo and Name */}
            <div className="flex flex-col items-center space-y-4">
              <img src="https://iili.io/qfdOijn.png" alt="Logo" className="h-24 md:h-28 object-contain" />
              <div className="flex flex-col items-center">
                <span className="font-righteous text-4xl md:text-5xl text-gradient leading-none">Elite Links</span>
                <span className="font-righteous text-3xl md:text-4xl text-gradient leading-none opacity-80">Count</span>
              </div>
            </div>

            {/* 3. Details Text */}
            <div className="bg-emerald-50/50 p-6 rounded-2xl border border-emerald-100/50 w-full">
              <div className="text-gray-600 font-medium leading-relaxed whitespace-pre-wrap text-sm md:text-base">
                {adsSettings.redirectDetails || (
                  <>
                    <p className="mb-4">
                      Welcome to Elite Links Count, the premium destination for secure and fast link redirection. We ensure that every link you visit is verified for safety and quality.
                    </p>
                    <p className="mb-4">
                      Our platform supports creators by providing a reliable way to share content. By proceeding, you acknowledge our terms of service and privacy policy.
                    </p>
                    <p>
                      Please wait a moment while we prepare your destination URL. Click the button below to continue to your requested content.
                    </p>
                  </>
                )}
              </div>
            </div>

            {/* 4. Banner Ad (Below Details) */}
            <div className="w-full">
              {renderBannerAd("middle-banner")}
            </div>

            {/* 5. Continue Button */}
            <div className="w-full max-w-md">
              <button
                onClick={countViewAndRedirect}
                className="w-full bg-emerald-600 text-white py-5 rounded-2xl font-black text-xl md:text-2xl uppercase tracking-widest hover:bg-emerald-700 transition-all flex items-center justify-center gap-3 shadow-lg shadow-emerald-200 hover:shadow-xl hover:scale-[1.02] active:scale-[0.98]"
              >
                Continue <ArrowRight size={28} />
              </button>
            </div>

            {/* 6. Banner Ad (Below Button) */}
            <div className="w-full">
              {renderBannerAd("bottom-banner")}
            </div>

          </div>
        </div>

        {/* Extra Ad 3: Below Card */}
        <div className="w-full mt-8">
           {renderBannerAd("extra-bottom-banner")}
        </div>

      </div>

      {/* 7. Footer */}
      <footer className="bg-white border-t border-gray-100 pt-12 pb-8 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
            {/* Brand Column */}
            <div className="col-span-1 md:col-span-2 space-y-4 text-center md:text-left">
              <div className="flex items-center justify-center md:justify-start gap-3">
                <img src="https://iili.io/qfdOijn.png" alt="Elite Links Count" className="h-12 object-contain" />
                <div className="flex flex-col">
                  <span className="font-righteous text-xl text-gradient leading-none">Elite Links</span>
                  <span className="font-righteous text-lg text-gradient leading-none opacity-80">Count</span>
                </div>
              </div>
              <p className="text-gray-500 text-sm max-w-sm mx-auto md:mx-0">
                Professional link monetization platform. Secure, fast, and reliable redirection services.
              </p>
              <div className="flex items-center justify-center md:justify-start gap-3">
                <a href={urlSettings.telegramChannel || "#"} target="_blank" rel="noreferrer" className="p-2 bg-gray-50 text-gray-400 hover:text-blue-500 hover:bg-blue-50 rounded-xl transition-all">
                  <Send size={18} />
                </a>
                <a href={urlSettings.whatsappChannel || "#"} target="_blank" rel="noreferrer" className="p-2 bg-gray-50 text-gray-400 hover:text-green-500 hover:bg-green-50 rounded-xl transition-all">
                  <MessageCircle size={18} />
                </a>
                <a href={urlSettings.instagramChannel || "#"} target="_blank" rel="noreferrer" className="p-2 bg-gray-50 text-gray-400 hover:text-pink-600 hover:bg-pink-50 rounded-xl transition-all">
                  <Instagram size={18} />
                </a>
              </div>
            </div>

            {/* Links Column 1 */}
            <div className="space-y-4 text-center md:text-left">
              <h4 className="text-xs font-black text-gray-900 uppercase tracking-widest">Legal</h4>
              <ul className="space-y-2 text-sm font-bold text-gray-500">
                <li><a href={urlSettings.privacyPolicy || "#"} target="_blank" rel="noreferrer" className="hover:text-emerald-600 transition-colors">Privacy Policy</a></li>
                <li><a href={urlSettings.useAndCondition || "#"} target="_blank" rel="noreferrer" className="hover:text-emerald-600 transition-colors">Terms of Use</a></li>
                <li><a href={urlSettings.adsCookies || "#"} target="_blank" rel="noreferrer" className="hover:text-emerald-600 transition-colors">Cookie Policy</a></li>
              </ul>
            </div>

            {/* Links Column 2 */}
            <div className="space-y-4 text-center md:text-left">
              <h4 className="text-xs font-black text-gray-900 uppercase tracking-widest">Support</h4>
              <ul className="space-y-2 text-sm font-bold text-gray-500">
                <li><a href={urlSettings.paymentIssue || "#"} target="_blank" rel="noreferrer" className="hover:text-emerald-600 transition-colors">Payment Support</a></li>
                <li><a href={urlSettings.websiteProblem || "#"} target="_blank" rel="noreferrer" className="hover:text-emerald-600 transition-colors">Report Issue</a></li>
                <li><a href={urlSettings.contactAdmin || "#"} target="_blank" rel="noreferrer" className="hover:text-emerald-600 transition-colors">Contact Us</a></li>
              </ul>
            </div>
          </div>

          <div className="pt-8 border-t border-gray-100 flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="text-xs font-bold text-gray-400 uppercase tracking-[0.3em]">v1.1</div>
            <div className="text-sm font-medium text-gray-500">&copy; {new Date().getFullYear()} Elite Links Count.</div>
          </div>
        </div>
      </footer>
    </div>
  );
}
