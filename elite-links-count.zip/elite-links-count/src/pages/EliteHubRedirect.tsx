import React, { useState, useEffect, useRef } from "react";
import { db } from "@/lib/firebase";
import { doc, updateDoc, increment } from "firebase/firestore";
import { ArrowRight, Lock, Send, MessageCircle, Instagram, CheckCircle, Clock } from "lucide-react";
import { BannerAdDisplay } from "@/components/BannerAdDisplay";
import { useAuth } from "@/contexts/AuthContext";

export function EliteHubRedirect({ linkData, adsSettings }: { linkData: any, adsSettings: any }) {
  const [isAdBlockerActive, setIsAdBlockerActive] = useState(false);
  const { urlSettings } = useAuth();
  
  // Flow States
  const [step, setStep] = useState(0); 
  // 0: Initial (I am not a robot)
  // 1: Timer Running
  // 2: Timer Done (Go to bottom)
  // 3: Bottom Link Clicked (Waiting/Verified)
  // 4: End Link 1 Clicked
  // 5: End Link 2 Clicked (Ready to Continue)

  const [timer, setTimer] = useState(10);
  const [isVerified, setIsVerified] = useState(false);
  const [verifying, setVerifying] = useState(false);

  useEffect(() => {
    // Basic AdBlocker detection
    const checkAdBlocker = () => {
      const ad = document.createElement('div');
      ad.innerHTML = '&nbsp;';
      ad.className = 'adsbox';
      document.body.appendChild(ad);
      window.setTimeout(() => {
        if (ad.offsetHeight === 0) {
          setIsAdBlockerActive(true);
        }
        ad.remove();
      }, 100);
    };
    checkAdBlocker();
  }, []);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (step === 1 && timer > 0) {
      interval = setInterval(() => {
        setTimer((prev) => prev - 1);
      }, 1000);
    } else if (step === 1 && timer === 0) {
      setStep(2);
    }
    return () => clearInterval(interval);
  }, [step, timer]);

  const handleRobotClick = () => {
    setStep(1);
  };

  const handleDirectLinkClick = (url: string, nextStep: number) => {
    if (url) {
      window.open(url, '_blank');
    }
    
    // Simulate verification/waiting
    setVerifying(true);
    setTimeout(() => {
      setVerifying(false);
      setStep(nextStep);
      if (nextStep === 3) setIsVerified(true); 
    }, 5000); 
  };

  const countViewAndRedirect = async () => {
    if (!linkData) return;
    try {
      const today = new Date().toISOString().split('T')[0];
      const clickKey = `click_${linkData.id}`;
      const lastClick = localStorage.getItem(clickKey);
      const now = Date.now();
      
      // If clicked in last 24 hours, don't count but still redirect
      if (lastClick && now - parseInt(lastClick) < 24 * 60 * 60 * 1000) {
        console.log("View already counted today for this link.");
      } else {
        const linkRef = doc(db, "links", linkData.id);
        await updateDoc(linkRef, {
          totalClicks: increment(1),
          [`dailyClicks.${today}`]: increment(1)
        });
        localStorage.setItem(clickKey, now.toString());
      }
      
      window.location.href = linkData.originalURL;
    } catch (err) {
      console.error("Error counting view:", err);
      window.location.href = linkData.originalURL;
    }
  };

  const getAdScript = (type: 'banner' | 'native', index: number) => {
    // Alternate between Script 1 and Script 2 based on index
    const isScript1 = index % 2 === 0;
    let script = '';
    
    if (type === 'banner') {
      script = isScript1 ? adsSettings.eliteBannerAd1 : adsSettings.eliteBannerAd2;
    } else {
      script = isScript1 ? adsSettings.eliteNativeAd1 : adsSettings.eliteNativeAd2;
    }

    // Fallback for demo/testing if no script is configured
    if (!script) {
      return `
        <div style="width:100%; height:250px; background:#f8f9fa; border:2px dashed #cbd5e1; border-radius:12px; display:flex; flex-direction:column; align-items:center; justify-content:center; color:#64748b; font-family:sans-serif;">
          <span style="font-weight:bold; font-size:16px;">${type === 'banner' ? 'BANNER' : 'NATIVE'} AD SLOT ${index + 1}</span>
          <span style="font-size:12px; margin-top:8px;">(Script ${isScript1 ? '1' : '2'} not configured)</span>
        </div>
      `;
    }

    return script;
  };

  const renderArticleContent = () => {
    // Generate a long article
    const paragraphs = [
      "Elite Hub is a premier platform designed to empower content creators and digital marketers. In today's fast-paced digital landscape, having the right tools to manage and monetize your links is crucial. Our service provides a seamless experience for shortening URLs while maximizing your earnings potential.",
      "Security is at the core of everything we do. We employ state-of-the-art encryption and verification processes to ensure that every link shared through our platform is safe for your audience. This builds trust and credibility, which are essential for long-term success in the online world.",
      "Our analytics dashboard offers real-time insights into your traffic. You can track clicks, geographic locations, and device types to better understand your audience. This data-driven approach allows you to optimize your campaigns and achieve higher conversion rates.",
      "Monetization with Elite Hub is straightforward and transparent. We offer competitive CPM rates and reliable payouts, ensuring that your hard work is rewarded. Whether you are a blogger, influencer, or business owner, our platform scales with your needs.",
      "User experience is paramount. We have designed our redirect pages to be clean, fast, and mobile-responsive. This ensures that your visitors have a positive experience, reducing bounce rates and increasing engagement with your content.",
      "We believe in community and support. Our dedicated support team is available to assist you with any questions or issues you may have. We also provide resources and guides to help you get the most out of our platform.",
      "Innovation drives us forward. We are constantly updating our features and technology to stay ahead of industry trends. From advanced link customization to API integrations, we provide the tools you need to succeed.",
      "Join thousands of satisfied users who have chosen Elite Hub as their trusted link management partner. Experience the difference of a platform built with your success in mind. Start shortening, sharing, and earning today.",
      "The digital economy is evolving, and we are here to help you navigate it. Our platform is built on a foundation of reliability and performance. We understand the challenges you face and provide solutions that work.",
      "Transparency is key to our relationship with our users. We provide detailed reports and clear communication about our policies and updates. You can trust us to be a partner in your growth.",
      "Our infrastructure is robust and scalable. We handle millions of requests daily with 99.9% uptime. This reliability ensures that your links are always accessible when your audience needs them.",
      "We are committed to privacy and data protection. We adhere to strict data policies to safeguard your information and that of your visitors. Your trust is our most valuable asset.",
      "Elite Hub is more than just a link shortener; it's a comprehensive tool for digital success. Explore our features and see how we can help you achieve your goals. The future of link management is here.",
      "Content distribution is made easy with our platform. Share your links across social media, email, and websites with confidence. Our tools ensure that your content reaches the right audience at the right time.",
      "We value your feedback. Our roadmap is influenced by the needs and suggestions of our community. Together, we are building the best link management platform in the world."
    ];

    // Repeat paragraphs to make it very long (4x)
    const longContent = [...paragraphs, ...paragraphs, ...paragraphs, ...paragraphs];
    const midPoint = Math.ceil(longContent.length / 2);
    const firstHalf = longContent.slice(0, midPoint);
    const secondHalf = longContent.slice(midPoint);
    
    let bannerIndex = 0;
    let nativeIndex = 0;
    let globalLineCount = 0;

    const renderParagraphs = (content: string[]) => {
      return content.map((para, index) => {
        globalLineCount++;
        const lineNum = globalLineCount;
        
        // Updated Frequency: Banner every 2 lines, Native every 3 lines
        const showBanner = lineNum % 2 === 0;
        const showNative = lineNum % 3 === 0;

        return (
          <React.Fragment key={`${lineNum}-${index}`}>
            <p className="mb-4 text-gray-600 leading-relaxed">{para}</p>
            
            {showBanner && (
              <div className="my-8 w-full flex justify-center overflow-hidden">
                 <BannerAdDisplay html={getAdScript('banner', bannerIndex++)} />
              </div>
            )}
            
            {showNative && (
              <div className="my-8 w-full flex justify-center overflow-hidden">
                 <BannerAdDisplay html={getAdScript('native', nativeIndex++)} />
              </div>
            )}
          </React.Fragment>
        );
      });
    };

    return (
      <>
        {renderParagraphs(firstHalf)}
        
        {/* Middle Verification Task */}
        <div className="my-12 p-6 bg-blue-50 rounded-2xl border border-blue-100 flex flex-col items-center text-center space-y-4">
          <h4 className="text-xl font-bold text-blue-900">Verification Required</h4>
          <p className="text-blue-700">Complete this step to read the rest of the article and continue.</p>
          
          {step === 2 ? (
            <button
              onClick={() => handleDirectLinkClick(adsSettings.eliteDirectLinkBottom, 3)}
              disabled={verifying}
              className="w-full max-w-md bg-blue-600 text-white py-4 rounded-xl font-bold text-lg uppercase tracking-wider hover:bg-blue-700 transition-all shadow-lg shadow-blue-200 animate-bounce disabled:opacity-70 disabled:cursor-wait flex items-center justify-center gap-2"
            >
              {verifying ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                  Verifying...
                </>
              ) : (
                "Click here and wait 5 seconds"
              )}
            </button>
          ) : step >= 3 ? (
            <div className="bg-green-100 text-green-800 px-6 py-3 rounded-full font-bold inline-flex items-center gap-2">
              <CheckCircle size={20} /> Verified
            </div>
          ) : (
            <div className="text-gray-400 italic">Complete previous steps first...</div>
          )}
        </div>

        {/* Second Half - Only show if verified */}
        {step >= 3 && (
          <div className="animate-in fade-in slide-in-from-bottom-8 duration-700">
            {renderParagraphs(secondHalf)}
          </div>
        )}
      </>
    );
  };

  if (isAdBlockerActive) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-gray-900 p-4 text-white">
        <Lock size={64} className="text-red-500 mb-6" />
        <h2 className="text-3xl font-black uppercase mb-4">AdBlocker Detected</h2>
        <p className="text-gray-400 max-w-md text-center mb-8">Please disable your AdBlocker to continue. Our platform relies on ads to provide free services to creators.</p>
        <button onClick={() => window.location.reload()} className="bg-emerald-600 px-8 py-3 rounded-2xl font-black uppercase">I've disabled it</button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col font-sans">
      
      <div className="flex-1 flex flex-col items-center w-full max-w-4xl mx-auto px-4 py-8">
        
        {/* 1. Top Page Banner Ad */}
        <div className="w-full mb-8">
           <BannerAdDisplay html={getAdScript('banner', 0)} />
        </div>

        {/* 2. Logo and Name */}
        <div className="flex flex-col items-center space-y-4 mb-8">
          <img src="https://iili.io/qfdOijn.png" alt="Logo" className="h-24 md:h-28 object-contain" />
          <div className="flex flex-col items-center">
            <span className="font-righteous text-4xl md:text-5xl text-gradient leading-none">Elite Hub</span>
            <span className="font-righteous text-3xl md:text-4xl text-gradient leading-none opacity-80">Shortener</span>
          </div>
        </div>

        {/* 3. Short Details */}
        <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm w-full mb-8 text-center">
          <p className="text-gray-600 font-medium text-sm md:text-base max-w-2xl mx-auto">
            Welcome to Elite Hub. We provide secure and fast link shortening services. 
            Please verify that you are human to proceed to your destination. 
            Follow the instructions below to unlock your content.
          </p>
        </div>

        {/* 4. I am not a robot Section */}
        <div className="w-full max-w-md space-y-6 mb-12">
          {/* Banner Above Button */}
          <div className="w-full">
            <BannerAdDisplay html={getAdScript('banner', 1)} />
          </div>

          {step === 0 ? (
            <button
              onClick={handleRobotClick}
              className="w-full bg-white border-2 border-gray-200 hover:border-emerald-500 text-gray-700 py-4 rounded-xl font-bold text-lg flex items-center justify-center gap-3 transition-all shadow-sm hover:shadow-md group"
            >
              <div className="w-6 h-6 border-2 border-gray-300 rounded-md group-hover:border-emerald-500"></div>
              I am not a robot
            </button>
          ) : step === 1 ? (
             <div className="w-full bg-white border-2 border-emerald-500 text-emerald-700 py-4 rounded-xl font-bold text-lg flex items-center justify-center gap-3 shadow-sm">
               <Clock className="animate-pulse" />
               Please wait {timer}s...
             </div>
          ) : (
            <div className="w-full bg-emerald-50 border-2 border-emerald-200 text-emerald-700 py-4 rounded-xl font-bold text-lg flex items-center justify-center gap-3 shadow-sm">
              <CheckCircle />
              Verified! Go to the bottom
            </div>
          )}

          {/* Banner Below Button */}
          <div className="w-full">
            <BannerAdDisplay html={getAdScript('banner', 2)} />
          </div>
        </div>

        {/* 5. Long Article with Injected Ads */}
        {step >= 2 && (
          <div className="w-full bg-white p-8 rounded-3xl shadow-xl border border-gray-100 mb-12">
            <h3 className="text-2xl font-bold text-gray-900 mb-6">About Elite Hub Services</h3>
            {renderArticleContent()}
          </div>
        )}

        {/* 6. Bottom Section */}
        {step >= 2 && (
          <div className="w-full max-w-md space-y-8 mb-12 flex flex-col items-center">
            <div className="w-full">
              <BannerAdDisplay html={getAdScript('banner', 3)} />
            </div>

            {step >= 3 && (
              <div className="w-full text-center space-y-6">
                <div className="bg-emerald-100 text-emerald-800 px-6 py-3 rounded-full font-bold inline-flex items-center gap-2">
                  <CheckCircle size={20} /> Verified
                </div>
                
                <p className="text-xl font-black text-gray-900 uppercase">Scroll down to the end</p>
                
                {/* End Direct Links */}
                <div className="space-y-4 pt-8">
                  {step === 3 && (
                    <button
                      onClick={() => handleDirectLinkClick(adsSettings.eliteDirectLinkEnd1, 4)}
                      disabled={verifying}
                      className="w-full bg-indigo-600 text-white py-4 rounded-xl font-bold text-lg uppercase tracking-wider hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200 disabled:opacity-70 disabled:cursor-wait flex items-center justify-center gap-2"
                    >
                      {verifying ? (
                        <>
                          <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                          Verifying...
                        </>
                      ) : (
                        "Click to Continue (1/2)"
                      )}
                    </button>
                  )}

                  {step === 4 && (
                    <button
                      onClick={() => handleDirectLinkClick(adsSettings.eliteDirectLinkEnd2, 5)}
                      disabled={verifying}
                      className="w-full bg-purple-600 text-white py-4 rounded-xl font-bold text-lg uppercase tracking-wider hover:bg-purple-700 transition-all shadow-lg shadow-purple-200 disabled:opacity-70 disabled:cursor-wait flex items-center justify-center gap-2"
                    >
                      {verifying ? (
                        <>
                          <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                          Verifying...
                        </>
                      ) : (
                        "Click to Continue (2/2)"
                      )}
                    </button>
                  )}

                  {step === 5 && (
                    <button
                      onClick={countViewAndRedirect}
                      className="w-full bg-emerald-600 text-white py-5 rounded-2xl font-black text-xl md:text-2xl uppercase tracking-widest hover:bg-emerald-700 transition-all flex items-center justify-center gap-3 shadow-lg shadow-emerald-200 hover:shadow-xl hover:scale-[1.02] active:scale-[0.98]"
                    >
                      Continue <ArrowRight size={28} />
                    </button>
                  )}
                </div>
              </div>
            )}
          </div>
        )}

      </div>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-100 pt-12 pb-8 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
            {/* Brand Column */}
            <div className="col-span-1 md:col-span-2 space-y-4 text-center md:text-left">
              <div className="flex items-center justify-center md:justify-start gap-3">
                <img src="https://iili.io/qfdOijn.png" alt="Elite Hub" className="h-12 object-contain" />
                <div className="flex flex-col">
                  <span className="font-righteous text-xl text-gradient leading-none">Elite Hub</span>
                  <span className="font-righteous text-lg text-gradient leading-none opacity-80">Shortener</span>
                </div>
              </div>
              <p className="text-gray-500 text-sm max-w-sm mx-auto md:mx-0">
                Professional link monetization platform. Secure, fast, and reliable redirection services.
              </p>
              <div className="flex items-center justify-center md:justify-start gap-3">
                <a href={urlSettings.telegramChannel || "#"} target="_blank" rel="noreferrer" className="p-2 bg-gray-50 text-gray-400 hover:text-blue-500 hover:bg-blue-50 rounded-xl transition-all">
                  <Send size={18} />
                </a>
                <a href={urlSettings.whatsappChannel || "#"} target="_blank" rel="noreferrer" className="p-2 bg-gray-50 text-gray-400 hover:text-green-500 hover:bg-green-50 rounded-xl transition-all">
                  <MessageCircle size={18} />
                </a>
                <a href={urlSettings.instagramChannel || "#"} target="_blank" rel="noreferrer" className="p-2 bg-gray-50 text-gray-400 hover:text-pink-600 hover:bg-pink-50 rounded-xl transition-all">
                  <Instagram size={18} />
                </a>
              </div>
            </div>

            {/* Links Column 1 */}
            <div className="space-y-4 text-center md:text-left">
              <h4 className="text-xs font-black text-gray-900 uppercase tracking-widest">Legal</h4>
              <ul className="space-y-2 text-sm font-bold text-gray-500">
                <li><a href={urlSettings.privacyPolicy || "#"} target="_blank" rel="noreferrer" className="hover:text-emerald-600 transition-colors">Privacy Policy</a></li>
                <li><a href={urlSettings.useAndCondition || "#"} target="_blank" rel="noreferrer" className="hover:text-emerald-600 transition-colors">Terms of Use</a></li>
                <li><a href={urlSettings.adsCookies || "#"} target="_blank" rel="noreferrer" className="hover:text-emerald-600 transition-colors">Cookie Policy</a></li>
              </ul>
            </div>

            {/* Links Column 2 */}
            <div className="space-y-4 text-center md:text-left">
              <h4 className="text-xs font-black text-gray-900 uppercase tracking-widest">Support</h4>
              <ul className="space-y-2 text-sm font-bold text-gray-500">
                <li><a href={urlSettings.paymentIssue || "#"} target="_blank" rel="noreferrer" className="hover:text-emerald-600 transition-colors">Payment Support</a></li>
                <li><a href={urlSettings.websiteProblem || "#"} target="_blank" rel="noreferrer" className="hover:text-emerald-600 transition-colors">Report Issue</a></li>
                <li><a href={urlSettings.contactAdmin || "#"} target="_blank" rel="noreferrer" className="hover:text-emerald-600 transition-colors">Contact Us</a></li>
              </ul>
            </div>
          </div>

          <div className="pt-8 border-t border-gray-100 flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="text-xs font-bold text-gray-400 uppercase tracking-[0.3em]">v1.1</div>
            <div className="text-sm font-medium text-gray-500">&copy; {new Date().getFullYear()} Elite Hub.</div>
          </div>
        </div>
      </footer>
    </div>
  );
}
