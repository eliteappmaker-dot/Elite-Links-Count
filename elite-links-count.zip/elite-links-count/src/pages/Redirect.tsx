import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { db } from "@/lib/firebase";
import { collection, query, where, getDocs, doc, getDoc, updateDoc, increment } from "firebase/firestore";
import { AlertCircle, Lock } from "lucide-react";
import { EliteHubRedirect } from "./EliteHubRedirect";
import { LinksCountRedirect } from "./LinksCountRedirect";
import { AdDisplay } from "@/components/AdDisplay";

export function Redirect() {
  const { id } = useParams();
  const { isAdmin } = useAuth();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [linkData, setLinkData] = useState<any>(null);
  const [adsSettings, setAdsSettings] = useState<any>({});
  const [isAdBlockerActive, setIsAdBlockerActive] = useState(false);

  useEffect(() => {
    // Advanced AdBlocker detection
    const checkAdBlocker = async () => {
      // Bait 1: adsbox element
      const ad = document.createElement('div');
      ad.innerHTML = '&nbsp;';
      ad.className = 'adsbox adbox pub_300x250 pub_300x250m pub_728x90 text-ad textAd text_ad text_ads text-ads';
      ad.style.position = 'absolute';
      ad.style.left = '-1000px';
      document.body.appendChild(ad);

      setTimeout(async () => {
        const isAdsBoxBlocked = ad.offsetHeight === 0 || ad.clientWidth === 0;
        
        let isFetchBlocked = false;
        try {
          // Bait 2: Fetching actual ad script path
          await fetch('https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js', { 
            method: 'HEAD', 
            mode: 'no-cors' 
          });
        } catch (e) {
          isFetchBlocked = true;
        }

        if (isAdsBoxBlocked || isFetchBlocked) {
          setIsAdBlockerActive(true);
        }
        ad.remove();
      }, 500);
    };
    checkAdBlocker();

    const fetchData = async () => {
      if (!id) {
        setError("Invalid URL access. Please use a valid link.");
        setLoading(false);
        return;
      }

      // Admin Preview Logic
      if (isAdmin && (id === "preview-links-count" || id === "preview-elite-hub")) {
        setLinkData({
          linkID: "preview",
          originalURL: "https://example.com",
          shortenerType: id === "preview-links-count" ? "links-count" : "elite-hub",
          adTier: "standard",
          cpm: 500,
          createdAt: { toMillis: () => Date.now() },
          totalClicks: 0
        });
        
        // Fetch ad settings for preview
        try {
          const adsSnap = await getDoc(doc(db, "settings", "ads"));
          if (adsSnap.exists()) setAdsSettings(adsSnap.data());
        } catch (err) {
          console.error("Error fetching ads settings for preview:", err);
        }
        
        setLoading(false);
        return;
      }

      try {
        const q = query(collection(db, "links"), where("linkID", "==", id));
        const querySnapshot = await getDocs(q);
        
        if (querySnapshot.empty) {
          setError("Link not found or expired.");
          return;
        }

        const data = querySnapshot.docs[0].data();
        const linkDocRef = doc(db, "links", querySnapshot.docs[0].id);
        data.id = querySnapshot.docs[0].id;
        
        // Count Raw Click (Initial visit)
        const today = new Date().toISOString().split('T')[0];
        try {
          await updateDoc(linkDocRef, {
            rawClicks: increment(1),
            [`dailyRawClicks.${today}`]: increment(1)
          });
        } catch (updateErr) {
          console.error("Error updating raw clicks:", updateErr);
        }

        setLinkData(data);

        const adsSnap = await getDoc(doc(db, "settings", "ads"));
        if (adsSnap.exists()) setAdsSettings(adsSnap.data());

      } catch (err) {
        console.error("Error fetching data:", err);
        setError("An error occurred while fetching the link.");
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [id]);

  const renderGlobalAds = () => {
    return (
      <>
        {adsSettings.socialBarAd && <AdDisplay html={adsSettings.socialBarAd} />}
        {adsSettings.popunderAd && <AdDisplay html={adsSettings.popunderAd} />}
      </>
    );
  };

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-gray-50 p-4">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-600"></div>
      </div>
    );
  }

  if (isAdBlockerActive) {
    return (
      <div className="fixed inset-0 z-[10000] flex flex-col items-center justify-center bg-gray-950 p-4 text-white text-center select-none">
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-20"></div>
        
        <div className="relative bg-gray-900 p-10 rounded-[2.5rem] border-2 border-red-500/40 shadow-[0_0_50px_rgba(239,68,68,0.2)] max-w-md w-full backdrop-blur-xl space-y-8 animate-in zoom-in duration-500">
          <div className="relative">
            <div className="absolute inset-0 bg-red-500 blur-3xl opacity-20"></div>
            <Lock size={80} className="text-red-500 mx-auto relative animate-pulse" />
          </div>
          
          <div className="space-y-4">
            <h2 className="text-3xl font-black uppercase tracking-tighter text-red-500 leading-none">
              AdBlocker Detected
            </h2>
            <p className="text-gray-400 text-lg font-bold leading-relaxed">
              Please close your ads block and continue this website
            </p>
          </div>

          <div className="bg-red-500/10 border border-red-500/20 p-4 rounded-2xl">
            <p className="text-xs text-red-400 font-bold uppercase tracking-widest leading-loose">
              Our platform relies on ads to provide free link shortening services. Please support us by disabling your blocker.
            </p>
          </div>

          <button 
            onClick={() => window.location.reload()} 
            className="group relative w-full overflow-hidden bg-white text-gray-900 px-8 py-5 rounded-2xl font-black uppercase tracking-[0.2em] transition-all hover:scale-105 active:scale-95 shadow-xl shadow-white/10"
          >
            <span className="relative z-10">Refresh Page</span>
            <div className="absolute inset-0 bg-emerald-500 translate-y-full group-hover:translate-y-0 transition-transform duration-300"></div>
          </button>
          
          <div className="pt-2">
            <p className="text-[10px] text-gray-600 font-bold uppercase tracking-widest">
              Elite Links Count &copy; 2026
            </p>
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-gray-50 p-4">
        <div className="bg-white p-8 rounded-3xl border border-red-100 shadow-xl text-center max-w-md w-full">
          <AlertCircle className="mx-auto h-16 w-16 text-red-500 mb-4" />
          <h2 className="text-2xl font-black text-gray-900 mb-2 uppercase">Link Error</h2>
          <p className="text-gray-600 mb-8 font-medium">{error}</p>
          <a href="/" className="inline-block bg-emerald-600 text-white px-8 py-3 rounded-2xl font-black uppercase tracking-widest hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-100">
            Back to Home
          </a>
        </div>
      </div>
    );
  }

  return (
    <>
      {renderGlobalAds()}
      {linkData.shortenerType === "elite-hub" ? (
        <EliteHubRedirect linkData={linkData} adsSettings={adsSettings} />
      ) : (
        <LinksCountRedirect linkData={linkData} adsSettings={adsSettings} />
      )}
    </>
  );
}
