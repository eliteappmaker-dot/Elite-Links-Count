import React from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { TrendingUp, Info, Send, MessageCircle } from 'lucide-react';

export function EarningPolicy() {
  const { urlSettings } = useAuth();

  return (
    <div className="max-w-4xl mx-auto py-12 px-4">
      <div className="bg-white rounded-3xl shadow-xl border border-gray-100 overflow-hidden">
        <div className="bg-emerald-600 p-8 text-white">
          <div className="flex items-center gap-4 mb-4">
            <TrendingUp size={40} />
            <h1 className="text-3xl font-black uppercase tracking-tight">Earning Policy</h1>
          </div>
          <p className="text-emerald-50 opacity-90 font-medium">Understanding how your earnings work.</p>
        </div>
        
        <div className="p-8 md:p-12 space-y-10">
          <section className="space-y-4">
            <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2">
              <Info className="text-emerald-600" size={24} /> Earnings Disclaimer
            </h2>
            <p className="text-gray-600 leading-relaxed">
              Please note that earnings from views are not fixed or limited. Your revenue depends entirely on user actions and the performance of advertisements. Earnings can fluctuate significantly—sometimes appearing very high and other times lower—based on market conditions, ad inventory, and user engagement.
            </p>
          </section>

          <section className="space-y-4">
            <h2 className="text-xl font-bold text-gray-900">Stay Updated</h2>
            <p className="text-gray-600 leading-relaxed">
              To get the latest updates regarding earning rates, policy changes, and platform news, we highly recommend joining our official channels.
            </p>
            <div className="flex flex-wrap gap-4 pt-2">
              {urlSettings.whatsappChannel && (
                <a 
                  href={urlSettings.whatsappChannel} 
                  target="_blank" 
                  rel="noreferrer"
                  className="flex items-center gap-2 bg-[#25D366] hover:bg-[#20bd5a] text-white px-6 py-3 rounded-xl font-bold transition-all shadow-lg shadow-green-900/20"
                >
                  <MessageCircle size={20} /> Join WhatsApp Channel
                </a>
              )}
              {urlSettings.telegramChannel && (
                <a 
                  href={urlSettings.telegramChannel} 
                  target="_blank" 
                  rel="noreferrer"
                  className="flex items-center gap-2 bg-[#0088cc] hover:bg-[#0077b5] text-white px-6 py-3 rounded-xl font-bold transition-all shadow-lg shadow-blue-900/20"
                >
                  <Send size={20} /> Join Telegram Channel
                </a>
              )}
            </div>
          </section>

          <section className="space-y-4">
            <h2 className="text-xl font-bold text-gray-900">Need Support?</h2>
            <p className="text-gray-600 leading-relaxed">
              If you have any questions or need assistance, our support team is here to help.
            </p>
            <div className="pt-4">
              {urlSettings.contactAdmin && (
                <a href={urlSettings.contactAdmin} target="_blank" rel="noreferrer" className="bg-emerald-600 text-white px-8 py-3 rounded-2xl font-bold hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-100 inline-block">
                  Contact Support
                </a>
              )}
            </div>
          </section>

          <div className="pt-8 border-t border-gray-100">
            <p className="text-sm text-gray-500 font-medium">Last Updated: {new Date().toLocaleDateString()}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
