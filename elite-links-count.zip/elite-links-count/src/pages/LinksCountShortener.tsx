import React, { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { db } from "@/lib/firebase";
import { collection, addDoc, query, where, getDocs, Timestamp, deleteDoc, doc } from "firebase/firestore";
import { generateId, calculateEarnings } from "@/lib/utils";
import { Copy, ExternalLink, Link as LinkIcon, TrendingUp, Clock, IndianRupee, Calendar, X, Trash2, AlertTriangle } from "lucide-react";
import toast from "react-hot-toast";
import { Link, useNavigate } from "react-router-dom";
import { DeleteConfirmModal } from "@/components/DeleteConfirmModal";
import { VerificationModal } from "@/components/VerificationModal";

export function LinksCountShortener() {
  const { user, userProfile, appSettings } = useAuth();
  const navigate = useNavigate();
  const [url, setUrl] = useState("");
  const [loading, setLoading] = useState(false);
  const [links, setLinks] = useState<any[]>([]);
  const [selectedLink, setSelectedLink] = useState<any | null>(null);
  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [linkToDelete, setLinkToDelete] = useState<string | null>(null);
  const [verificationModalOpen, setVerificationModalOpen] = useState(false);

  useEffect(() => {
    if (user) {
      fetchLinks();
      const interval = setInterval(fetchLinks, 60000);
      return () => clearInterval(interval);
    }
  }, [user]);

  const fetchLinks = async () => {
    if (!user) return;
    try {
      const q = query(
        collection(db, "links"),
        where("userID", "==", user.uid),
        where("shortenerType", "==", "links-count")
      );
      const querySnapshot = await getDocs(q);
      const now = Date.now();
      const thirtyMinutesAgo = now - (30 * 60 * 1000);

      const fetchedLinks = querySnapshot.docs
        .map(doc => ({ id: doc.id, ...doc.data() }))
        .filter((link: any) => {
          const createdAt = link.createdAt?.toMillis() || 0;
          return createdAt >= thirtyMinutesAgo;
        });
      
      fetchedLinks.sort((a: any, b: any) => {
        const dateA = a.createdAt?.toMillis() || 0;
        const dateB = b.createdAt?.toMillis() || 0;
        return dateB - dateA;
      });
      
      setLinks(fetchedLinks);
    } catch (error) {
      console.error("Error fetching links:", error);
    }
  };

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!url) return toast.error("Please enter a URL");
    if (!url.startsWith("http://") && !url.startsWith("https://")) {
      return toast.error("URL must start with http:// or https://");
    }
    if (!user) return toast.error("Please login to generate links");

    // Verification Check
    if (!userProfile?.isLinksCountVerified) {
      setVerificationModalOpen(true);
      return;
    }

    try {
      const linkID = generateId(12);
      const currentCPM = appSettings.cpmLinksCount || 500;
      const baseUrl = "https://elitelinkscount.netlify.app";
      
      const domain = "elitelinkscount.netlify.app";
      const shortUrl = `${domain}/links-count/${linkID}`;
      const fullShortUrl = `${baseUrl}/links-count/${linkID}`;
      
      const newLink = {
        linkID,
        originalURL: url,
        userID: user.uid,
        userName: user.displayName || 'Anonymous',
        userEmail: user.email,
        createdAt: Timestamp.now(),
        totalClicks: 0,
        dailyClicks: {},
        earnings: 0,
        cpm: currentCPM,
        adTier: "standard",
        shortenerType: "links-count",
        shortUrl: shortUrl,
        fullShortUrl: fullShortUrl
      };

      await addDoc(collection(db, "links"), newLink);
      toast.success("Links Count Link generated successfully!");
      setUrl("");
      fetchLinks();
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success("Copied to clipboard!");
  };

  const handleDeleteClick = (id: string) => {
    setLinkToDelete(id);
    setDeleteModalOpen(true);
  };

  const confirmDelete = async () => {
    if (!linkToDelete) return;
    try {
      await deleteDoc(doc(db, "links", linkToDelete));
      toast.success("Link deleted successfully");
      fetchLinks();
    } catch (error) {
      toast.error("Error deleting link");
    } finally {
      setLinkToDelete(null);
    }
  };

  const isExpired = (link: any) => {
    if (!link.createdAt) return false;
    const createdAt = link.createdAt.toMillis();
    const now = Date.now();
    const diffDays = (now - createdAt) / (1000 * 60 * 60 * 24);
    return diffDays > 30 && (link.totalClicks || 0) <= 400;
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="text-center space-y-6 py-12">
        <div className="flex flex-col items-center justify-center mb-4">
          <h1 className="font-righteous text-5xl md:text-7xl text-gradient tracking-tighter leading-none">Links Count</h1>
          <h2 className="font-righteous text-4xl md:text-6xl text-gradient tracking-widest leading-none opacity-80">Shortener</h2>
        </div>
        <p className="text-lg md:text-xl text-gray-600 max-w-2xl mx-auto font-medium">
          Exclusive link shortener for Links Count.
        </p>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6 md:p-8 space-y-6">
        <form onSubmit={!user ? (e) => { e.preventDefault(); navigate('/login'); } : handleGenerate} className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
              <LinkIcon className="h-5 w-5 text-gray-400" />
            </div>
            <input
              type="url"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="Paste your long URL here (https://...)"
              className="block w-full pl-11 pr-4 py-4 border-gray-300 rounded-xl focus:ring-emerald-500 focus:border-emerald-500 text-lg bg-gray-50 border transition-colors"
              required
            />
          </div>
          <button
            type="submit"
            disabled={loading}
            className="bg-emerald-600 hover:bg-emerald-700 text-white px-8 py-4 rounded-xl font-bold text-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 whitespace-nowrap shadow-sm"
          >
            {!user ? "Login to Generate" : loading ? "Generating..." : "Generate Link"}
          </button>
        </form>

        {url && user && (
          <div className="space-y-4 animate-in fade-in slide-in-from-top-4 duration-300">
            <div className="p-4 bg-blue-50 rounded-xl border border-blue-100 text-blue-800 text-sm">
              Estimated Earning: <span className="font-bold">₹{appSettings.cpmLinksCount || 500}</span> per 1000 views.
            </div>
          </div>
        )}
      </div>

      {links.length > 0 && (
        <div className="space-y-4">
          <h3 className="text-xl font-bold text-gray-900 flex items-center gap-2">
            <Clock className="text-emerald-600" /> Recent Links Count Links (Last 30 Mins)
          </h3>
          <div className="grid gap-4">
            {links.map((link) => {
              const baseUrl = "https://elitelinkscount.netlify.app";
              const domain = "elitelinkscount.netlify.app";
              
              // Use stored URLs if available, otherwise generate dynamically
              const shortUrl = link.shortUrl || `${domain}/links-count/${link.linkID}`;
              const fullShortUrl = link.fullShortUrl || `${baseUrl}/links-count/${link.linkID}`;
              
              const linkCPM = link.cpm || appSettings.cpmLinksCount || 500;
              const expired = isExpired(link);
              
              return (
                <div key={link.id} className={`bg-white rounded-2xl border p-5 hover:shadow-md transition-shadow w-full overflow-hidden ${expired ? 'border-red-200 opacity-75' : 'border-gray-200'}`}>
                  <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 w-full overflow-hidden">
                    
                    <div className="space-y-2 flex-1 min-w-0 w-full overflow-hidden">
                      <div className="flex items-center gap-2 w-full overflow-hidden">
                        <a href={fullShortUrl} target="_blank" rel="noreferrer" className={`${expired ? 'text-gray-400' : 'text-emerald-600'} font-bold text-lg truncate hover:underline flex-1`}>
                          {shortUrl}
                        </a>
                        <div className="flex items-center gap-1 flex-shrink-0">
                          <button 
                            onClick={() => copyToClipboard(fullShortUrl)} 
                            className="p-2 text-gray-500 hover:text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors"
                            title="Copy Link"
                          >
                            <Copy size={18} />
                          </button>
                          <button 
                            onClick={() => handleDeleteClick(link.id)} 
                            className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                            title="Delete Link"
                          >
                            <Trash2 size={18} />
                          </button>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-gray-500 w-full overflow-hidden">
                        <ExternalLink size={14} className="flex-shrink-0" />
                        <span className="truncate">{link.originalURL}</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="text-xs text-gray-400">
                          {link.createdAt?.toDate().toLocaleString()}
                        </span>
                        {expired && (
                          <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-full bg-red-600 text-white flex items-center gap-1">
                            <AlertTriangle size={10} /> Expired
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="flex flex-row md:flex-col gap-4 md:gap-2 w-full md:w-auto justify-between md:justify-center bg-gray-50 md:bg-transparent p-3 md:p-0 rounded-xl">
                      <div className="text-center md:text-right">
                        <div className="text-xs text-gray-500 font-medium uppercase tracking-wider mb-1 flex items-center justify-center md:justify-end gap-1">
                          <TrendingUp size={12} /> Clicks
                        </div>
                        <div className="font-black text-xl text-gray-900">{link.totalClicks || 0}</div>
                      </div>
                      <div className="text-center md:text-right">
                        <div className="text-xs text-gray-500 font-medium uppercase tracking-wider mb-1 flex items-center justify-center md:justify-end gap-1">
                          <IndianRupee size={12} /> Earned
                        </div>
                        <div className="font-black text-xl text-emerald-600">₹{calculateEarnings(link.totalClicks || 0, linkCPM).toFixed(2)}</div>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      <DeleteConfirmModal 
        isOpen={deleteModalOpen}
        onClose={() => {
          setDeleteModalOpen(false);
          setLinkToDelete(null);
        }}
        onConfirm={confirmDelete}
      />

      <VerificationModal
        isOpen={verificationModalOpen}
        onClose={() => setVerificationModalOpen(false)}
      />

      {user && (
        <div className="flex justify-center pt-4">
          <button
            onClick={() => navigate('/wallet')}
            className="bg-gray-900 hover:bg-gray-800 text-white px-8 py-4 rounded-xl font-bold text-lg transition-colors shadow-sm w-full md:w-auto"
          >
            Go To Wallet Page
          </button>
        </div>
      )}
    </div>
  );
}
