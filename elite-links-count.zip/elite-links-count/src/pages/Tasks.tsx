import React, { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { db } from "@/lib/firebase";
import { collection, query, where, getDocs, doc, getDoc, updateDoc, setDoc, Timestamp, increment } from "firebase/firestore";
import { Clock, Gift, CheckCircle, Lock, TrendingUp, IndianRupee, Calendar, Award, ChevronRight, Users } from "lucide-react";
import { calculateEarnings } from "@/lib/utils";
import toast from "react-hot-toast";

type TaskType = 'views' | 'earnings' | 'withdrawals' | 'links-count-views' | 'single-link-views' | 'referrals';

interface Task {
  id: string;
  title: string;
  description: string;
  reward: number;
  target: number;
  type: TaskType;
}

const TASKS: Record<string, Task[]> = {
  daily: [
    { id: 'd1', title: 'Daily Views', description: 'Complete 1,000 views today', reward: 5, target: 1000, type: 'views' },
    { id: 'd2', title: 'Links Count Views', description: 'Complete 800 views on Links Count shortener', reward: 5, target: 800, type: 'links-count-views' },
    { id: 'd3', title: 'Single Link Hit', description: 'Get 100 clicks on any single link', reward: 2, target: 100, type: 'single-link-views' },
    { id: 'd4', title: 'Daily Earnings', description: 'Earn ₹90 today', reward: 3, target: 90, type: 'earnings' },
    { id: 'd5', title: 'Daily Invites', description: 'Invite 5 users today', reward: 2, target: 5, type: 'referrals' }
  ],
  weekly: [
    { id: 'w1', title: 'Weekly Views', description: 'Complete 10,000 views this week', reward: 15, target: 10000, type: 'views' },
    { id: 'w2', title: 'Weekly Earnings', description: 'Earn ₹400 this week', reward: 10, target: 400, type: 'earnings' },
    { id: 'w3', title: 'Weekly Withdrawal', description: 'Withdraw ₹500 this week', reward: 10, target: 500, type: 'withdrawals' },
    { id: 'w4', title: 'Weekly Invites', description: 'Invite 50 users this week', reward: 10, target: 50, type: 'referrals' }
  ],
  monthly: [
    { id: 'm1', title: 'Monthly Views', description: 'Complete 1,00,000 views this month', reward: 30, target: 100000, type: 'views' },
    { id: 'm2', title: 'Viral Link', description: 'Get 90,000 views on a single link', reward: 30, target: 90000, type: 'single-link-views' },
    { id: 'm3', title: 'Monthly Invites', description: 'Invite 100 users this month', reward: 20, target: 100, type: 'referrals' }
  ]
};

export function Tasks() {
  const { user, appSettings } = useAuth();
  const [activeTab, setActiveTab] = useState<"daily" | "weekly" | "monthly">("daily");
  const [loading, setLoading] = useState(true);
  const [timeLeft, setTimeLeft] = useState("");
  const [progress, setProgress] = useState<Record<string, number>>({});
  const [claims, setClaims] = useState<Record<string, boolean>>({});

  // Helper to get start of period
  const getPeriodStart = (type: string) => {
    const now = new Date();
    const start = new Date(now);
    start.setHours(0, 0, 0, 0);

    if (type === 'weekly') {
      const day = start.getDay(); // 0 is Sunday
      const diff = start.getDate() - day + (day === 0 ? -6 : 1); // Adjust to Monday start
      start.setDate(diff);
    } else if (type === 'monthly') {
      start.setDate(1);
    }
    return start;
  };

  // Helper to get unique period ID for claims
  const getPeriodId = (type: string) => {
    const start = getPeriodStart(type);
    return `${type}_${start.toISOString().split('T')[0]}`;
  };

  // Timer Logic
  useEffect(() => {
    const timer = setInterval(() => {
      const now = new Date();
      const end = new Date(now);
      end.setHours(23, 59, 59, 999);

      if (activeTab === 'weekly') {
        const day = end.getDay();
        const diff = end.getDate() + (7 - day + (day === 0 ? -6 : 0)); // Next Sunday
        end.setDate(diff);
      } else if (activeTab === 'monthly') {
        end.setMonth(end.getMonth() + 1);
        end.setDate(0); // Last day of current month
      }

      const diff = end.getTime() - now.getTime();
      const days = Math.floor(diff / (1000 * 60 * 60 * 24));
      const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((diff % (1000 * 60)) / 1000);

      let timeString = "";
      if (days > 0) timeString += `${days}d `;
      timeString += `${hours}h ${minutes}m ${seconds}s`;
      setTimeLeft(timeString);
    }, 1000);

    return () => clearInterval(timer);
  }, [activeTab]);

  useEffect(() => {
    if (user) {
      fetchData();
    }
  }, [user, activeTab]);

  const fetchData = async () => {
    setLoading(true);
    try {
      const periodStart = getPeriodStart(activeTab);
      const periodId = getPeriodId(activeTab);

      // 1. Fetch Links & Calculate Views/Earnings
      const linksQ = query(collection(db, "links"), where("userID", "==", user!.uid));
      const linksSnap = await getDocs(linksQ);

      let totalViews = 0;
      let totalEarnings = 0;
      let linksCountViews = 0;
      let maxSingleLinkViews = 0;

      linksSnap.forEach(doc => {
        const data = doc.data();
        const dailyClicks = data.dailyClicks || {};
        let linkViewsInPeriod = 0;

        Object.entries(dailyClicks).forEach(([dateStr, clicks]: [string, any]) => {
          const date = new Date(dateStr);
          if (date >= periodStart) {
            const count = Number(clicks);
            linkViewsInPeriod += count;
            totalViews += count;
            
            // Calculate earnings for this specific click count
            // Note: Using current CPM setting as approximation if historical not stored
            const cpm = data.cpm || appSettings.cpm;
            totalEarnings += calculateEarnings(count, cpm);

            if (data.shortenerType === 'links-count') {
              linksCountViews += count;
            }
          }
        });

        if (linkViewsInPeriod > maxSingleLinkViews) {
          maxSingleLinkViews = linkViewsInPeriod;
        }
      });

      // 2. Fetch Withdrawals
      const withdrawalsQ = query(
        collection(db, "withdrawals"), 
        where("userID", "==", user!.uid),
        where("status", "==", "Approved")
      );
      const wSnap = await getDocs(withdrawalsQ);
      let totalWithdrawals = 0;

      wSnap.forEach(doc => {
        const data = doc.data();
        const createdAt = data.createdAt?.toDate();
        if (createdAt && createdAt >= periodStart) {
          totalWithdrawals += data.amount;
        }
      });

      // 3. Fetch Referrals
      const referralsQ = query(
        collection(db, "users"),
        where("referredBy", "==", user!.uid)
      );
      const referralsSnap = await getDocs(referralsQ);
      let totalReferrals = 0;
      referralsSnap.forEach(doc => {
        const data = doc.data();
        const joinedAt = data.createdAt?.toDate();
        if (joinedAt && joinedAt >= periodStart) {
          totalReferrals++;
        }
      });

      // 4. Update Progress State
      setProgress({
        'views': totalViews,
        'earnings': totalEarnings,
        'withdrawals': totalWithdrawals,
        'links-count-views': linksCountViews,
        'single-link-views': maxSingleLinkViews,
        'referrals': totalReferrals
      });

      // 5. Fetch Claims
      const claimsQ = query(
        collection(db, "claims"),
        where("userId", "==", user!.uid),
        where("periodId", "==", periodId)
      );
      const claimsSnap = await getDocs(claimsQ);
      const claimedTasks: Record<string, boolean> = {};
      claimsSnap.forEach(doc => {
        claimedTasks[doc.data().taskId] = true;
      });
      setClaims(claimedTasks);

    } catch (error) {
      console.error("Error fetching task data:", error);
      toast.error("Failed to load tasks");
    } finally {
      setLoading(false);
    }
  };

  const handleClaim = async (task: Task) => {
    if (!user) return;
    
    const periodId = getPeriodId(activeTab);
    const claimId = `${user.uid}_${task.id}_${periodId}`;

    try {
      // 1. Check if already claimed (client-side check first)
      if (claims[task.id]) return;

      // 2. Add to claims collection
      await setDoc(doc(db, "claims", claimId), {
        userId: user.uid,
        taskId: task.id,
        periodId: periodId,
        reward: task.reward,
        claimedAt: Timestamp.now()
      });

      // 3. Update User Balance
      await updateDoc(doc(db, "users", user.uid), {
        walletBalance: increment(task.reward)
      });

      // 4. Update UI
      setClaims(prev => ({ ...prev, [task.id]: true }));
      toast.success(`Successfully claimed ₹${task.reward}!`);

    } catch (error: any) {
      console.error("Claim error:", error);
      if (error.code === 'already-exists') {
        toast.error("Already claimed!");
      } else {
        toast.error("Failed to claim reward");
      }
    }
  };

  const getProgressValue = (task: Task) => {
    const current = progress[task.type] || 0;
    return Math.min(100, (current / task.target) * 100);
  };

  const getCurrentValue = (task: Task) => {
    return progress[task.type] || 0;
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8 pb-20">
      {/* Header & Timer */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h1 className="text-4xl font-black text-gray-900 tracking-tight">Tasks & Rewards</h1>
          <p className="text-gray-500 font-medium mt-2">Complete tasks to earn extra cash!</p>
        </div>
        
        <div className="bg-gray-900 text-white px-6 py-4 rounded-2xl shadow-xl flex items-center gap-4 animate-in slide-in-from-right duration-500">
          <div className="p-3 bg-white/10 rounded-xl">
            <Clock size={24} className="text-emerald-400" />
          </div>
          <div>
            <p className="text-[10px] font-black uppercase tracking-widest text-gray-400">
              {activeTab} Reset In
            </p>
            <p className="text-2xl font-mono font-bold tracking-wider text-emerald-400">
              {timeLeft || "Loading..."}
            </p>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex p-1.5 bg-white border border-gray-200 rounded-2xl w-full max-w-md shadow-sm">
        {(["daily", "weekly", "monthly"] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`flex-1 py-3 rounded-xl font-black text-sm uppercase tracking-wider transition-all duration-200 ${
              activeTab === tab
                ? "bg-emerald-600 text-white shadow-md transform scale-105"
                : "text-gray-500 hover:text-gray-900 hover:bg-gray-50"
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* Tasks Grid */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {[1, 2, 3, 4].map(i => (
            <div key={i} className="h-64 bg-gray-100 rounded-3xl animate-pulse"></div>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {TASKS[activeTab].map((task) => {
            const current = getCurrentValue(task);
            const percent = getProgressValue(task);
            const isCompleted = current >= task.target;
            const isClaimed = claims[task.id];

            return (
              <div 
                key={task.id} 
                className={`relative overflow-hidden bg-white p-8 rounded-[2rem] border-2 transition-all duration-300 group ${
                  isClaimed 
                    ? 'border-gray-100 opacity-60' 
                    : isCompleted 
                      ? 'border-emerald-500 shadow-xl shadow-emerald-100' 
                      : 'border-gray-100 hover:border-emerald-200 hover:shadow-lg'
                }`}
              >
                {/* Background Decoration */}
                <div className="absolute top-0 right-0 p-8 opacity-5 transform translate-x-4 -translate-y-4 group-hover:scale-110 transition-transform">
                  <Award size={120} />
                </div>

                <div className="relative z-10">
                  <div className="flex justify-between items-start mb-6">
                    <div className={`p-4 rounded-2xl ${
                      isCompleted ? 'bg-emerald-100 text-emerald-600' : 'bg-gray-50 text-gray-400'
                    }`}>
                      {task.type === 'earnings' ? <IndianRupee size={28} /> : 
                       task.type === 'withdrawals' ? <Gift size={28} /> : 
                       task.type === 'referrals' ? <Users size={28} /> :
                       <TrendingUp size={28} />}
                    </div>
                    <div className="text-right">
                      <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Reward</p>
                      <p className="text-3xl font-black text-emerald-600">₹{task.reward}</p>
                    </div>
                  </div>

                  <h3 className="text-xl font-black text-gray-900 mb-2">{task.title}</h3>
                  <p className="text-gray-500 font-medium text-sm mb-8">{task.description}</p>

                  {/* Progress Bar */}
                  <div className="space-y-3 mb-8">
                    <div className="flex justify-between text-xs font-bold uppercase tracking-wider">
                      <span className={isCompleted ? "text-emerald-600" : "text-gray-400"}>
                        {isCompleted ? "Goal Reached" : "Progress"}
                      </span>
                      <span className="text-gray-900">
                        {task.type === 'earnings' || task.type === 'withdrawals' ? '₹' : ''}
                        {current.toFixed(0)} / {task.target}
                      </span>
                    </div>
                    <div className="h-4 bg-gray-100 rounded-full overflow-hidden">
                      <div 
                        className={`h-full rounded-full transition-all duration-1000 ease-out ${
                          isCompleted ? 'bg-emerald-500' : 'bg-emerald-400'
                        }`}
                        style={{ width: `${percent}%` }}
                      ></div>
                    </div>
                  </div>

                  {/* Action Button */}
                  {isClaimed ? (
                    <button disabled className="w-full py-4 bg-gray-100 text-gray-400 rounded-xl font-black text-sm uppercase tracking-widest flex items-center justify-center gap-2 cursor-not-allowed">
                      <CheckCircle size={20} /> Claimed
                    </button>
                  ) : isCompleted ? (
                    <button 
                      onClick={() => handleClaim(task)}
                      className="w-full py-4 bg-emerald-600 text-white rounded-xl font-black text-sm uppercase tracking-widest hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-200 flex items-center justify-center gap-2 animate-bounce"
                    >
                      <Gift size={20} /> Claim Reward
                    </button>
                  ) : (
                    <button disabled className="w-full py-4 bg-gray-50 text-gray-400 rounded-xl font-black text-sm uppercase tracking-widest flex items-center justify-center gap-2 cursor-not-allowed">
                      <Lock size={18} /> Locked
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
