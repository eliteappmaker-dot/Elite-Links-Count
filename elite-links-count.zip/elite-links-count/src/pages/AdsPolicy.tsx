import React from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { ShieldCheck, AlertTriangle, Info } from 'lucide-react';

export function AdsPolicy() {
  const { urlSettings } = useAuth();

  return (
    <div className="max-w-4xl mx-auto py-12 px-4">
      <div className="bg-white rounded-3xl shadow-xl border border-gray-100 overflow-hidden">
        <div className="bg-emerald-600 p-8 text-white">
          <div className="flex items-center gap-4 mb-4">
            <ShieldCheck size={40} />
            <h1 className="text-3xl font-black uppercase tracking-tight">Ads Policy</h1>
          </div>
          <p className="text-emerald-50 opacity-90 font-medium">How we use advertisements to keep our service free.</p>
        </div>
        
        <div className="p-8 md:p-12 space-y-10">
          <section className="space-y-4">
            <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2">
              <Info className="text-emerald-600" size={24} /> Why we show ads?
            </h2>
            <p className="text-gray-600 leading-relaxed">
              Elite Links Count is a free service that allows users to shorten links and earn money. To sustain our servers, pay our users, and continue developing new features, we rely on advertising revenue. Without ads, we would not be able to offer this platform for free.
            </p>
          </section>

          <section className="space-y-4">
            <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2">
              <AlertTriangle className="text-amber-500" size={24} /> AdBlocker Usage
            </h2>
            <p className="text-gray-600 leading-relaxed">
              Using AdBlockers or any software that prevents ads from loading is strictly prohibited on our platform. If we detect an AdBlocker, you will be prompted to disable it before you can continue using the site. Repeated attempts to bypass our ad systems may lead to account suspension.
            </p>
          </section>

          <section className="space-y-4">
            <h2 className="text-xl font-bold text-gray-900">Types of Ads</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 bg-gray-50 rounded-2xl border border-gray-100">
                <h3 className="font-bold text-gray-900 mb-2">Banner Ads</h3>
                <p className="text-sm text-gray-600">Standard display ads shown on various pages of the website.</p>
              </div>
              <div className="p-4 bg-gray-50 rounded-2xl border border-gray-100">
                <h3 className="font-bold text-gray-900 mb-2">Pop-unders</h3>
                <p className="text-sm text-gray-600">Ads that open in a new window or tab behind your current browser window.</p>
              </div>
              <div className="p-4 bg-gray-50 rounded-2xl border border-gray-100">
                <h3 className="font-bold text-gray-900 mb-2">Native Ads</h3>
                <p className="text-sm text-gray-600">Ads that match the look, feel, and function of the media format in which they appear.</p>
              </div>
              <div className="p-4 bg-gray-50 rounded-2xl border border-gray-100">
                <h3 className="font-bold text-gray-900 mb-2">Direct Links</h3>
                <p className="text-sm text-gray-600">Special links that may redirect you through an advertisement page.</p>
              </div>
            </div>
          </section>

          <div className="pt-8 border-t border-gray-100 flex flex-col md:flex-row justify-between items-center gap-6">
            <p className="text-sm text-gray-500 font-medium">Last Updated: {new Date().toLocaleDateString()}</p>
            {urlSettings.contactAdmin && (
              <a href={urlSettings.contactAdmin} className="bg-emerald-600 text-white px-8 py-3 rounded-2xl font-bold hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-100">
                Contact Support
              </a>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
