/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/contexts/AuthContext";
import { Layout } from "@/components/Layout";
import { Login } from "@/pages/Login";
import { Dashboard } from "@/pages/Dashboard";
import { Wallet } from "@/pages/Wallet";
import { Admin } from "@/pages/Admin";
import { Analytics } from "@/pages/Analytics";
import { LinkDetails } from "@/pages/LinkDetails";
import { LinksCountShortener } from "@/pages/LinksCountShortener";
import { EliteHubShortener } from "@/pages/EliteHubShortener";
import { Profile } from "@/pages/Profile";
import { PrivacyPolicy } from "@/pages/PrivacyPolicy";
import { Terms } from "@/pages/Terms";
import { Tasks } from "@/pages/Tasks";
import { Invite } from "@/pages/Invite";
import { AdsPolicy } from "@/pages/AdsPolicy";
import { FakeClicksPolicy } from "@/pages/FakeClicksPolicy";
import { EarningPolicy } from "@/pages/EarningPolicy";
import { AdBlockDetector } from "@/components/AdBlockDetector";
import { Toaster } from "react-hot-toast";

import { Redirect } from "@/pages/Redirect";

export default function App() {
  return (
    <Router>
      <AuthProvider>
        <Toaster position="top-center" />
        <Routes>
          {/* Main Layout Routes */}
          <Route path="/" element={<Layout />}>
            <Route index element={<LinksCountShortener />} />
            <Route path="login" element={<Login />} />
            <Route path="dashboard" element={<Dashboard />} />
            <Route path="wallet" element={<Wallet />} />
            <Route path="profile" element={<Profile />} />
            <Route path="analytics" element={<Analytics />} />
            <Route path="analytics/:id" element={<LinkDetails />} />
            <Route path="tasks" element={<Tasks />} />
            <Route path="invite" element={<Invite />} />
            <Route path="admin" element={<Admin />} />
            <Route path="elite-hub" element={<EliteHubShortener />} />
            <Route path="privacy" element={<PrivacyPolicy />} />
            <Route path="terms" element={<Terms />} />
            <Route path="ads-policy" element={<AdsPolicy />} />
            <Route path="fake-clicks-policy" element={<FakeClicksPolicy />} />
            <Route path="earning-policy" element={<EarningPolicy />} />
          </Route>
          
          {/* Redirect Routes (No Layout) */}
          <Route path="/public/:id" element={<Redirect />} />
          <Route path="/v/:id" element={<Redirect />} />
          <Route path="/c/:id" element={<Redirect />} />
          <Route path="/f/:id" element={<Redirect />} />
          <Route path="/links-count/:id" element={<Redirect />} />
          <Route path="/:id" element={<Redirect />} />
        </Routes>
      </AuthProvider>
    </Router>
  );
}
