import React, { createContext, useContext, useEffect, useState } from "react";
import { auth, db } from "@/lib/firebase";
import { onAuthStateChanged, User } from "firebase/auth";
import { doc, getDoc, setDoc, onSnapshot } from "firebase/firestore";

interface AppSettings {
  cpm: number;
  cpmLow: number;
  cpmMedium: number;
  cpmHigh: number;
  cpmEliteHub: number;
  cpmLinksCount: number;
  websiteUrl?: string;
}

interface UrlSettings {
  telegramChannel?: string;
  telegramGroup?: string;
  whatsappChannel?: string;
  instagramChannel?: string;
  adsPolicy?: string;
  fakeClicksPolicy?: string;
  contactAdmin?: string;
  privacyPolicy?: string;
  useAndCondition?: string;
  paymentIssue?: string;
  websiteAdsProblem?: string;
  adsCookies?: string;
  websiteProblem?: string;
  feedback?: string;
  inviteShareUrl?: string;
}

interface UserProfile {
  uid: string;
  email: string | null;
  displayName: string | null;
  photoURL: string | null;
  isAdmin: boolean;
  isBlocked: boolean;
  isEliteHubVerified?: boolean;
  isLinksCountVerified?: boolean;
  totalEarnings: number;
  totalClicks: number;
  walletBalance: number;
  referralCode?: string;
}

interface AuthContextType {
  user: User | null;
  userProfile: UserProfile | null;
  isAdmin: boolean;
  loading: boolean;
  appSettings: AppSettings;
  urlSettings: UrlSettings;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  userProfile: null,
  isAdmin: false,
  loading: true,
  appSettings: { cpm: 500, cpmLow: 0, cpmMedium: 300, cpmHigh: 600, cpmEliteHub: 500, cpmLinksCount: 500 },
  urlSettings: {},
});

const ADMIN_EMAILS = ["eliteappmaker@gmail.com", "myotherwork2025@gmail.com"];

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);
  const userUnsubscribeRef = React.useRef<(() => void) | null>(null);
  const [appSettings, setAppSettings] = useState<AppSettings>({ 
    cpm: 500, 
    cpmLow: 0, 
    cpmMedium: 300, 
    cpmHigh: 600,
    cpmEliteHub: 500,
    cpmLinksCount: 500
  });
  const [urlSettings, setUrlSettings] = useState<UrlSettings>({});

  useEffect(() => {
    // Real-time App Settings
    const unsubscribeApp = onSnapshot(doc(db, "settings", "app"), (docSnap) => {
      if (docSnap.exists()) {
        const data = docSnap.data();
        setAppSettings({ 
          cpm: Number(data.cpm || 500),
          cpmLow: Number(data.cpmLow || 0),
          cpmMedium: Number(data.cpmMedium || 300),
          cpmHigh: Number(data.cpmHigh || 600),
          cpmEliteHub: Number(data.cpmEliteHub || 500),
          cpmLinksCount: Number(data.cpmLinksCount || 500),
          websiteUrl: data.websiteUrl
        });
      }
    }, (error) => {
      console.error("Error listening to app settings:", error);
    });

    // Real-time URL Settings
    const unsubscribeUrls = onSnapshot(doc(db, "settings", "urls"), (urlSnap) => {
      if (urlSnap.exists()) {
        setUrlSettings(urlSnap.data());
      }
    }, (error) => {
      console.error("Error listening to url settings:", error);
    });

    const unsubscribeAuth = onAuthStateChanged(auth, async (authUser) => {
      // Cleanup previous user listener if it exists
      if (userUnsubscribeRef.current) {
        userUnsubscribeRef.current();
        userUnsubscribeRef.current = null;
      }

      if (authUser) {
        setUser(authUser);
        
        // Real-time User Profile
        const userRef = doc(db, "users", authUser.uid);
        const unsub = onSnapshot(userRef, async (docSnap) => {
          if (docSnap.exists()) {
            const data = docSnap.data();
            const profile: UserProfile = {
              uid: authUser.uid,
              email: authUser.email,
              displayName: authUser.displayName,
              photoURL: authUser.photoURL,
              isAdmin: data.isAdmin || ADMIN_EMAILS.includes(authUser.email || ""),
              isBlocked: data.isBlocked || false,
              isEliteHubVerified: data.isEliteHubVerified || false,
              isLinksCountVerified: data.isLinksCountVerified || false,
              totalEarnings: data.totalEarnings || 0,
              totalClicks: data.totalClicks || 0,
              walletBalance: data.walletBalance || 0,
              referralCode: data.referralCode || "",
            };
            setUserProfile(profile);
            setIsAdmin(profile.isAdmin);
          } else {
            // Create user doc if not exists
            const newProfile: UserProfile = {
              uid: authUser.uid,
              email: authUser.email,
              displayName: authUser.displayName,
              photoURL: authUser.photoURL,
              isAdmin: ADMIN_EMAILS.includes(authUser.email || ""),
              isBlocked: false,
              isEliteHubVerified: false,
              isLinksCountVerified: false,
              totalEarnings: 0,
              totalClicks: 0,
              walletBalance: 0,
              referralCode: "",
            };
            await setDoc(userRef, {
              ...newProfile,
              createdAt: new Date(),
            });
            setUserProfile(newProfile);
            setIsAdmin(newProfile.isAdmin);
          }
          setLoading(false);
        }, (error) => {
          console.error("User profile listener error:", error);
          setLoading(false);
        });

        userUnsubscribeRef.current = unsub;
      } else {
        setUser(null);
        setUserProfile(null);
        setIsAdmin(false);
        setLoading(false);
      }
    });

    return () => {
      unsubscribeApp();
      unsubscribeUrls();
      unsubscribeAuth();
      if (userUnsubscribeRef.current) userUnsubscribeRef.current();
    };
  }, []);

  return (
    <AuthContext.Provider value={{ user, userProfile, isAdmin, loading, appSettings, urlSettings }}>
      {loading ? (
        <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center">
          <div className="relative flex flex-col items-center">
            <div className="flex flex-col items-center">
              <img 
                src="https://iili.io/qfdOijn.png" 
                alt="Elite Links Count" 
                className="h-40 md:h-48 object-contain animate-logo-glow relative z-10 mb-6" 
                onError={(e) => {
                  e.currentTarget.src = "https://ui-avatars.com/api/?name=Elite+Links+Count&background=10b981&color=fff";
                }} 
              />
              <div className="flex flex-col items-center mb-10">
                <span className="font-righteous text-4xl md:text-6xl text-gradient leading-none">Elite Links</span>
                <span className="font-righteous text-3xl md:text-5xl text-gradient leading-none opacity-80">Count</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-3 h-3 bg-emerald-600 rounded-full animate-bounce"></div>
                <div className="w-3 h-3 bg-emerald-500 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                <div className="w-3 h-3 bg-emerald-400 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        children
      )}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
